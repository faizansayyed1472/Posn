/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { TohandsHeader } from './components/TohandsHeader';
import { TohandsCalculator } from './components/TohandsCalculator';
import { PosCatalogDrawer } from './components/PosCatalogDrawer';
import { SalePaymentModal } from './components/SalePaymentModal';
import { ExpenseModal } from './components/ExpenseModal';
import { QuickUpiQrModal } from './components/QuickUpiQrModal';
import { UdhaarLedgerModal } from './components/UdhaarLedgerModal';
import { ReportsDashboardModal } from './components/ReportsDashboardModal';
import { StoreSettingsModal } from './components/StoreSettingsModal';
import { CustomWeightModal } from './components/CustomWeightModal';
import { PosBarcodeScannerModal } from './components/PosBarcodeScannerModal';
import { TopCashFlowBanner } from './components/TopCashFlowBanner';
import { WebProductSearch } from './components/WebProductSearch';
import { AuthLoginModal } from './components/AuthLoginModal';
import { BillsManagementModal } from './components/BillsManagementModal';
import { ChevronLeft, ChevronRight, ChevronUp, ChevronDown, SlidersHorizontal, Layers, ShoppingBag, Database, ArrowDown } from 'lucide-react';
import { printReceipt } from './utils/printer';
import {
  Product,
  BillItem,
  Transaction,
  CustomerUdhaar,
  StoreSettings,
  StaffAccount,
  FullBackupData,
} from './types';
import { INITIAL_PRODUCTS } from './data/defaultInventory';
import { playKeySound } from './utils/audio';
import { createFullBackupData, saveAutoBackupSnapshot } from './utils/backup';
import {
  getAllProductsFromIDB,
  saveAllProductsToIDB,
  saveSingleProductToIDB,
  CATALOGUE_MAX_CAPACITY,
} from './utils/idbStorage';

const LEGACY_STORAGE_KEYS = {
  PRODUCTS: ['tohands_products_v2', 'tohands_products_v1'],
  TRANSACTIONS: ['tohands_transactions_v2', 'tohands_transactions_v1'],
  CUSTOMERS: ['tohands_customers_v2', 'tohands_customers_v1'],
  SETTINGS: ['tohands_settings_v2', 'tohands_settings_v1'],
  OPENING_AMOUNT: ['tohands_opening_amount'],
  ADDED_CASH: ['tohands_added_cash'],
  THEME: ['tohands_theme_mode'],
  LAST_BACKUP: ['tohands_last_auto_backup_date'],
};

const STORAGE_KEYS = {
  PRODUCTS: 'nayab_products_v2',
  TRANSACTIONS: 'nayab_transactions_v2',
  CUSTOMERS: 'nayab_customers_v2',
  SETTINGS: 'nayab_settings_v2',
  OPENING_AMOUNT: 'nayab_opening_amount',
  ADDED_CASH: 'nayab_added_cash',
  THEME: 'nayab_theme_mode',
  LAST_BACKUP: 'nayab_last_auto_backup_date',
};

// Safe storage reader that prioritizes new nayab_ keys and seamlessly migrates legacy tohands_ data
function getStoredItem(newKey: string, legacyKeys: string[] = []): string | null {
  try {
    const val = localStorage.getItem(newKey);
    if (val !== null) return val;
    for (const oldKey of legacyKeys) {
      const oldVal = localStorage.getItem(oldKey);
      if (oldVal !== null) {
        localStorage.setItem(newKey, oldVal);
        return oldVal;
      }
    }
  } catch (e) {
    console.warn('Storage read error:', e);
  }
  return null;
}

const DEFAULT_STAFF: StaffAccount[] = [
  {
    id: 'staff-1',
    name: 'Nayab Bhai',
    role: 'owner',
    pin: 'nayab@q6',
    phone: '9876543210',
    active: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'staff-2',
    name: 'Rahul (Cashier)',
    role: 'cashier',
    pin: '0000',
    active: true,
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_SETTINGS: StoreSettings = {
  shopName: 'Nayab Masale & Kirana Store',
  tagline: 'Authentic Indian Spices & Daily Groceries',
  phone: '9876543210',
  upiId: 'nayabmasale@upi',
  upiName: 'Nayab Masale & Kirana',
  address: 'Main Bazaar, Spice Market',
  defaultTaxRate: 5,
  staffAccounts: DEFAULT_STAFF,
  activeStaffId: 'staff-1',
  printerConfig: {
    printerType: 'browser',
    paperWidth: '58mm',
    autoPrintOnSale: false,
    connected: false,
  },
};

const INITIAL_CUSTOMERS: CustomerUdhaar[] = [
  { id: 'c-1', name: 'Ramesh Bhai (Halwai)', phone: '9820011223', totalDue: 1850, lastActive: new Date().toISOString() },
  { id: 'c-2', name: 'Gupta Ji Grocery', phone: '9811122233', totalDue: 3400, lastActive: new Date().toISOString() },
  { id: 'c-3', name: 'Anwar Catering', phone: '9899988877', totalDue: 5600, lastActive: new Date().toISOString() },
];

export default function App() {
  // Theme state (dark / light mode)
  const [themeMode, setThemeMode] = useState<'dark' | 'light'>(() => {
    try {
      const saved = getStoredItem(STORAGE_KEYS.THEME, LEGACY_STORAGE_KEYS.THEME);
      return saved === 'light' || saved === 'dark' ? saved : 'dark';
    } catch {
      return 'dark';
    }
  });

  const handleToggleTheme = () => {
    setThemeMode((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      try {
        localStorage.setItem(STORAGE_KEYS.THEME, next);
      } catch {}
      return next;
    });
  };

  // Store inventory products
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = getStoredItem(STORAGE_KEYS.PRODUCTS, LEGACY_STORAGE_KEYS.PRODUCTS);
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  // Transactions ledger
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = getStoredItem(STORAGE_KEYS.TRANSACTIONS, LEGACY_STORAGE_KEYS.TRANSACTIONS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Customers credit ledger (Udhaar)
  const [customers, setCustomers] = useState<CustomerUdhaar[]>(() => {
    try {
      const saved = getStoredItem(STORAGE_KEYS.CUSTOMERS, LEGACY_STORAGE_KEYS.CUSTOMERS);
      return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
    } catch {
      return INITIAL_CUSTOMERS;
    }
  });

  // Store profile, UPI, Staff & Printer settings
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(() => {
    try {
      const saved = getStoredItem(STORAGE_KEYS.SETTINGS, LEGACY_STORAGE_KEYS.SETTINGS);
      if (saved) {
        const parsed = JSON.parse(saved);
        const existingStaff: StaffAccount[] = parsed.staffAccounts?.length ? parsed.staffAccounts : DEFAULT_SETTINGS.staffAccounts;
        // Automatically migrate default owner pin from 1234 to nayab@q6 if unmodified
        const migratedStaff = existingStaff.map((s) => {
          if (s.role === 'owner' && (s.pin === '1234' || !s.pin)) {
            return { ...s, pin: 'nayab@q6' };
          }
          return s;
        });

        return {
          ...DEFAULT_SETTINGS,
          ...parsed,
          staffAccounts: migratedStaff,
          activeStaffId: parsed.activeStaffId || DEFAULT_SETTINGS.activeStaffId,
          printerConfig: {
            ...DEFAULT_SETTINGS.printerConfig,
            ...(parsed.printerConfig || {}),
          },
        };
      }
      return DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Active POS bill items currently on the counter
  const [billItems, setBillItems] = useState<BillItem[]>([]);

  // Modal control states
  const [isPosCatalogOpen, setIsPosCatalogOpen] = useState(false);
  const [isSaleModalOpen, setIsSaleModalOpen] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isUpiQrModalOpen, setIsUpiQrModalOpen] = useState(false);
  const [isUdhaarLedgerOpen, setIsUdhaarLedgerOpen] = useState(false);
  const [isReportsOpen, setIsReportsOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isBillsManagerOpen, setIsBillsManagerOpen] = useState(false);
  const [isBarcodeScannerOpen, setIsBarcodeScannerOpen] = useState(false);
  const [settingsInitialTab, setSettingsInitialTab] = useState<'upi' | 'inventory' | 'staff' | 'printer' | 'profile' | 'backup' | 'reports'>('upi');
  const [quickWeightProduct, setQuickWeightProduct] = useState<Product | null>(null);

  // Authentication State (Staff & Owner Login on application launch)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      const saved = sessionStorage.getItem('nayab_authenticated_session');
      return saved === 'true';
    } catch {
      return false;
    }
  });
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(() => {
    try {
      const saved = sessionStorage.getItem('nayab_authenticated_session');
      return saved !== 'true';
    } catch {
      return true;
    }
  });

  // Active amount passed to modals from keypad or bill
  const [activeModalAmount, setActiveModalAmount] = useState<number>(0);

  // Fast Moving products vertical scrolling
  const fastMovingScrollRef = useRef<HTMLDivElement>(null);

  const handleScrollFastMoving = (direction: 'up' | 'down') => {
    if (fastMovingScrollRef.current) {
      const scrollAmount = 140;
      fastMovingScrollRef.current.scrollBy({
        top: direction === 'up' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  // Opening and Added Cash amounts on top
  const [openingAmount, setOpeningAmount] = useState<number>(() => {
    try {
      const saved = getStoredItem(STORAGE_KEYS.OPENING_AMOUNT, LEGACY_STORAGE_KEYS.OPENING_AMOUNT);
      return saved !== null ? parseFloat(saved) : 1000;
    } catch {
      return 1000;
    }
  });

  const [addedAmount, setAddedAmount] = useState<number>(() => {
    try {
      const saved = getStoredItem(STORAGE_KEYS.ADDED_CASH, LEGACY_STORAGE_KEYS.ADDED_CASH);
      return saved !== null ? parseFloat(saved) : 0;
    } catch {
      return 0;
    }
  });

  const handleUpdateOpeningAmount = (newAmount: number) => {
    setOpeningAmount(newAmount);
    localStorage.setItem(STORAGE_KEYS.OPENING_AMOUNT, String(newAmount));
  };

  const handleAddCashAmount = (added: number) => {
    setAddedAmount((prev) => {
      const updated = Math.round((prev + added) * 100) / 100;
      localStorage.setItem(STORAGE_KEYS.ADDED_CASH, String(updated));
      return updated;
    });
  };

  const handleResetDailyCash = () => {
    setOpeningAmount(0);
    setAddedAmount(0);
    localStorage.setItem(STORAGE_KEYS.OPENING_AMOUNT, '0');
    localStorage.setItem(STORAGE_KEYS.ADDED_CASH, '0');
  };

  // Quick Print Bill Slip from Calculator (prints active bill or single-amount slip with dynamic UPI QR)
  const handleQuickPrintSlip = async (amount: number) => {
    const activeStaff = storeSettings.staffAccounts?.find((s) => s.id === storeSettings.activeStaffId);
    const items: BillItem[] =
      billItems.length > 0
        ? [...billItems]
        : [
            {
              id: `item-${Date.now()}`,
              name: 'Quick Counter Sale / Kirana Items',
              rate: amount,
              quantity: 1,
              unit: 'pcs',
              total: amount,
            },
          ];

    const receiptData = {
      shopName: storeSettings.shopName || 'Nayab Masale & Kirana Store',
      address: storeSettings.address || 'Main Bazaar, Spice Market',
      phone: storeSettings.phone || '9876543210',
      gstin: storeSettings.gstin,
      receiptNumber: `NB-SLIP-${Date.now().toString().slice(-6)}`,
      date: new Date().toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'medium' }),
      cashierName: activeStaff?.name || 'Nayab Bhai',
      items,
      subtotal: amount,
      taxAmount: 0,
      taxRate: 0,
      grandTotal: amount,
      paymentMode: 'Quick Print Slip',
      upiId: storeSettings.upiId,
    };
    await printReceipt(receiptData, storeSettings);
  };

  // Print current active bill
  const handlePrintCurrentBill = async () => {
    if (billItems.length === 0) return;
    const activeStaff = storeSettings.staffAccounts?.find((s) => s.id === storeSettings.activeStaffId);
    const receiptData = {
      shopName: storeSettings.shopName || 'Nayab Masale & Kirana',
      address: storeSettings.address || 'Shop No. 4, Main Bazar',
      phone: storeSettings.phone || '9876543210',
      gstin: storeSettings.gstin,
      receiptNumber: `NB-${Date.now().toString().slice(-6)}`,
      date: new Date().toLocaleString('en-IN'),
      cashierName: activeStaff?.name || 'Nayab Bhai',
      items: [...billItems],
      subtotal: billSubtotal,
      taxAmount: billTax,
      taxRate: storeSettings.defaultTaxRate,
      grandTotal: billGrandTotal,
      paymentMode: 'Cash Bill',
      upiId: storeSettings.upiId,
    };
    await printReceipt(receiptData, storeSettings);
  };

  // Load catalogue products from High-Capacity IndexedDB (supports up to 1,500,000 items)
  useEffect(() => {
    getAllProductsFromIDB()
      .then((idbProducts) => {
        if (idbProducts && idbProducts.length > 0) {
          setProducts(idbProducts);
        }
      })
      .catch((err) => {
        console.warn('Could not load products from IndexedDB:', err);
      });
  }, []);

  // Persist products to High-Capacity IndexedDB (supports up to 1,500,000 items)
  useEffect(() => {
    saveAllProductsToIDB(products).catch((err) => {
      console.warn('Failed saving to IndexedDB:', err);
    });

    // Safely cache a small fallback snapshot to LocalStorage without exceeding 5MB quota
    try {
      if (products.length <= 500) {
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
      }
    } catch {
      // Ignore local storage quota overflow
    }
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(storeSettings));
  }, [storeSettings]);

  // Automated Full Data Backup Snapshot (Safeguards inventory, ledger & udhaar khata)
  useEffect(() => {
    if (storeSettings.autoBackupEnabled === false) return;
    try {
      const todayDateStr = new Date().toISOString().slice(0, 10);
      const lastAutoBackupDate = getStoredItem(STORAGE_KEYS.LAST_BACKUP, LEGACY_STORAGE_KEYS.LAST_BACKUP);
      if (lastAutoBackupDate !== todayDateStr && products.length > 0) {
        const fullBackup = createFullBackupData(
          products,
          transactions,
          customers,
          storeSettings,
          { openingAmount, addedAmount }
        );
        saveAutoBackupSnapshot(fullBackup);
        localStorage.setItem(STORAGE_KEYS.LAST_BACKUP, todayDateStr);
      }
    } catch (e) {
      console.warn('Auto backup check:', e);
    }
  }, [storeSettings.autoBackupEnabled, products.length, transactions.length, customers.length]);

  // Compute active bill total
  const billSubtotal = billItems.reduce((sum, item) => sum + item.total, 0);
  const billTax = (billSubtotal * storeSettings.defaultTaxRate) / 100;
  const billGrandTotal = Math.round((billSubtotal + billTax) * 100) / 100;

  // Compute Today's sales total
  const startOfToday = new Date().setHours(0, 0, 0, 0);
  const todaySalesTotal = transactions
    .filter((t) => t.type === 'sale' && new Date(t.timestamp).getTime() >= startOfToday)
    .reduce((sum, t) => sum + t.amount, 0);

  const todayOnlineSalesTotal = transactions
    .filter(
      (t) =>
        t.type === 'sale' &&
        t.paymentMode === 'online_upi' &&
        new Date(t.timestamp).getTime() >= startOfToday
    )
    .reduce((sum, t) => sum + t.amount, 0);

  const todayUdhaarSalesTotal = transactions
    .filter(
      (t) =>
        t.type === 'sale' &&
        t.paymentMode === 'credit_udhaar' &&
        new Date(t.timestamp).getTime() >= startOfToday
    )
    .reduce((sum, t) => sum + t.amount, 0);

  const todayExpensesTotal = transactions
    .filter((t) => t.type === 'expense' && new Date(t.timestamp).getTime() >= startOfToday)
    .reduce((sum, t) => sum + t.amount, 0);

  const pendingUdhaarTotal = customers.reduce((sum, c) => sum + c.totalDue, 0);
  const currentActiveStaff = storeSettings.staffAccounts.find((s) => s.id === storeSettings.activeStaffId) || storeSettings.staffAccounts[0];
  const isOwner = currentActiveStaff?.role === 'owner';

  // Add Item to Bill
  const handleAddItemToBill = (item: Omit<BillItem, 'id'>) => {
    playKeySound('action');
    const newItem: BillItem = {
      ...item,
      id: `bi-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    };
    setBillItems((prev) => [...prev, newItem]);
  };

  // Update Item Quantity directly on the bill tape
  const handleUpdateItemQuantity = (id: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveItem(id);
      return;
    }
    setBillItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const total = Math.round(newQuantity * item.rate * 100) / 100;
          return { ...item, quantity: newQuantity, total };
        }
        return item;
      })
    );
  };

  // Remove Item from Bill
  const handleRemoveItem = (id: string) => {
    playKeySound('clear');
    setBillItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Clear Bill
  const handleClearBill = () => {
    playKeySound('clear');
    setBillItems([]);
  };

  // Inventory modifications (High-capacity catalogue up to 1,500,000 items)
  const handleAddProductToInventory = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev.filter((p) => p.id !== newProd.id)]);
    // Directly save single item to High-Capacity IndexedDB immediately for instant persistence
    saveSingleProductToIDB(newProd).catch(console.warn);
  };

  const handleBulkAddProducts = (newItems: Product[]) => {
    setProducts((prev) => {
      const merged = [...newItems, ...prev];
      return merged.slice(0, CATALOGUE_MAX_CAPACITY);
    });
  };

  const handleClearAllProducts = () => {
    setProducts([]);
  };

  const handleUpdateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
  };

  // Staff switch
  const handleSwitchStaff = (staffId: string) => {
    setStoreSettings((prev) => ({
      ...prev,
      activeStaffId: staffId,
    }));
  };

  // User Login & Logout Handlers
  const handleLoginSuccess = (staff: StaffAccount) => {
    setIsAuthenticated(true);
    setIsLoginModalOpen(false);
    try {
      sessionStorage.setItem('nayab_authenticated_session', 'true');
    } catch {}
    setStoreSettings((prev) => ({
      ...prev,
      activeStaffId: staff.id,
    }));
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setIsLoginModalOpen(true);
    try {
      sessionStorage.removeItem('nayab_authenticated_session');
    } catch {}
  };

  // Update and Delete Transactions (Bills Management for Owner)
  const handleUpdateTransaction = (updatedTx: Transaction) => {
    setTransactions((prev) => {
      const updated = prev.map((t) => (t.id === updatedTx.id ? updatedTx : t));
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(updated));
      return updated;
    });
  };

  const handleDeleteTransaction = (transactionId: string) => {
    setTransactions((prev) => {
      const updated = prev.filter((t) => t.id !== transactionId);
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(updated));
      return updated;
    });
  };

  // Open Sale Modal from keypad or checkout
  const handleOpenSale = (currentAmt: number) => {
    const amt = billItems.length > 0 && billGrandTotal > 0 ? billGrandTotal : currentAmt;
    setActiveModalAmount(amt);
    setIsSaleModalOpen(true);
  };

  // Open Expense Modal
  const handleOpenExpense = (currentAmt: number) => {
    setActiveModalAmount(currentAmt > 0 ? currentAmt : 100);
    setIsExpenseModalOpen(true);
  };

  // Open UPI QR Modal
  const handleOpenUpiQr = (currentAmt: number) => {
    const amt = billItems.length > 0 && billGrandTotal > 0 ? billGrandTotal : (currentAmt > 0 ? currentAmt : 100);
    setActiveModalAmount(amt);
    setIsUpiQrModalOpen(true);
  };

  // Complete Sale
  const handleCompleteSale = (saleData: Omit<Transaction, 'id' | 'receiptNumber' | 'timestamp'>) => {
    const receiptNo = `NB-${Date.now().toString().slice(-6)}`;
    const activeStaff = storeSettings.staffAccounts.find((s) => s.id === storeSettings.activeStaffId);

    const newTx: Transaction = {
      ...saleData,
      id: `tx-${Date.now()}`,
      receiptNumber: receiptNo,
      timestamp: new Date().toISOString(),
      staffId: activeStaff?.id,
      staffName: activeStaff?.name,
      items: billItems.length > 0 ? [...billItems] : undefined,
    };

    setTransactions((prev) => [newTx, ...prev]);

    // If payment mode is Udhaar, update customer khata
    if (saleData.paymentMode === 'credit_udhaar' && saleData.customerName) {
      setCustomers((prev) => {
        const existingIdx = prev.findIndex(
          (c) =>
            c.id === saleData.customerId ||
            c.name.toLowerCase() === saleData.customerName?.toLowerCase()
        );

        if (existingIdx >= 0) {
          const updated = [...prev];
          updated[existingIdx] = {
            ...updated[existingIdx],
            totalDue: updated[existingIdx].totalDue + saleData.amount,
            lastActive: new Date().toISOString(),
          };
          return updated;
        } else {
          const newCustomer: CustomerUdhaar = {
            id: `cust-${Date.now()}`,
            name: saleData.customerName || 'Customer',
            phone: saleData.customerPhone || 'Not provided',
            totalDue: saleData.amount,
            lastActive: new Date().toISOString(),
          };
          return [newCustomer, ...prev];
        }
      });
    }

    // Clear active bill tape
    setBillItems([]);
  };

  // Record Expense
  const handleRecordExpense = (expenseData: Omit<Transaction, 'id' | 'receiptNumber' | 'timestamp'>) => {
    const receiptNo = `EXP-${Date.now().toString().slice(-6)}`;
    const activeStaff = storeSettings.staffAccounts.find((s) => s.id === storeSettings.activeStaffId);

    const newTx: Transaction = {
      ...expenseData,
      id: `tx-${Date.now()}`,
      receiptNumber: receiptNo,
      timestamp: new Date().toISOString(),
      staffId: activeStaff?.id,
      staffName: activeStaff?.name,
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  // Quick mark UPI paid
  const handleRecordQuickUpiSale = (amt: number) => {
    handleCompleteSale({
      type: 'sale',
      amount: amt,
      paymentMode: 'online_upi',
      remarks: 'Instant UPI QR Counter Payment',
      taxRate: storeSettings.defaultTaxRate,
    });
  };

  // Customer Udhaar Payment Received (Jama)
  const handleSettleCustomerUdhaar = (customerId: string, amount: number) => {
    setCustomers((prev) =>
      prev.map((c) => {
        if (c.id === customerId) {
          return {
            ...c,
            totalDue: Math.max(0, c.totalDue - amount),
            lastActive: new Date().toISOString(),
          };
        }
        return c;
      })
    );

    const cust = customers.find((c) => c.id === customerId);
    handleCompleteSale({
      type: 'sale',
      amount,
      paymentMode: 'cash',
      customerName: cust?.name,
      customerPhone: cust?.phone,
      customerId,
      remarks: `Udhaar Chukaya (Jama) by ${cust?.name || 'Customer'}`,
      taxRate: 0,
    });
  };

  // Add new customer account
  const handleAddCustomer = (newCustomer: CustomerUdhaar) => {
    setCustomers((prev) => [newCustomer, ...prev]);
  };

  // Restore backup
  const handleImportBackup = (backup: any) => {
    if (backup.products && Array.isArray(backup.products)) setProducts(backup.products);
    if (backup.transactions && Array.isArray(backup.transactions)) setTransactions(backup.transactions);
    if (backup.customers && Array.isArray(backup.customers)) setCustomers(backup.customers);
    if (backup.storeSettings) setStoreSettings((prev) => ({ ...prev, ...backup.storeSettings }));
  };

  // Full JSON Backup Restore
  const handleRestoreFullBackup = (backup: FullBackupData) => {
    if (backup.data.products && Array.isArray(backup.data.products)) {
      setProducts(backup.data.products);
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(backup.data.products));
    }
    if (backup.data.transactions && Array.isArray(backup.data.transactions)) {
      setTransactions(backup.data.transactions);
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(backup.data.transactions));
    }
    if (backup.data.customers && Array.isArray(backup.data.customers)) {
      setCustomers(backup.data.customers);
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(backup.data.customers));
    }
    if (backup.data.storeSettings) {
      const merged: StoreSettings = {
        ...storeSettings,
        ...backup.data.storeSettings,
        lastBackupTimestamp: new Date().toISOString(),
      };
      setStoreSettings(merged);
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(merged));
    }
    if (backup.data.cashFlow) {
      if (typeof backup.data.cashFlow.openingAmount === 'number') {
        setOpeningAmount(backup.data.cashFlow.openingAmount);
        localStorage.setItem(STORAGE_KEYS.OPENING_AMOUNT, String(backup.data.cashFlow.openingAmount));
      }
      if (typeof backup.data.cashFlow.addedAmount === 'number') {
        setAddedAmount(backup.data.cashFlow.addedAmount);
        localStorage.setItem(STORAGE_KEYS.ADDED_CASH, String(backup.data.cashFlow.addedAmount));
      }
    }
  };

  const handleOpenSettingsWithTab = (tab: 'upi' | 'inventory' | 'staff' | 'printer' | 'profile' | 'backup' | 'reports' = 'upi') => {
    setSettingsInitialTab(tab);
    setIsSettingsOpen(true);
  };

  return (
    <div className={`min-h-screen flex flex-col font-['Plus_Jakarta_Sans',sans-serif] transition-colors duration-200 ${themeMode === 'light' ? 'bg-slate-100 text-slate-900' : 'bg-slate-950 text-slate-100'}`}>
      {/* Top Application Bar */}
      <TohandsHeader
        storeSettings={storeSettings}
        todaySalesTotal={todaySalesTotal}
        productsCount={products.length}
        pendingUdhaarTotal={pendingUdhaarTotal}
        onOpenPosCatalog={() => setIsPosCatalogOpen(true)}
        onOpenBarcodeScanner={() => setIsBarcodeScannerOpen(true)}
        onOpenUdhaarLedger={() => setIsUdhaarLedgerOpen(true)}
        onOpenReports={() => handleOpenSettingsWithTab('reports')}
        onOpenBillsManager={() => setIsBillsManagerOpen(true)}
        onOpenSettings={handleOpenSettingsWithTab}
        onSwitchStaff={handleSwitchStaff}
        onLogout={handleLogout}
        themeMode={themeMode}
        onToggleTheme={handleToggleTheme}
      />

      {/* Top Cash Addition & Daily Galla Bar (Opening + Added + Physical Cash Sale - Expenses = Cash In Hand) */}
      <TopCashFlowBanner
        openingAmount={openingAmount}
        addedAmount={addedAmount}
        todaySalesTotal={todaySalesTotal}
        todayOnlineSalesTotal={todayOnlineSalesTotal}
        todayUdhaarSalesTotal={todayUdhaarSalesTotal}
        todayExpensesTotal={todayExpensesTotal}
        onOpenExpenseModal={() => setIsExpenseModalOpen(true)}
        onUpdateOpeningAmount={handleUpdateOpeningAmount}
        onAddCashAmount={handleAddCashAmount}
        onResetDailyCash={handleResetDailyCash}
        themeMode={themeMode}
      />

      {/* Main Work Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 flex flex-col lg:flex-row items-start justify-center gap-6">
        {/* Primary Column: NAYAB Smart Calculator + Bill Tape + Inventory Search */}
        <div className="w-full lg:w-[580px] xl:w-[620px] flex-shrink-0">
          <TohandsCalculator
            onOpenSale={handleOpenSale}
            onOpenExpense={handleOpenExpense}
            onOpenUpiQr={handleOpenUpiQr}
            onOpenPosCatalog={() => setIsPosCatalogOpen(true)}
            activeBillCount={billItems.length}
            activeBillTotal={billGrandTotal}
            defaultTaxRate={storeSettings.defaultTaxRate}
            products={products}
            onAddItemToBill={handleAddItemToBill}
            onSelectProductForWeight={(product) => setQuickWeightProduct(product)}
            onUpdateProduct={handleUpdateProduct}
            onOpenBarcodeScanner={() => setIsBarcodeScannerOpen(true)}
            activeBillItems={billItems}
            onUpdateItemQuantity={handleUpdateItemQuantity}
            onRemoveItem={handleRemoveItem}
            onClearBill={handleClearBill}
            onQuickPrintBill={handleQuickPrintSlip}
            onAddProductToInventory={handleAddProductToInventory}
          />
        </div>

        {/* Right Column: Fast Moving Kirana Products & Web Product Search */}
        <div className="w-full lg:flex-1 space-y-4">
          {/* Quick Shortcuts & Fast Kirana Items (6 on Display + Vertical Scrolling) */}
          <div className="bg-slate-900/70 rounded-3xl p-4 border border-slate-800 space-y-3 shadow-sm">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Fast Moving Kirana Masale
                </span>
                <span className="text-[10px] bg-purple-500/20 text-purple-300 font-semibold px-2 py-0.5 rounded-full border border-purple-500/30">
                  6 on Display
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                {/* Vertical Scroll Controls */}
                <div className="flex items-center gap-1 bg-slate-800/80 p-0.5 rounded-xl border border-slate-700/80">
                  <button
                    onClick={() => handleScrollFastMoving('up')}
                    className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition-colors"
                    title="Scroll Up"
                  >
                    <ChevronUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleScrollFastMoving('down')}
                    className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition-colors"
                    title="Scroll Down"
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={() => setIsPosCatalogOpen(true)}
                  className="text-xs font-semibold text-purple-400 hover:text-purple-300 ml-1 hidden sm:inline"
                >
                  All ({products.length}) →
                </button>
              </div>
            </div>

            {/* Fast Moving Products Grid: Exactly 6 on display, remaining items scroll vertically */}
            {(() => {
              const fastMovingItems = products.filter((p) => p.popular).length >= 6
                ? products.filter((p) => p.popular)
                : products;

              return (
                <div className="space-y-2">
                  <div
                    ref={fastMovingScrollRef}
                    className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[164px] sm:max-h-[170px] overflow-y-auto pr-1 select-none scroll-smooth"
                    style={{ scrollbarWidth: 'thin' }}
                  >
                    {fastMovingItems.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => setQuickWeightProduct(p)}
                        className="p-2.5 rounded-2xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 hover:border-purple-500/60 text-left transition-all group shadow-sm flex flex-col justify-between"
                      >
                        <div>
                          <div className="font-semibold text-xs text-white truncate group-hover:text-purple-300">
                            {p.name}
                          </div>
                          {p.hindiName && (
                            <div className="text-[10px] text-amber-300/80 truncate mt-0.5">{p.hindiName}</div>
                          )}
                        </div>
                        <div className="flex items-center justify-between mt-2 pt-1 border-t border-slate-700/50 text-[11px]">
                          <span className="font-mono font-bold text-emerald-400">₹{p.rate}</span>
                          <span className="text-[10px] text-slate-400">/{p.unit}</span>
                        </div>
                      </button>
                    ))}
                  </div>

                  {fastMovingItems.length > 6 && (
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/80">
                      <span>Showing 6 items on display</span>
                      <button
                        onClick={() => handleScrollFastMoving('down')}
                        className="flex items-center gap-1 text-purple-400 hover:text-purple-300 font-semibold transition-colors"
                      >
                        <span>Scroll vertically for {fastMovingItems.length - 6} more</span>
                        <ArrowDown className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })()}
          </div>

          {/* Search from Web component placed directly below Fast Moving Products */}
          <WebProductSearch
            existingProducts={products}
            onAddProductToInventory={handleAddProductToInventory}
            onSelectProductForBill={(p, customQty) => {
              if (customQty && customQty > 0) {
                handleAddItemToBill({
                  productId: p.id,
                  name: p.name,
                  hindiName: p.hindiName,
                  rate: p.rate,
                  quantity: customQty,
                  unit: p.unit,
                  total: Math.round(p.rate * customQty * 100) / 100,
                });
              } else {
                setQuickWeightProduct(p);
              }
            }}
          />
        </div>
      </main>

      {/* POS Catalog Drawer (with Web Item Search & Editable Rates/Stock & 1.5M Capacity) */}
      <PosCatalogDrawer
        isOpen={isPosCatalogOpen}
        onClose={() => setIsPosCatalogOpen(false)}
        products={products}
        onAddProductToInventory={handleAddProductToInventory}
        onBulkAddProducts={handleBulkAddProducts}
        onAddItemToBill={handleAddItemToBill}
        onUpdateProduct={handleUpdateProduct}
      />

      {/* Sale Settlement Modal with Thermal Printer support */}
      <SalePaymentModal
        isOpen={isSaleModalOpen}
        onClose={() => setIsSaleModalOpen(false)}
        initialAmount={activeModalAmount}
        billItems={billItems}
        storeSettings={storeSettings}
        customers={customers}
        onCompleteSale={handleCompleteSale}
      />

      {/* Expense Modal */}
      <ExpenseModal
        isOpen={isExpenseModalOpen}
        onClose={() => setIsExpenseModalOpen(false)}
        initialAmount={activeModalAmount}
        onRecordExpense={handleRecordExpense}
      />

      {/* Instant UPI QR Modal */}
      <QuickUpiQrModal
        isOpen={isUpiQrModalOpen}
        onClose={() => setIsUpiQrModalOpen(false)}
        initialAmount={activeModalAmount}
        storeSettings={storeSettings}
        onRecordSaleAsUpi={handleRecordQuickUpiSale}
      />

      {/* Customer Udhaar Khata Modal */}
      <UdhaarLedgerModal
        isOpen={isUdhaarLedgerOpen}
        onClose={() => setIsUdhaarLedgerOpen(false)}
        customers={customers}
        onSettlePayment={handleSettleCustomerUdhaar}
        onAddCustomer={handleAddCustomer}
        storeSettings={storeSettings}
      />

      {/* Scrolling Business Reports & Analytics Dashboard Modal */}
      <ReportsDashboardModal
        isOpen={isReportsOpen}
        onClose={() => setIsReportsOpen(false)}
        transactions={transactions}
        customers={customers}
        products={products}
        storeSettings={storeSettings}
        onImportBackup={handleImportBackup}
        onOpenSettings={handleOpenSettingsWithTab}
      />

      {/* Store Profile, UPI, Inventory, Staff, Thermal Printer & Full Data Backup Settings Modal */}
      <StoreSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={storeSettings}
        products={products}
        transactions={transactions}
        customers={customers}
        cashFlow={{ openingAmount, addedAmount }}
        onSaveSettings={setStoreSettings}
        onUpdateProduct={handleUpdateProduct}
        onAddProduct={handleAddProductToInventory}
        onBulkAddProducts={handleBulkAddProducts}
        onClearAllProducts={handleClearAllProducts}
        onDeleteProduct={handleDeleteProduct}
        onRestoreFullBackup={handleRestoreFullBackup}
        onOpenBillsManager={() => setIsBillsManagerOpen(true)}
        initialTab={settingsInitialTab}
        isOwner={isOwner}
        activeStaff={currentActiveStaff}
      />

      {/* Bills & Transactions Manager (Owner Only: Search, Edit Cash/Online/Udhaar bills & Expenses) */}
      <BillsManagementModal
        isOpen={isBillsManagerOpen}
        onClose={() => setIsBillsManagerOpen(false)}
        transactions={transactions}
        customers={customers}
        storeSettings={storeSettings}
        onUpdateTransaction={handleUpdateTransaction}
        onDeleteTransaction={handleDeleteTransaction}
      />

      {/* Staff & Owner Initial Login Popup Modal */}
      <AuthLoginModal
        isOpen={isLoginModalOpen || !isAuthenticated}
        onClose={() => {
          if (isAuthenticated) {
            setIsLoginModalOpen(false);
          }
        }}
        settings={storeSettings}
        onLoginSuccess={handleLoginSuccess}
        canDismiss={isAuthenticated}
      />

      {/* Quick Custom Weight & Quantity Modal (No pre-added forced quantity) */}
      {quickWeightProduct && (
        <CustomWeightModal
          isOpen={Boolean(quickWeightProduct)}
          onClose={() => setQuickWeightProduct(null)}
          product={quickWeightProduct}
          onConfirmAdd={handleAddItemToBill}
        />
      )}

      {/* POS Camera Barcode Scanner Modal */}
      <PosBarcodeScannerModal
        isOpen={isBarcodeScannerOpen}
        onClose={() => setIsBarcodeScannerOpen(false)}
        products={products}
        onAddItemToBill={handleAddItemToBill}
        onSelectProductForWeight={(product) => {
          setQuickWeightProduct(product);
        }}
        onCreateNewProductWithBarcode={(_barcode) => {
          setIsPosCatalogOpen(true);
        }}
      />
    </div>
  );
}
