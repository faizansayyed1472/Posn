import React, { useState, useEffect } from 'react';
import {
  RotateCcw,
  Delete,
  QrCode,
  Receipt,
  ArrowDownCircle,
  ShoppingBag,
  Volume2,
  VolumeX,
  Percent,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  History,
  Clock,
  Printer,
} from 'lucide-react';
import { playKeySound } from '../utils/audio';
import { Product, BillItem } from '../types';
import { KiranaSpiceItemSearch } from './KiranaSpiceItemSearch';
import { ActiveBillTape } from './ActiveBillTape';
import { PosInventorySearchBar } from './PosInventorySearchBar';

export interface CalcHistoryItem {
  id: string;
  expression: string;
  result: number;
  time: string;
}

interface TohandsCalculatorProps {
  onOpenSale: (currentAmount: number) => void;
  onOpenExpense?: (currentAmount: number) => void;
  onOpenUpiQr: (currentAmount: number) => void;
  onOpenPosCatalog: () => void;
  onQuickPrintBill?: (currentAmount: number) => void;
  activeBillCount: number;
  activeBillTotal: number;
  defaultTaxRate: number;
  products?: Product[];
  activeBillItems?: BillItem[];
  onUpdateItemQuantity?: (id: string, qty: number) => void;
  onUpdateItemQty?: (id: string, qty: number) => void;
  onRemoveItem?: (id: string) => void;
  onClearBill?: () => void;
  onAddItemToBill?: (item: Omit<BillItem, 'id'>) => void;
  onSelectProductForWeight?: (product: Product) => void;
  onUpdateProduct?: (product: Product) => void;
  onAddProductToInventory?: (product: Product) => void;
  onOpenBarcodeScanner?: () => void;
}

export const TohandsCalculator: React.FC<TohandsCalculatorProps> = ({
  onOpenSale,
  onOpenExpense,
  onOpenUpiQr,
  onOpenPosCatalog,
  onQuickPrintBill,
  activeBillCount,
  activeBillTotal,
  defaultTaxRate,
  products,
  activeBillItems,
  onUpdateItemQuantity,
  onUpdateItemQty,
  onRemoveItem,
  onClearBill,
  onAddItemToBill,
  onSelectProductForWeight,
  onUpdateProduct,
  onAddProductToInventory,
  onOpenBarcodeScanner,
}) => {
  const updateItemQty = onUpdateItemQuantity || onUpdateItemQty;
  const [displayValue, setDisplayValue] = useState<string>('0');
  const [prevValue, setPrevValue] = useState<number | null>(null);
  const [operator, setOperator] = useState<'+' | '-' | '*' | '/' | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState<boolean>(false);
  const [formulaTape, setFormulaTape] = useState<string>('');
  const [memory, setMemory] = useState<number>(0);
  const [mrcTapped, setMrcTapped] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [taxRate, setTaxRate] = useState<number>(defaultTaxRate || 5);
  const [taxLabel, setTaxLabel] = useState<string | null>(null);
  const [auditSteps, setAuditSteps] = useState<Array<{ step: number; text: string; val: number }>>([]);
  const [auditStepIdx, setAuditStepIdx] = useState<number | null>(null);
  const [showHistory, setShowHistory] = useState<boolean>(true);

  // Up to 50 calculations history
  const [calcHistory, setCalcHistory] = useState<CalcHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('nayab_calc_history_v1') || localStorage.getItem('tohands_calc_history_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('nayab_calc_history_v1', JSON.stringify(calcHistory.slice(0, 50)));
  }, [calcHistory]);

  const recordCalculation = (expression: string, result: number) => {
    const item: CalcHistoryItem = {
      id: `calc-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      expression,
      result,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };
    setCalcHistory((prev) => [item, ...prev].slice(0, 50));
  };

  // Sync with bill total if bill is active and user hasn't typed a new calculation
  useEffect(() => {
    if (activeBillTotal > 0 && displayValue === '0' && !prevValue) {
      setDisplayValue(activeBillTotal.toFixed(2));
      setFormulaTape(`Cart Total: ₹${activeBillTotal.toFixed(2)}`);
    }
  }, [activeBillTotal]);

  const sound = (type: 'num' | 'op' | 'action' | 'clear' | 'bill') => {
    if (soundEnabled) playKeySound(type);
  };

  // Keyboard navigation support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['input', 'textarea'].includes((e.target as HTMLElement)?.tagName?.toLowerCase())) return;

      if (e.key >= '0' && e.key <= '9') {
        inputDigit(e.key);
      } else if (e.key === '.') {
        inputDot();
      } else if (e.key === '+') {
        inputOperator('+');
      } else if (e.key === '-') {
        inputOperator('-');
      } else if (e.key === '*') {
        inputOperator('*');
      } else if (e.key === '/') {
        e.preventDefault();
        inputOperator('/');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Backspace') {
        handleCorrect();
      } else if (e.key === 'Escape') {
        handleAllClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [displayValue, prevValue, operator, waitingForOperand, formulaTape, auditSteps]);

  const inputDigit = (digit: string) => {
    sound('num');
    setTaxLabel(null);
    setAuditStepIdx(null);

    if (waitingForOperand) {
      setDisplayValue(digit);
      setWaitingForOperand(false);
    } else {
      setDisplayValue(displayValue === '0' ? digit : displayValue + digit);
    }
  };

  const inputDoubleZero = () => {
    sound('num');
    setTaxLabel(null);
    setAuditStepIdx(null);

    if (waitingForOperand) {
      setDisplayValue('0');
      setWaitingForOperand(false);
    } else if (displayValue !== '0') {
      setDisplayValue(displayValue + '00');
    }
  };

  const inputDot = () => {
    sound('num');
    setTaxLabel(null);
    if (waitingForOperand) {
      setDisplayValue('0.');
      setWaitingForOperand(false);
      return;
    }
    if (!displayValue.includes('.')) {
      setDisplayValue(displayValue + '.');
    }
  };

  const inputOperator = (nextOp: '+' | '-' | '*' | '/') => {
    sound('op');
    setTaxLabel(null);
    setAuditStepIdx(null);
    const inputValue = parseFloat(displayValue);

    const opSymbol = nextOp === '*' ? '×' : nextOp === '/' ? '÷' : nextOp;

    if (prevValue === null) {
      setPrevValue(inputValue);
      setFormulaTape(`${inputValue} ${opSymbol}`);
      const newStep = { step: 1, text: `${inputValue} ${opSymbol}`, val: inputValue };
      setAuditSteps([newStep]);
    } else if (operator) {
      const currentValue = prevValue || 0;
      let newValue = currentValue;
      if (operator === '+') newValue = currentValue + inputValue;
      else if (operator === '-') newValue = currentValue - inputValue;
      else if (operator === '*') newValue = currentValue * inputValue;
      else if (operator === '/') newValue = inputValue !== 0 ? currentValue / inputValue : 0;

      // Keep 2 decimals max for cash consistency
      const rounded = Math.round(newValue * 100) / 100;
      setPrevValue(rounded);
      setDisplayValue(String(rounded));
      setFormulaTape(`${rounded} ${opSymbol}`);

      const expr = `${formulaTape || currentValue} ${inputValue}`;
      recordCalculation(expr, rounded);

      const nextStepNum = auditSteps.length + 1;
      setAuditSteps((prev) => [...prev, { step: nextStepNum, text: `${expr} = ${rounded}`, val: rounded }]);
    } else {
      setPrevValue(inputValue);
      setFormulaTape(`${inputValue} ${opSymbol}`);
    }

    setWaitingForOperand(true);
    setOperator(nextOp);
  };

  const handleEquals = () => {
    sound('action');
    const inputValue = parseFloat(displayValue);

    if (prevValue !== null && operator) {
      let newValue = prevValue;
      const opSymbol = operator === '*' ? '×' : operator === '/' ? '÷' : operator;

      if (operator === '+') newValue = prevValue + inputValue;
      else if (operator === '-') newValue = prevValue - inputValue;
      else if (operator === '*') newValue = prevValue * inputValue;
      else if (operator === '/') newValue = inputValue !== 0 ? prevValue / inputValue : 0;

      const rounded = Math.round(newValue * 100) / 100;
      setDisplayValue(String(rounded));
      setFormulaTape(`${prevValue} ${opSymbol} ${inputValue} =`);
      setPrevValue(null);
      setOperator(null);
      setWaitingForOperand(true);

      const expr = `${prevValue} ${opSymbol} ${inputValue}`;
      recordCalculation(expr, rounded);

      const nextStepNum = auditSteps.length + 1;
      setAuditSteps((prev) => [...prev, { step: nextStepNum, text: `${expr} = ${rounded}`, val: rounded }]);
    }
  };

  const handlePercentage = () => {
    sound('op');
    const current = parseFloat(displayValue);
    if (prevValue !== null && (operator === '+' || operator === '-')) {
      // e.g. 500 + 10% = 500 + 50 = 550
      const percentVal = (prevValue * current) / 100;
      setDisplayValue(String(percentVal));
    } else {
      const result = current / 100;
      setDisplayValue(String(result));
    }
  };

  // CORRECT: single-digit backspace
  const handleCorrect = () => {
    sound('clear');
    if (waitingForOperand) return;
    if (displayValue.length > 1) {
      setDisplayValue(displayValue.slice(0, -1));
    } else {
      setDisplayValue('0');
    }
  };

  // C: Clear current entry
  const handleClearEntry = () => {
    sound('clear');
    setDisplayValue('0');
    setTaxLabel(null);
  };

  // AC: All Clear
  const handleAllClear = () => {
    sound('clear');
    setDisplayValue('0');
    setPrevValue(null);
    setOperator(null);
    setWaitingForOperand(false);
    setFormulaTape('');
    setTaxLabel(null);
    setAuditSteps([]);
    setAuditStepIdx(null);
  };

  // TAX+: Add GST rate
  const handleTaxPlus = () => {
    sound('action');
    const val = parseFloat(displayValue);
    if (isNaN(val) || val === 0) return;

    const taxAmount = (val * taxRate) / 100;
    const totalWithTax = Math.round((val + taxAmount) * 100) / 100;

    setDisplayValue(String(totalWithTax));
    setTaxLabel(`TAX+ ${taxRate}% (+₹${taxAmount.toFixed(2)})`);
    setFormulaTape(`${val} + ${taxRate}% Tax =`);
    setWaitingForOperand(true);
  };

  // TAX-: Deduct GST rate (Calculate Base Amount)
  const handleTaxMinus = () => {
    sound('action');
    const val = parseFloat(displayValue);
    if (isNaN(val) || val === 0) return;

    const baseAmount = Math.round((val / (1 + taxRate / 100)) * 100) / 100;
    const taxDeducted = Math.round((val - baseAmount) * 100) / 100;

    setDisplayValue(String(baseAmount));
    setTaxLabel(`TAX- ${taxRate}% (Base: ₹${baseAmount}, Tax: ₹${taxDeducted})`);
    setFormulaTape(`${val} - ${taxRate}% Base =`);
    setWaitingForOperand(true);
  };

  // Memory Operations
  const handleMemoryAdd = () => {
    sound('action');
    const val = parseFloat(displayValue);
    setMemory((m) => m + val);
    setMrcTapped(false);
    setWaitingForOperand(true);
  };

  const handleMemorySubtract = () => {
    sound('action');
    const val = parseFloat(displayValue);
    setMemory((m) => m - val);
    setMrcTapped(false);
    setWaitingForOperand(true);
  };

  const handleMrc = () => {
    sound('action');
    if (!mrcTapped) {
      // First tap: Recall memory
      setDisplayValue(String(memory));
      setWaitingForOperand(true);
      setMrcTapped(true);
    } else {
      // Second tap: Clear memory
      setMemory(0);
      setMrcTapped(false);
    }
  };

  // Check & Correct step verification
  const handleCheckPrev = () => {
    sound('op');
    if (auditSteps.length === 0) return;
    const nextIdx = auditStepIdx === null ? auditSteps.length - 1 : Math.max(0, auditStepIdx - 1);
    setAuditStepIdx(nextIdx);
    const step = auditSteps[nextIdx];
    setDisplayValue(String(step.val));
    setFormulaTape(`STEP ${step.step}/${auditSteps.length}: ${step.text}`);
  };

  const handleCheckNext = () => {
    sound('op');
    if (auditSteps.length === 0 || auditStepIdx === null) return;
    const nextIdx = Math.min(auditSteps.length - 1, auditStepIdx + 1);
    setAuditStepIdx(nextIdx);
    const step = auditSteps[nextIdx];
    setDisplayValue(String(step.val));
    setFormulaTape(`STEP ${step.step}/${auditSteps.length}: ${step.text}`);
  };

  const currentNumericTotal = parseFloat(displayValue) || activeBillTotal || 0;

  return (
    <div className="w-full max-w-xl mx-auto space-y-3">
      {/* 5. Purple Section: POS Search Bar from Inventory with Web Search Fallback */}
      <PosInventorySearchBar
        products={products || []}
        onAddItemToBill={onAddItemToBill}
        onSelectProductForWeight={onSelectProductForWeight}
        onOpenPosCatalog={onOpenPosCatalog}
        onOpenBarcodeScanner={onOpenBarcodeScanner}
        onAddProductToInventory={onAddProductToInventory}
      />

      {/* Main NAYAB Calculator Hardware Body */}
      <div className="w-full bg-gradient-to-b from-slate-900 via-slate-925 to-slate-950 rounded-3xl p-4 sm:p-6 shadow-2xl border border-slate-800 ring-1 ring-slate-800/80">
        {/* Casing Brand Header & Hardware Indicators */}
        <div className="flex items-center justify-between pb-3 px-1 border-b border-slate-800/80 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50 animate-pulse"></div>
            <span className="font-extrabold text-white tracking-widest text-sm">NAYAB</span>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-cyan-400 font-mono font-semibold border border-slate-700">
              SMART BIZ 12D
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Tax selector pill */}
            <div className="flex items-center gap-1 bg-slate-800/90 px-2 py-0.5 rounded-md border border-slate-700/60 text-[11px]">
              <span className="text-slate-400">GST:</span>
              <select
                value={taxRate}
                onChange={(e) => setTaxRate(Number(e.target.value))}
                className="bg-transparent text-amber-300 font-bold focus:outline-none cursor-pointer"
              >
                <option value={0} className="bg-slate-900 text-white">0%</option>
                <option value={5} className="bg-slate-900 text-white">5%</option>
                <option value={12} className="bg-slate-900 text-white">12%</option>
                <option value={18} className="bg-slate-900 text-white">18%</option>
                <option value={28} className="bg-slate-900 text-white">28%</option>
              </select>
            </div>

            {/* Sound Toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title={soundEnabled ? 'Mute Keypad Sound' : 'Enable Keypad Sound'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-600" />}
            </button>
          </div>
        </div>

        {/* Retro LCD Screen Bezel */}
        <div className="mt-3 bg-stone-900 p-3.5 sm:p-4 rounded-2xl border-2 border-stone-800 shadow-inner relative overflow-hidden">
          {/* Subtle LCD green glass background glow */}
          <div className="absolute inset-0 bg-emerald-950/20 pointer-events-none"></div>

          {/* Top Formula Tape / State Bar */}
          <div className="relative flex items-center justify-between text-[11px] sm:text-xs font-mono text-emerald-400/80 min-h-[22px] pb-1 border-b border-emerald-900/30">
            <div className="flex items-center gap-2 truncate">
              {memory !== 0 && (
                <span className="bg-emerald-400/20 text-emerald-300 px-1 rounded font-bold">M</span>
              )}
              {taxLabel && (
                <span className="text-amber-300 bg-amber-400/10 px-1.5 rounded font-medium">{taxLabel}</span>
              )}
              <span className="truncate text-emerald-300 font-bold">
                {prevValue !== null && operator
                  ? `${prevValue} ${operator === '*' ? '×' : operator === '/' ? '÷' : operator} ${waitingForOperand ? '' : displayValue}`
                  : formulaTape || 'READY'}
              </span>
            </div>

            <div className="flex items-center gap-2 flex-shrink-0 text-[10px] text-emerald-400/70">
              <button
                onClick={() => setShowHistory(!showHistory)}
                className="flex items-center gap-1 text-emerald-300 hover:text-white bg-emerald-950/70 px-1.5 py-0.5 rounded border border-emerald-800/60 transition-colors"
                title="Toggle last 50 calculations history tape"
              >
                <History className="w-3 h-3" />
                <span>History ({calcHistory.length}/50)</span>
              </button>
              {auditSteps.length > 0 && (
                <span>STEP {auditStepIdx !== null ? auditStepIdx + 1 : auditSteps.length}/{auditSteps.length}</span>
              )}
              <span>12-DIGIT</span>
            </div>
          </div>

        {/* Main Digital Readout */}
        <div className="relative mt-2 text-right">
          <div className="text-3xl sm:text-4xl lg:text-5xl font-['Share_Tech_Mono',monospace] tracking-wider text-emerald-300 font-bold drop-shadow-[0_0_12px_rgba(52,211,153,0.3)] truncate select-all">
            <span className="text-emerald-500/60 text-2xl sm:text-3xl mr-1 font-sans">₹</span>
            {displayValue}
          </div>
        </div>

        {/* Active POS items indicator banner inside display */}
        {activeBillCount > 0 && (
          <div className="mt-2 pt-1.5 border-t border-emerald-900/40 flex items-center justify-between text-[11px] text-emerald-300 font-sans">
            <span className="flex items-center gap-1">
              <ShoppingBag className="w-3.5 h-3.5 text-emerald-400" />
              <span>Bill Items in Cart: <strong>{activeBillCount}</strong></span>
            </span>
            <span className="font-semibold text-emerald-400">Total: ₹{activeBillTotal.toFixed(2)}</span>
          </div>
        )}
      </div>

      {/* Last 50 Calculations History Tape */}
      {showHistory && (
        <div className="mt-2.5 p-2.5 bg-stone-950/90 border border-emerald-900/50 rounded-2xl font-mono text-xs shadow-inner">
          <div className="flex items-center justify-between text-[11px] text-emerald-400 pb-1.5 border-b border-stone-800/80">
            <span className="flex items-center gap-1.5 font-semibold">
              <History className="w-3.5 h-3.5 text-cyan-400" />
              <span>Calculation History Tape (Last 50)</span>
            </span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-stone-400 hidden sm:inline">Tap row to reload</span>
              {calcHistory.length > 0 && (
                <button
                  onClick={() => setCalcHistory([])}
                  className="text-[10px] text-stone-500 hover:text-red-400 transition-colors"
                  title="Clear history tape"
                >
                  Clear ({calcHistory.length})
                </button>
              )}
            </div>
          </div>

          {calcHistory.length === 0 ? (
            <div className="py-2.5 text-center text-stone-500 text-[11px]">
              No calculation history yet. Perform additions, subtractions or tap '=' to save.
            </div>
          ) : (
            <div className="space-y-1.5 mt-1.5 max-h-52 overflow-y-auto pr-1">
              {calcHistory.map((item, idx) => (
                <button
                  key={item.id}
                  onClick={() => {
                    sound('num');
                    setDisplayValue(String(item.result));
                    setFormulaTape(`Recalled: ${item.expression}`);
                  }}
                  className="w-full flex items-center justify-between py-1 px-2 rounded-lg bg-stone-900/90 hover:bg-stone-800 border border-stone-800/60 hover:border-emerald-500/50 text-left transition-all group"
                  title="Click to load result into calculator"
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="text-[10px] text-stone-500 font-bold w-5">#{idx + 1}</span>
                    <span className="text-stone-300 group-hover:text-emerald-300 truncate font-medium">
                      {item.expression}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                    <span className="font-bold text-emerald-400 font-mono">= ₹{item.result.toFixed(2)}</span>
                    <span className="text-[9px] text-stone-500 flex items-center gap-0.5">
                      <Clock className="w-2.5 h-2.5" />
                      {item.time}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Function & Memory Row */}
      <div className="grid grid-cols-5 gap-2 mt-3 text-xs font-bold">
        <button
          onClick={handleTaxMinus}
          className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 active:scale-95 text-amber-300 border border-slate-700/80 shadow-sm transition-all"
          title="Calculate Base without Tax"
        >
          TAX-
        </button>
        <button
          onClick={handleTaxPlus}
          className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 active:scale-95 text-amber-300 border border-slate-700/80 shadow-sm transition-all"
          title="Add Tax percentage"
        >
          TAX+
        </button>
        <button
          onClick={handleMrc}
          className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 active:scale-95 text-cyan-300 border border-slate-700/80 shadow-sm transition-all"
          title="Memory Recall / Clear"
        >
          MRC
        </button>
        <button
          onClick={handleMemorySubtract}
          className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 active:scale-95 text-cyan-300 border border-slate-700/80 shadow-sm transition-all"
          title="Memory Subtract"
        >
          M-
        </button>
        <button
          onClick={handleMemoryAdd}
          className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 active:scale-95 text-cyan-300 border border-slate-700/80 shadow-sm transition-all"
          title="Memory Add"
        >
          M+
        </button>
      </div>

      {/* Check & Step Verification Row */}
      <div className="grid grid-cols-5 gap-2 mt-2 text-xs font-bold">
        <button
          onClick={handleCheckPrev}
          className="py-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 active:scale-95 text-slate-300 border border-slate-700 flex items-center justify-center gap-0.5"
          title="Audit Previous Step"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
          <span>CHECK</span>
        </button>
        <button
          onClick={handleCheckNext}
          className="py-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 active:scale-95 text-slate-300 border border-slate-700 flex items-center justify-center gap-0.5"
          title="Audit Next Step"
        >
          <span>CHECK</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={handleCorrect}
          className="py-2 rounded-xl bg-slate-800 hover:bg-slate-750 active:scale-95 text-red-300 border border-slate-700 flex items-center justify-center gap-1"
          title="Backspace single digit"
        >
          <Delete className="w-3.5 h-3.5" />
          <span>CORRECT</span>
        </button>
        <button
          onClick={handleClearEntry}
          className="py-2 rounded-xl bg-slate-800 hover:bg-slate-750 active:scale-95 text-orange-400 border border-slate-700"
          title="Clear current input"
        >
          C
        </button>
        <button
          onClick={handleAllClear}
          className="py-2 rounded-xl bg-red-950/60 hover:bg-red-900/80 active:scale-95 text-red-300 border border-red-800/60"
          title="All Clear Reset"
        >
          AC
        </button>
      </div>

      {/* Numerical Keypad & Math Operators */}
      <div className="grid grid-cols-4 gap-2.5 mt-3 text-lg sm:text-xl font-bold font-mono">
        {/* Row 1 */}
        <button
          onClick={() => inputDigit('7')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          7
        </button>
        <button
          onClick={() => inputDigit('8')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          8
        </button>
        <button
          onClick={() => inputDigit('9')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          9
        </button>
        <button
          onClick={() => inputOperator('/')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-cyan-400 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all text-2xl font-sans"
        >
          ÷
        </button>

        {/* Row 2 */}
        <button
          onClick={() => inputDigit('4')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          4
        </button>
        <button
          onClick={() => inputDigit('5')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          5
        </button>
        <button
          onClick={() => inputDigit('6')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          6
        </button>
        <button
          onClick={() => inputOperator('*')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-cyan-400 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all text-2xl font-sans"
        >
          ×
        </button>

        {/* Row 3 */}
        <button
          onClick={() => inputDigit('1')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          1
        </button>
        <button
          onClick={() => inputDigit('2')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          2
        </button>
        <button
          onClick={() => inputDigit('3')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          3
        </button>
        <button
          onClick={() => inputOperator('-')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-cyan-400 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all text-3xl font-sans"
        >
          -
        </button>

        {/* Row 4 */}
        <button
          onClick={() => inputDigit('0')}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all"
        >
          0
        </button>
        <button
          onClick={inputDoubleZero}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all text-base"
        >
          00
        </button>
        <button
          onClick={inputDot}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-100 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all text-2xl font-sans"
        >
          .
        </button>
        {/* Massive Double-Height Plus Key (+ बड़ा जोड़ बटन) */}
        <button
          onClick={() => inputOperator('+')}
          className="row-span-2 h-full min-h-[122px] sm:min-h-[138px] rounded-2xl bg-gradient-to-b from-cyan-600 via-cyan-700 to-cyan-800 hover:from-cyan-500 hover:to-cyan-700 active:scale-95 text-white shadow-xl shadow-cyan-950/80 border-2 border-cyan-300 flex items-center justify-center transition-all text-4xl sm:text-5xl font-black font-sans cursor-pointer"
          title="Plus Addition Key (+ बड़ा जोड़ बटन - High Frequency)"
        >
          +
        </button>

        {/* Row 5: Percentage & Large Equals Key */}
        <button
          onClick={handlePercentage}
          className="h-14 sm:h-16 rounded-2xl bg-slate-800 hover:bg-slate-750 text-cyan-400 shadow-md border border-slate-700 flex items-center justify-center active:scale-95 transition-all font-mono font-bold text-xl"
        >
          %
        </button>

        <button
          onClick={handleEquals}
          className="col-span-2 h-14 sm:h-16 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 active:scale-98 text-white shadow-xl shadow-blue-950/80 border border-blue-400/40 flex items-center justify-center text-3xl font-sans font-bold transition-all"
        >
          =
        </button>
      </div>

      {/* Prominent NAYAB Smart Business Action Buttons at the Bottom */}
      <div className="grid grid-cols-4 gap-2 mt-3.5 pt-3 border-t border-slate-800/80">
        {/* SALE / BILL KEY (Green) */}
        <button
          id="btn-nayab-sale-bill"
          onClick={() => {
            sound('bill');
            onOpenSale(currentNumericTotal);
          }}
          className="col-span-2 py-3 px-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-98 text-white font-bold rounded-2xl shadow-lg shadow-emerald-950/80 border border-emerald-400/40 flex items-center justify-center gap-2 text-sm sm:text-base transition-all group cursor-pointer"
        >
          <Receipt className="w-5 h-5 text-emerald-200 group-hover:scale-110 transition-transform" />
          <div className="text-left leading-tight">
            <div className="font-extrabold tracking-wide">SALE / BILL</div>
            <div className="text-[10px] text-emerald-100 font-normal">Settle & Receipt</div>
          </div>
        </button>

        {/* PRINT BILL KEY (Blue) - In place of expenses button */}
        <button
          id="btn-nayab-print-bill"
          onClick={() => {
            sound('bill');
            if (onQuickPrintBill) {
              onQuickPrintBill(currentNumericTotal);
            }
          }}
          className="py-3 px-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 active:scale-98 text-white font-bold rounded-2xl shadow-lg shadow-blue-950/80 border border-blue-400/40 flex flex-col items-center justify-center text-xs transition-all cursor-pointer"
          title="Print Bill Slip with Dynamic UPI QR Code (प्रिंट बिल)"
        >
          <Printer className="w-4 h-4 text-blue-200 mb-0.5" />
          <span className="font-extrabold tracking-wide">PRINT BILL</span>
          <span className="text-[9px] text-blue-100 font-normal">Slip + QR</span>
        </button>

        {/* UPI QR KEY (Electric Blue) */}
        <button
          id="btn-nayab-upi-qr"
          onClick={() => {
            sound('action');
            onOpenUpiQr(currentNumericTotal);
          }}
          className="py-3 px-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 active:scale-98 text-white font-bold rounded-2xl shadow-lg shadow-cyan-950/80 border border-cyan-400/40 flex flex-col items-center justify-center text-xs transition-all cursor-pointer"
        >
          <QrCode className="w-4 h-4 text-cyan-200 mb-0.5" />
          <span>UPI QR</span>
          <span className="text-[9px] text-cyan-100 font-normal">Scan & Pay</span>
        </button>
      </div>
    </div>

      {/* 4. Current Bill Tape - PLACED DIRECTLY BELOW SALE BILL BUTTON */}
      {activeBillItems && updateItemQty && onRemoveItem && onClearBill && (
        <div className="mt-4 pt-3 border-t border-slate-800">
          <ActiveBillTape
            items={activeBillItems}
            onUpdateItemQuantity={updateItemQty}
            onRemoveItem={onRemoveItem}
            onClearBill={onClearBill}
            onProceedToSale={() => onOpenSale(currentNumericTotal)}
            onOpenPosCatalog={onOpenPosCatalog}
            onOpenBarcodeScanner={onOpenBarcodeScanner}
            onPrintBill={onQuickPrintBill ? () => onQuickPrintBill(currentNumericTotal) : undefined}
            taxRate={taxRate}
          />
        </div>
      )}

      {/* 4. Select Kirana and Spice Inventory Item Search - PLACED BELOW CURRENT BILL TAPE */}
      {products && onAddItemToBill && onSelectProductForWeight && onUpdateProduct && (
        <div className="mt-4 pt-3 border-t border-slate-800">
          <KiranaSpiceItemSearch
            products={products}
            onAddItemToBill={onAddItemToBill}
            onSelectProductForWeight={onSelectProductForWeight}
            onUpdateProduct={onUpdateProduct}
            onOpenPosCatalog={onOpenPosCatalog}
            onOpenBarcodeScanner={onOpenBarcodeScanner}
          />
        </div>
      )}
    </div>
  );
};

export const NayabCalculator = TohandsCalculator;
