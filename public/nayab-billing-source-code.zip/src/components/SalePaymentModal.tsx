import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  X,
  Receipt,
  CheckCircle,
  Banknote,
  QrCode,
  BookOpen,
  User,
  Phone,
  Printer,
  Share2,
  AlertCircle,
  Shield,
} from 'lucide-react';
import { BillItem, PaymentMode, StoreSettings, CustomerUdhaar, Transaction } from '../types';
import { playKeySound } from '../utils/audio';
import { printReceipt, ThermalReceiptData } from '../utils/printer';

interface SalePaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialAmount: number;
  billItems: BillItem[];
  storeSettings: StoreSettings;
  customers: CustomerUdhaar[];
  onCompleteSale: (transaction: Omit<Transaction, 'id' | 'receiptNumber' | 'timestamp'>) => void;
}

export const SalePaymentModal: React.FC<SalePaymentModalProps> = ({
  isOpen,
  onClose,
  initialAmount,
  billItems,
  storeSettings,
  customers,
  onCompleteSale,
}) => {
  const [amount, setAmount] = useState<number>(initialAmount);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('cash');
  const [cashTendered, setCashTendered] = useState<number>(initialAmount);
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [savedReceiptNo, setSavedReceiptNo] = useState<string>('');
  const [printStatus, setPrintStatus] = useState<string>('');

  const activeStaff = storeSettings.staffAccounts.find((s) => s.id === storeSettings.activeStaffId);

  useEffect(() => {
    setAmount(initialAmount);
    setCashTendered(initialAmount);
    setIsCompleted(false);
    setPrintStatus('');
  }, [initialAmount, isOpen]);

  // Generate dynamic UPI QR Code whenever UPI payment mode or amount is active
  useEffect(() => {
    if (paymentMode === 'online_upi' && amount > 0) {
      const receiptNo = `NB-${Date.now().toString().slice(-6)}`;
      const upiUrl = `upi://pay?pa=${encodeURIComponent(
        storeSettings.upiId || 'nayabmasale@upi'
      )}&pn=${encodeURIComponent(
        storeSettings.upiName || storeSettings.shopName
      )}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Bill ' + receiptNo)}`;

      QRCode.toDataURL(upiUrl, {
        width: 240,
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      })
        .then((url) => setQrDataUrl(url))
        .catch((err) => console.error('QR generation error:', err));
    }
  }, [paymentMode, amount, storeSettings]);

  if (!isOpen) return null;

  const changeDue = Math.max(0, Math.round((cashTendered - amount) * 100) / 100);

  const handleCustomerSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const custId = e.target.value;
    setSelectedCustomerId(custId);
    const found = customers.find((c) => c.id === custId);
    if (found) {
      setCustomerName(found.name);
      setCustomerPhone(found.phone);
    }
  };

  const executePrintReceipt = async (receiptNo: string) => {
    setPrintStatus('Sending receipt to thermal printer...');
    const receiptData: ThermalReceiptData = {
      shopName: storeSettings.shopName,
      address: storeSettings.address,
      phone: storeSettings.phone,
      gstin: storeSettings.gstin,
      receiptNumber: receiptNo,
      date: new Date().toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' }),
      cashierName: activeStaff?.name || 'Cashier',
      customerName: customerName.trim() || undefined,
      items:
        billItems.length > 0
          ? billItems
          : [{ id: 'm1', name: 'Manual Counter Sale', quantity: 1, unit: 'packet', rate: amount, total: amount }],
      subtotal: amount / (1 + storeSettings.defaultTaxRate / 100),
      taxAmount: (amount * storeSettings.defaultTaxRate) / (100 + storeSettings.defaultTaxRate),
      taxRate: storeSettings.defaultTaxRate,
      grandTotal: amount,
      paymentMode,
      upiId: storeSettings.upiId,
    };

    const res = await printReceipt(receiptData, storeSettings);
    if (res.success) {
      setPrintStatus(`Receipt printed via ${res.method}!`);
    } else {
      setPrintStatus(res.error || 'Receipt print error.');
    }
  };

  const handleFinishSale = () => {
    if (amount <= 0) return;
    if (paymentMode === 'credit_udhaar' && !customerName.trim()) {
      alert('Please enter Customer Name for Udhaar / Khata entry.');
      return;
    }

    playKeySound('bill');
    const newReceiptNo = `NB-${Date.now().toString().slice(-6)}`;

    onCompleteSale({
      type: 'sale',
      amount,
      baseAmount: amount / (1 + storeSettings.defaultTaxRate / 100),
      taxAmount: (amount * storeSettings.defaultTaxRate) / (100 + storeSettings.defaultTaxRate),
      taxRate: storeSettings.defaultTaxRate,
      paymentMode,
      customerName: customerName.trim() || undefined,
      customerPhone: customerPhone.trim() || undefined,
      customerId: selectedCustomerId || undefined,
      staffName: activeStaff?.name,
      staffId: activeStaff?.id,
      remarks: remarks.trim() || undefined,
      items: billItems.length > 0 ? billItems : undefined,
    });

    setIsCompleted(true);
    setSavedReceiptNo(newReceiptNo);

    // Auto-print thermal receipt if enabled in printer config
    if (storeSettings.printerConfig?.autoPrintOnSale) {
      executePrintReceipt(newReceiptNo);
    }
  };

  // WhatsApp bill receipt sharing link
  const generateWhatsAppShareUrl = () => {
    let text = `*${storeSettings.shopName}*\n${storeSettings.address}\nPh: ${storeSettings.phone}\n`;
    text += `--------------------------\n`;
    text += `*Bill / Receipt:* ${savedReceiptNo || 'NB-' + Date.now().toString().slice(-6)}\n`;
    text += `*Date:* ${new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}\n`;
    if (activeStaff) text += `*Cashier:* ${activeStaff.name}\n`;
    if (customerName) text += `*Customer:* ${customerName}\n`;
    text += `--------------------------\n`;

    if (billItems.length > 0) {
      billItems.forEach((item, idx) => {
        text += `${idx + 1}. ${item.name} (${item.quantity}${item.unit}) = ₹${item.total.toFixed(2)}\n`;
      });
      text += `--------------------------\n`;
    }

    text += `*Total Amount:* ₹${amount.toFixed(2)}\n`;
    text += `*Payment Mode:* ${paymentMode.toUpperCase()}\n`;
    if (paymentMode === 'credit_udhaar') {
      text += `*Status:* Added to Udhaar Khata\n`;
    } else {
      text += `*Status:* PAID (Dhanyawad / Thank you!)\n`;
    }

    const cleanPhone = customerPhone.replace(/[^0-9]/g, '');
    const phoneParam = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    return `https://api.whatsapp.com/send?phone=${phoneParam}&text=${encodeURIComponent(text)}`;
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/95">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center">
              <Receipt className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Settle Bill / Sale</h3>
              <p className="text-xs text-slate-400">
                {storeSettings.shopName} {activeStaff && `• Cashier: ${activeStaff.name}`}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {isCompleted ? (
            /* Success Receipt Screen */
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center">
                <CheckCircle className="w-10 h-10" />
              </div>

              <div>
                <h4 className="text-lg font-bold text-white">Bill Recorded Successfully!</h4>
                <p className="text-xs text-slate-400 mt-0.5">Receipt #{savedReceiptNo}</p>
              </div>

              {printStatus && (
                <div className="text-[11px] font-semibold text-cyan-300 bg-cyan-950/60 p-2 rounded-xl border border-cyan-800/80 max-w-sm mx-auto">
                  {printStatus}
                </div>
              )}

              <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700 max-w-sm mx-auto text-left text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Bill Amount:</span>
                  <span className="font-bold text-emerald-400 font-mono text-base">₹{amount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Payment Mode:</span>
                  <span className="font-semibold text-white uppercase">{paymentMode.replace('_', ' ')}</span>
                </div>
                {activeStaff && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Cashier:</span>
                    <span className="text-slate-200">{activeStaff.name}</span>
                  </div>
                )}
                {customerName && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Customer:</span>
                    <span className="text-slate-200">{customerName}</span>
                  </div>
                )}
                {paymentMode === 'credit_udhaar' && (
                  <div className="p-2 bg-amber-500/10 border border-amber-500/30 rounded-lg text-amber-300 text-[11px]">
                    Added to {customerName}'s Udhaar Khata ledger.
                  </div>
                )}
              </div>

              {/* Share & Print Actions */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
                <button
                  onClick={() => executePrintReceipt(savedReceiptNo)}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Thermal Receipt</span>
                </button>

                <a
                  href={generateWhatsAppShareUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Send WhatsApp Bill</span>
                </a>

                <button
                  onClick={onClose}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-bold transition-colors"
                >
                  Done (New Bill)
                </button>
              </div>
            </div>
          ) : (
            /* Active Settlement Form */
            <>
              {/* Grand Total Amount Display */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">Final Sale Amount</span>
                  <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-400">
                    ₹{amount.toFixed(2)}
                  </div>
                </div>

                <div className="text-right text-xs text-slate-400">
                  <span>{billItems.length > 0 ? `${billItems.length} items from POS` : 'Keypad Amount'}</span>
                  {storeSettings.defaultTaxRate > 0 && (
                    <div className="text-amber-400/90 text-[11px]">
                      Incl. {storeSettings.defaultTaxRate}% GST
                    </div>
                  )}
                </div>
              </div>

              {/* Payment Mode Selector Tabs */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Select Payment Method:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMode('cash')}
                    className={`py-2.5 px-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 border transition-all ${
                      paymentMode === 'cash'
                        ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500 shadow-md ring-1 ring-emerald-500/50'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-750'
                    }`}
                  >
                    <Banknote className="w-4 h-4 text-emerald-400" />
                    <span>CASH (नकद)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMode('online_upi')}
                    className={`py-2.5 px-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 border transition-all ${
                      paymentMode === 'online_upi'
                        ? 'bg-cyan-600/30 text-cyan-300 border-cyan-500 shadow-md ring-1 ring-cyan-500/50'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-750'
                    }`}
                  >
                    <QrCode className="w-4 h-4 text-cyan-400" />
                    <span>UPI QR (ऑनलाइन)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMode('credit_udhaar')}
                    className={`py-2.5 px-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 border transition-all ${
                      paymentMode === 'credit_udhaar'
                        ? 'bg-amber-600/30 text-amber-300 border-amber-500 shadow-md ring-1 ring-amber-500/50'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-750'
                    }`}
                  >
                    <BookOpen className="w-4 h-4 text-amber-400" />
                    <span>UDHAAR (उधार)</span>
                  </button>
                </div>
              </div>

              {/* Mode-Specific Sub-Panel */}
              {paymentMode === 'cash' && (
                <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-semibold">Cash Tendered by Customer:</span>
                    <span className="text-slate-400">Change: <strong className="text-emerald-400 font-mono text-sm">₹{changeDue.toFixed(2)}</strong></span>
                  </div>

                  <input
                    type="number"
                    value={cashTendered}
                    onChange={(e) => setCashTendered(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-lg font-bold"
                  />

                  {/* Fast Indian currency note chips */}
                  <div className="flex flex-wrap gap-1.5">
                    {[50, 100, 200, 500, 2000].map((note) => (
                      <button
                        key={note}
                        type="button"
                        onClick={() => setCashTendered(note)}
                        className="px-2.5 py-1 rounded-lg bg-slate-750 hover:bg-slate-700 text-slate-300 border border-slate-600 text-xs font-mono font-semibold"
                      >
                        ₹{note}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setCashTendered(amount)}
                      className="px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/60 text-xs font-semibold"
                    >
                      Exact (₹{amount.toFixed(0)})
                    </button>
                  </div>
                </div>
              )}

              {paymentMode === 'online_upi' && (
                <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80 flex flex-col items-center text-center space-y-3">
                  <div className="bg-white p-2.5 rounded-2xl shadow-xl">
                    {qrDataUrl ? (
                      <img src={qrDataUrl} alt="UPI Payment QR" className="w-48 h-48 rounded-lg" />
                    ) : (
                      <div className="w-48 h-48 flex items-center justify-center text-xs text-slate-400 font-medium">
                        Generating Dynamic QR...
                      </div>
                    )}
                  </div>

                  <div className="space-y-0.5 text-xs">
                    <div className="font-bold text-white text-sm">
                      Scan to Pay ₹{amount.toFixed(2)}
                    </div>
                    <div className="text-slate-400 font-mono text-[11px]">
                      UPI ID: {storeSettings.upiId || 'nayabmasale@upi'}
                    </div>
                    <div className="text-[10px] text-emerald-400 font-semibold">
                      Supports GPay, PhonePe, Paytm, BHIM & Any Banking App
                    </div>
                  </div>
                </div>
              )}

              {paymentMode === 'credit_udhaar' && (
                <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-amber-500/40 space-y-3">
                  <div className="flex items-center gap-1.5 text-amber-300 text-xs font-bold">
                    <AlertCircle className="w-4 h-4" />
                    <span>Customer Credit (Udhaar Khata) Entry</span>
                  </div>

                  {customers.length > 0 && (
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">
                        Select Existing Customer:
                      </label>
                      <select
                        value={selectedCustomerId}
                        onChange={handleCustomerSelect}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none"
                      >
                        <option value="">-- Choose Customer or Enter Below --</option>
                        {customers.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name} ({c.phone}) - Current Due: ₹{c.totalDue.toFixed(2)}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}

              {/* Customer Details Optional Fields */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1 flex items-center gap-1">
                    <User className="w-3.5 h-3.5" />
                    <span>Customer Name {paymentMode === 'credit_udhaar' && '*'}</span>
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Ramesh Bhai"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5" />
                    <span>Mobile No. (for WhatsApp):</span>
                  </label>
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="10-digit mobile"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Remarks / Note (Optional):</label>
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="e.g. 500g Jeera + 1kg Atta parcel"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleFinishSale}
                  className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-99 text-white font-extrabold rounded-xl shadow-lg shadow-emerald-950/80 text-sm flex items-center justify-center gap-2 transition-all"
                >
                  <CheckCircle className="w-5 h-5 text-emerald-200" />
                  <span>Confirm Sale & Record (₹{amount.toFixed(2)})</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
