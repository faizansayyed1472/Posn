import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Wallet,
  Calendar,
  IndianRupee,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Printer,
  Receipt,
  Lock,
  Eye,
  EyeOff,
  ShoppingBag,
  Clock,
  ArrowUpRight,
  Filter,
} from 'lucide-react';
import { Transaction, CustomerUdhaar, Product, StoreSettings } from '../types';
import { printReceipt, ThermalReceiptData } from '../utils/printer';

interface OwnerReportsTabProps {
  transactions: Transaction[];
  customers: CustomerUdhaar[];
  products: Product[];
  storeSettings: StoreSettings;
  cashFlow?: { openingAmount: number; addedAmount: number };
  onOpenBillsManager?: () => void;
}

type ReportPeriod = 'daily' | 'weekly' | 'monthly' | 'yearly' | 'all';

export const OwnerReportsTab: React.FC<OwnerReportsTabProps> = ({
  transactions = [],
  customers = [],
  products = [],
  storeSettings,
  cashFlow,
  onOpenBillsManager,
}) => {
  const [selectedPeriod, setSelectedPeriod] = useState<ReportPeriod>('daily');
  const [sessionUnlocked, setSessionUnlocked] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');
  const [showPin, setShowPin] = useState<boolean>(false);
  const [printMsg, setPrintMsg] = useState<string>('');

  const activeStaff = storeSettings.staffAccounts?.find((s) => s.id === storeSettings.activeStaffId) ||
    storeSettings.staffAccounts?.[0];
  const isOwner = activeStaff?.role === 'owner';
  const ownerStaff = storeSettings.staffAccounts?.find((s) => s.role === 'owner') ||
    storeSettings.staffAccounts?.[0] || {
      id: 'owner',
      name: 'Nayab Store Owner',
      role: 'owner' as const,
      pin: 'nayab@q6',
    };

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (ownerStaff.pin && ownerStaff.pin !== pinInput.trim()) {
      setPinError('Incorrect Owner PIN. Access is strictly restricted to store owner.');
      return;
    }
    setSessionUnlocked(true);
    setPinError('');
  };

  // Date boundaries for Daily, Weekly, Monthly, Yearly
  const dateRanges = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).getTime();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    const startOfYear = new Date(now.getFullYear(), 0, 1).getTime();

    return { startOfToday, startOfWeek, startOfMonth, startOfYear };
  }, []);

  // Filtered transactions based on period
  const filteredTransactions = useMemo(() => {
    return transactions.filter((t) => {
      const tTime = new Date(t.timestamp).getTime();
      if (selectedPeriod === 'daily') return tTime >= dateRanges.startOfToday;
      if (selectedPeriod === 'weekly') return tTime >= dateRanges.startOfWeek;
      if (selectedPeriod === 'monthly') return tTime >= dateRanges.startOfMonth;
      if (selectedPeriod === 'yearly') return tTime >= dateRanges.startOfYear;
      return true;
    });
  }, [transactions, selectedPeriod, dateRanges]);

  // Aggregated analytics
  const totalSales = useMemo(() => {
    return filteredTransactions
      .filter((t) => t.type === 'sale')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [filteredTransactions]);

  const totalExpenses = useMemo(() => {
    return filteredTransactions
      .filter((t) => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [filteredTransactions]);

  const netBalance = totalSales - totalExpenses;

  const salesCount = filteredTransactions.filter((t) => t.type === 'sale').length;
  const avgBillValue = salesCount > 0 ? totalSales / salesCount : 0;

  const cashSales = filteredTransactions
    .filter((t) => t.type === 'sale' && t.paymentMode === 'cash')
    .reduce((sum, t) => sum + t.amount, 0);

  const upiSales = filteredTransactions
    .filter((t) => t.type === 'sale' && t.paymentMode === 'online_upi')
    .reduce((sum, t) => sum + t.amount, 0);

  const udhaarSales = filteredTransactions
    .filter((t) => t.type === 'sale' && t.paymentMode === 'credit_udhaar')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalUdhaarPending = useMemo(() => {
    return customers.reduce((sum, c) => sum + c.totalDue, 0);
  }, [customers]);

  // Top products sold in this period
  const topProducts = useMemo(() => {
    const itemMap: { [name: string]: { name: string; qty: number; unit: string; total: number } } = {};
    filteredTransactions
      .filter((t) => t.type === 'sale' && t.items)
      .forEach((t) => {
        t.items?.forEach((item) => {
          if (!itemMap[item.name]) {
            itemMap[item.name] = { name: item.name, qty: 0, unit: item.unit || 'pcs', total: 0 };
          }
          itemMap[item.name].qty += item.quantity;
          itemMap[item.name].total += item.total;
        });
      });

    return Object.values(itemMap)
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  }, [filteredTransactions]);

  // Print Summary Thermal Receipt Slip for this period
  const handlePrintPeriodReport = async () => {
    setPrintMsg('Printing report summary to thermal slip...');
    const periodTitles: Record<ReportPeriod, string> = {
      daily: 'DAILY SALES & EXPENSE REPORT',
      weekly: 'WEEKLY 7-DAY BUSINESS REPORT',
      monthly: 'MONTHLY FINANCIAL REPORT',
      yearly: 'ANNUAL YEARLY STORE REPORT',
      all: 'ALL-TIME HISTORIC REPORT',
    };

    const receiptData: ThermalReceiptData = {
      shopName: storeSettings.shopName,
      address: storeSettings.address,
      phone: storeSettings.phone,
      gstin: storeSettings.gstin,
      receiptNumber: `REP-${selectedPeriod.toUpperCase()}-${Date.now().toString().slice(-4)}`,
      date: new Date().toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'medium' }),
      cashierName: `Owner: ${ownerStaff.name}`,
      items: [
        { id: 'r1', name: 'Total Gross Sales (बिक्री)', quantity: salesCount, unit: 'bills' as const, rate: totalSales, total: totalSales },
        { id: 'r2', name: 'Total Expenses (दुकान खर्च)', quantity: 1, unit: 'entry' as const, rate: totalExpenses, total: totalExpenses },
        { id: 'r3', name: 'Cash Sales (नकद)', quantity: 1, unit: 'cash' as const, rate: cashSales, total: cashSales },
        { id: 'r4', name: 'UPI Online Sales', quantity: 1, unit: 'upi' as const, rate: upiSales, total: upiSales },
        { id: 'r5', name: 'Udhaar Given (उधार)', quantity: 1, unit: 'khata' as const, rate: udhaarSales, total: udhaarSales },
      ],
      subtotal: totalSales,
      taxAmount: 0,
      taxRate: 0,
      grandTotal: netBalance,
      paymentMode: 'report',
      upiId: storeSettings.upiId,
    };

    const res = await printReceipt(receiptData, storeSettings);
    if (res.success) {
      setPrintMsg('Report printed successfully!');
      setTimeout(() => setPrintMsg(''), 3500);
    } else {
      setPrintMsg(res.error || 'Failed to print report.');
    }
  };

  // If active user is NOT owner and has not unlocked with owner PIN:
  if (!isOwner && !sessionUnlocked) {
    return (
      <div className="bg-slate-900/90 border-2 border-amber-500/40 rounded-3xl p-6 shadow-2xl max-w-lg mx-auto space-y-4 my-4">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-extrabold text-base text-white">Owner Reports - Restricted Access</h3>
            <p className="text-xs text-amber-300 font-medium">केवल दुकान मालिक के लिए (Protected with Owner PIN)</p>
          </div>
        </div>

        <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs text-slate-300 space-y-2">
          <p>
            Daily, Weekly, Monthly, and Yearly sales breakdowns, store expenses, and profits are strictly confidential and restricted to the Store Owner.
          </p>
          <div className="flex justify-between pt-2 border-t border-slate-800 text-slate-400">
            <span>Current Logged Staff:</span>
            <span className="text-white font-semibold">{activeStaff?.name} ({activeStaff?.role})</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Store Owner:</span>
            <span className="text-amber-400 font-bold">{ownerStaff.name}</span>
          </div>
        </div>

        {pinError && (
          <div className="p-2.5 bg-rose-950/70 border border-rose-500/50 rounded-xl text-rose-200 text-xs font-semibold">
            ⚠ {pinError}
          </div>
        )}

        <form onSubmit={handleUnlock} className="space-y-3">
          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1.5">
              Enter Owner PIN / Password:
            </label>
            <div className="relative">
              <input
                type={showPin ? 'text' : 'password'}
                required
                autoFocus
                placeholder="Enter Owner Password / PIN"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                className="w-full bg-slate-950 border border-amber-500/50 focus:border-amber-400 rounded-xl pl-3.5 pr-10 py-2 text-white font-mono text-sm tracking-wider focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-amber-950/80 transition-all"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Unlock Owner Reports (रिपोर्ट्स देखें)</span>
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Bar with Period Selection & Print Report Button */}
      <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-white text-sm">Owner Business Reports</h4>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold text-[10px] border border-amber-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                <span>OWNER ACCESS</span>
              </span>
            </div>
            <p className="text-slate-400 text-xs">
              Daily, Weekly, Monthly & Yearly sales, expenses, and net profit ledger
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {onOpenBillsManager && (
            <button
              onClick={onOpenBillsManager}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
              title="Search, filter, view and edit sale bills, online UPI and udhaar bills"
            >
              <Receipt className="w-3.5 h-3.5 text-blue-200" />
              <span>Manage Bills & Edit (बिल देखें व बदलें)</span>
            </button>
          )}

          <button
            onClick={handlePrintPeriodReport}
            className="px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-650 text-white border border-slate-600 font-semibold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
            title="Print report on thermal slip"
          >
            <Printer className="w-3.5 h-3.5 text-cyan-400" />
            <span>Print Report Slip</span>
          </button>
        </div>
      </div>

      {printMsg && (
        <div className="p-2.5 rounded-xl bg-cyan-950/80 border border-cyan-800 text-cyan-300 text-xs font-semibold text-center">
          {printMsg}
        </div>
      )}

      {/* Period Selection Tabs: Daily, Weekly, Monthly, Yearly, All */}
      <div className="flex items-center gap-1.5 p-1.5 bg-slate-950/80 rounded-2xl border border-slate-800 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setSelectedPeriod('daily')}
          className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all whitespace-nowrap ${
            selectedPeriod === 'daily'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Daily (आज का)</span>
        </button>

        <button
          onClick={() => setSelectedPeriod('weekly')}
          className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all whitespace-nowrap ${
            selectedPeriod === 'weekly'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Weekly (इस सप्ताह - 7 Days)</span>
        </button>

        <button
          onClick={() => setSelectedPeriod('monthly')}
          className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all whitespace-nowrap ${
            selectedPeriod === 'monthly'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Monthly (इस महीने)</span>
        </button>

        <button
          onClick={() => setSelectedPeriod('yearly')}
          className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all whitespace-nowrap ${
            selectedPeriod === 'yearly'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Yearly (इस साल)</span>
        </button>

        <button
          onClick={() => setSelectedPeriod('all')}
          className={`px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all whitespace-nowrap ${
            selectedPeriod === 'all'
              ? 'bg-slate-700 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <span>All-Time (कुल)</span>
        </button>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total Sales */}
        <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-semibold uppercase tracking-wider">Gross Sales (बिक्री)</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400">
            ₹{totalSales.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400">
            {salesCount} sale bills recorded
          </div>
        </div>

        {/* Total Expenses */}
        <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-semibold uppercase tracking-wider">Store Expenses (खर्च)</span>
            <TrendingDown className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-xl font-bold font-mono text-rose-400">
            ₹{totalExpenses.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400">
            Deducted from daily counter
          </div>
        </div>

        {/* Net Profit / Balance */}
        <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-semibold uppercase tracking-wider">Net Balance (शुद्ध बचत)</span>
            <Wallet className="w-4 h-4 text-sky-400" />
          </div>
          <div
            className={`text-xl font-bold font-mono ${
              netBalance >= 0 ? 'text-sky-400' : 'text-rose-400'
            }`}
          >
            ₹{netBalance.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400">
            Avg Bill: ₹{avgBillValue.toFixed(0)}
          </div>
        </div>

        {/* Pending Udhaar in Market */}
        <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-semibold uppercase tracking-wider">Pending Udhaar (उधार)</span>
            <IndianRupee className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold font-mono text-amber-400">
            ₹{totalUdhaarPending.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400">
            Total market receivables
          </div>
        </div>
      </div>

      {/* Payment Modes Breakdown */}
      <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-2">
        <h5 className="font-bold text-white text-xs uppercase tracking-wider">
          Payment Mode Collection ({selectedPeriod.toUpperCase()})
        </h5>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
            <div>
              <div className="text-slate-400 text-[11px]">Cash Collection (नकद):</div>
              <div className="font-mono font-bold text-emerald-400 text-sm">₹{cashSales.toFixed(2)}</div>
            </div>
            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-1.5 py-0.5 rounded">
              {totalSales > 0 ? Math.round((cashSales / totalSales) * 100) : 0}%
            </span>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
            <div>
              <div className="text-slate-400 text-[11px]">UPI QR Scanner (बैंक):</div>
              <div className="font-mono font-bold text-cyan-400 text-sm">₹{upiSales.toFixed(2)}</div>
            </div>
            <span className="text-[10px] bg-cyan-500/20 text-cyan-300 font-bold px-1.5 py-0.5 rounded">
              {totalSales > 0 ? Math.round((upiSales / totalSales) * 100) : 0}%
            </span>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
            <div>
              <div className="text-slate-400 text-[11px]">Credit Khata (उधार बिल):</div>
              <div className="font-mono font-bold text-amber-400 text-sm">₹{udhaarSales.toFixed(2)}</div>
            </div>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.5 rounded">
              {totalSales > 0 ? Math.round((udhaarSales / totalSales) * 100) : 0}%
            </span>
          </div>
        </div>
      </div>

      {/* Top Products in this period */}
      {topProducts.length > 0 && (
        <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-2">
          <h5 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
            <ShoppingBag className="w-3.5 h-3.5 text-purple-400" />
            <span>Top Selling Spices & Kirana Items in this Period</span>
          </h5>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2 pt-1">
            {topProducts.map((p, idx) => (
              <div key={idx} className="bg-slate-900/70 p-2.5 rounded-xl border border-slate-800 text-xs">
                <div className="font-semibold text-white truncate">{p.name}</div>
                <div className="text-slate-400 text-[10px]">
                  Sold: <strong className="text-white">{p.qty} {p.unit}</strong>
                </div>
                <div className="font-mono font-bold text-emerald-400 text-[11px] mt-0.5">
                  ₹{p.total.toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Detailed Transactions List for this period with Real-time Date and Time */}
      <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-2.5">
        <div className="flex items-center justify-between">
          <h5 className="font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>Period Transaction Records with Real-time Date & Time ({filteredTransactions.length})</span>
          </h5>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="text-center py-6 text-slate-500 text-xs">
            No transactions found for the selected {selectedPeriod} period.
          </div>
        ) : (
          <div className="max-h-72 overflow-y-auto border border-slate-800 rounded-xl divide-y divide-slate-800/80 bg-slate-900/60">
            {filteredTransactions.map((t) => {
              const formattedDate = new Date(t.timestamp).toLocaleDateString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
              });
              const formattedTime = new Date(t.timestamp).toLocaleTimeString('en-IN', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
              });

              return (
                <div key={t.id} className="p-2.5 hover:bg-slate-800/50 transition-colors flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-white">{t.receiptNumber}</span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-bold uppercase ${
                          t.type === 'sale'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {t.type}
                      </span>
                      <span className="text-slate-400 text-[10px] uppercase font-semibold">
                        {t.paymentMode.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                      <Clock className="w-3 h-3 text-cyan-400" />
                      <span className="text-slate-300">{formattedDate}</span>
                      <span>•</span>
                      <span className="font-mono text-cyan-300 font-semibold">{formattedTime}</span>
                      {t.customerName && (
                        <>
                          <span>•</span>
                          <span className="text-amber-300">Cust: {t.customerName}</span>
                        </>
                      )}
                      {t.staffName && (
                        <>
                          <span>•</span>
                          <span className="text-slate-400">Staff: {t.staffName}</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    <div
                      className={`font-mono font-bold text-sm ${
                        t.type === 'sale' ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {t.type === 'sale' ? '+' : '-'}₹{t.amount.toFixed(2)}
                    </div>
                    {t.items && (
                      <div className="text-[10px] text-slate-500">
                        {t.items.length} item(s)
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
