import React, { useState, useEffect, useMemo } from 'react';
import QRCode from 'qrcode';
import {
  X,
  Settings,
  Store,
  QrCode,
  Package,
  Users,
  Printer,
  Phone,
  MapPin,
  Check,
  Plus,
  Trash2,
  Edit2,
  AlertTriangle,
  Key,
  Shield,
  Search,
  RefreshCw,
  Copy,
  Bluetooth,
  Usb,
  Database,
  Download,
  Upload,
  ShieldCheck,
  FileJson,
  AlertCircle,
  HardDrive,
  CheckCircle2,
  BarChart3,
  Lock,
  ShieldAlert,
} from 'lucide-react';
import { StoreSettings, Product, StaffAccount, ProductCategory, UnitType, Transaction, CustomerUdhaar, FullBackupData } from '../types';
import { OwnerReportsTab } from './OwnerReportsTab';
import {
  connectBluetoothPrinter,
  connectSerialPrinter,
  disconnectHardwarePrinter,
  isHardwarePrinterConnected,
  printTestReceipt,
} from '../utils/printer';
import {
  createFullBackupData,
  downloadBackupAsJson,
  validateBackupJson,
  saveAutoBackupSnapshot,
} from '../utils/backup';

interface StoreSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: StoreSettings;
  products: Product[];
  transactions?: Transaction[];
  customers?: CustomerUdhaar[];
  cashFlow?: { openingAmount: number; addedAmount: number };
  onSaveSettings: (newSettings: StoreSettings) => void;
  onUpdateProduct: (product: Product) => void;
  onAddProduct: (product: Product) => void;
  onBulkAddProducts?: (items: Product[]) => void;
  onClearAllProducts?: () => void;
  onDeleteProduct: (productId: string) => void;
  onRestoreFullBackup?: (backupData: FullBackupData) => void;
  onOpenBillsManager?: () => void;
  initialTab?: 'upi' | 'inventory' | 'staff' | 'printer' | 'profile' | 'backup' | 'reports';
  isOwner?: boolean;
  activeStaff?: StaffAccount;
}

export const StoreSettingsModal: React.FC<StoreSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  products,
  transactions = [],
  customers = [],
  cashFlow,
  onSaveSettings,
  onUpdateProduct,
  onAddProduct,
  onDeleteProduct,
  onRestoreFullBackup,
  onOpenBillsManager,
  initialTab = 'upi',
  isOwner,
  activeStaff,
}) => {
  const [activeTab, setActiveTab] = useState<'upi' | 'inventory' | 'staff' | 'printer' | 'profile' | 'backup' | 'reports'>(initialTab);
  const [formData, setFormData] = useState<StoreSettings>(settings);

  // Check if current user is owner
  const currentActiveStaff = activeStaff || settings.staffAccounts.find((s) => s.id === settings.activeStaffId) || settings.staffAccounts[0];
  const userIsOwner = isOwner !== undefined ? isOwner : currentActiveStaff?.role === 'owner';
  const ownerStaffAccount = settings.staffAccounts.find((s) => s.role === 'owner') || settings.staffAccounts[0];

  // In-modal owner authorization unlock state
  const [ownerAuthUnlocked, setOwnerAuthUnlocked] = useState<boolean>(false);
  const [unlockPinInput, setUnlockPinInput] = useState<string>('');
  const [unlockPinError, setUnlockPinError] = useState<string>('');

  const isOwnerPermissionGranted = userIsOwner || ownerAuthUnlocked;

  const handleVerifyOwnerPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (ownerStaffAccount?.pin && unlockPinInput.trim() !== ownerStaffAccount.pin) {
      setUnlockPinError('Incorrect Owner PIN. Only store owner can manage account settings.');
      return;
    }
    setOwnerAuthUnlocked(true);
    setUnlockPinError('');
    setUnlockPinInput('');
  };

  useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  // UPI preview QR
  const [previewQrUrl, setPreviewQrUrl] = useState<string>('');
  const [copiedUpi, setCopiedUpi] = useState(false);

  // Inventory tab states
  const [invSearch, setInvSearch] = useState('');
  const [invCategory, setInvCategory] = useState<string>('all');
  const [invPage, setInvPage] = useState(1);
  const [invPageSize, setInvPageSize] = useState(25);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdHindi, setNewProdHindi] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<ProductCategory>('spices');
  const [newProdUnit, setNewProdUnit] = useState<UnitType>('kg');
  const [newProdRate, setNewProdRate] = useState<string>('');
  const [newProdStock, setNewProdStock] = useState<string>('');
  const [prodSuccessMsg, setProdSuccessMsg] = useState('');
  const [prodErrorMsg, setProdErrorMsg] = useState('');

  // Staff tab states
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffRole, setNewStaffRole] = useState<'cashier' | 'manager' | 'owner'>('cashier');
  const [newStaffPin, setNewStaffPin] = useState('');
  const [newStaffPhone, setNewStaffPhone] = useState('');
  const [staffError, setStaffError] = useState('');

  // Owner password change states
  const [showOwnerPasswordModal, setShowOwnerPasswordModal] = useState(false);
  const [currentOwnerPasswordInput, setCurrentOwnerPasswordInput] = useState('');
  const [newOwnerPasswordInput, setNewOwnerPasswordInput] = useState('');
  const [confirmOwnerPasswordInput, setConfirmOwnerPasswordInput] = useState('');
  const [ownerPasswordChangeError, setOwnerPasswordChangeError] = useState('');
  const [ownerPasswordChangeSuccess, setOwnerPasswordChangeSuccess] = useState('');
  const [showNewPasswordText, setShowNewPasswordText] = useState(false);

  // Printer status
  const [printerConnecting, setPrinterConnecting] = useState(false);
  const [printerStatusMsg, setPrinterStatusMsg] = useState('');
  const [printerConnected, setPrinterConnected] = useState(isHardwarePrinterConnected());

  // Backup tab states
  const [backupSuccessMsg, setBackupSuccessMsg] = useState('');
  const [backupErrorMsg, setBackupErrorMsg] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [pendingRestoreData, setPendingRestoreData] = useState<FullBackupData | null>(null);
  const [restoreSuccessMsg, setRestoreSuccessMsg] = useState('');
  const [autoSnapshotSaved, setAutoSnapshotSaved] = useState(false);
  const [localSnapshotsMeta, setLocalSnapshotsMeta] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('nayab_backup_snapshots_meta') || localStorage.getItem('tohands_backup_snapshots_meta');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const handleDownloadFullBackup = () => {
    setIsExporting(true);
    setBackupErrorMsg('');
    try {
      const backupObj = createFullBackupData(
        products,
        transactions,
        customers,
        formData,
        cashFlow
      );
      const filename = downloadBackupAsJson(backupObj);
      const nowStr = new Date().toISOString();
      const updatedSettings: StoreSettings = {
        ...formData,
        lastBackupTimestamp: nowStr,
      };
      setFormData(updatedSettings);
      onSaveSettings(updatedSettings);
      setBackupSuccessMsg(`Full backup saved! Downloaded "${filename}" successfully.`);
      setTimeout(() => setBackupSuccessMsg(''), 6000);
    } catch (err: any) {
      setBackupErrorMsg(err.message || 'Failed to generate backup file.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleTakeImmediateSnapshot = () => {
    try {
      const backupObj = createFullBackupData(
        products,
        transactions,
        customers,
        formData,
        cashFlow
      );
      const res = saveAutoBackupSnapshot(backupObj);
      setAutoSnapshotSaved(true);
      const updatedSettings: StoreSettings = {
        ...formData,
        lastBackupTimestamp: res.timestamp,
      };
      setFormData(updatedSettings);
      onSaveSettings(updatedSettings);
      setBackupSuccessMsg(`Internal local snapshot saved (${res.sizeKb} KB) at ${new Date(res.timestamp).toLocaleTimeString()}.`);
      const historyJson = localStorage.getItem('nayab_backup_snapshots_meta') || localStorage.getItem('tohands_backup_snapshots_meta');
      if (historyJson) setLocalSnapshotsMeta(JSON.parse(historyJson));
      setTimeout(() => {
        setAutoSnapshotSaved(false);
        setBackupSuccessMsg('');
      }, 5000);
    } catch (err: any) {
      setBackupErrorMsg('Could not save local snapshot: ' + err.message);
    }
  };

  const handleFileUploadForRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBackupErrorMsg('');
    setRestoreSuccessMsg('');

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (!content) return;
      const validation = validateBackupJson(content);
      if (!validation.isValid || !validation.data) {
        setBackupErrorMsg(validation.error || 'Invalid backup file format.');
        setPendingRestoreData(null);
      } else {
        setPendingRestoreData(validation.data);
      }
    };
    reader.onerror = () => {
      setBackupErrorMsg('Could not read the uploaded file.');
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleConfirmRestore = () => {
    if (!pendingRestoreData) return;
    if (onRestoreFullBackup) {
      onRestoreFullBackup(pendingRestoreData);
      setRestoreSuccessMsg('Store data, inventory, transactions, and customers restored successfully!');
      setPendingRestoreData(null);
      setTimeout(() => setRestoreSuccessMsg(''), 6000);
    } else {
      setBackupErrorMsg('Restore handler not configured.');
    }
  };

  useEffect(() => {
    setFormData(settings);
    setActiveTab(initialTab);
  }, [settings, initialTab, isOpen]);

  // Generate live UPI QR preview whenever UPI ID changes
  useEffect(() => {
    if (formData.upiId) {
      const upiUrl = `upi://pay?pa=${encodeURIComponent(formData.upiId)}&pn=${encodeURIComponent(
        formData.upiName || formData.shopName
      )}&cu=INR`;

      QRCode.toDataURL(upiUrl, {
        width: 180,
        margin: 1,
        color: { dark: '#0f172a', light: '#ffffff' },
      })
        .then((url) => setPreviewQrUrl(url))
        .catch(() => {});
    }
  }, [formData.upiId, formData.upiName, formData.shopName]);

  const handleSaveAll = () => {
    // If not owner, do not allow staff to modify staff accounts, roles or credentials
    if (!isOwnerPermissionGranted) {
      onSaveSettings({
        ...formData,
        staffAccounts: settings.staffAccounts,
        activeStaffId: settings.activeStaffId,
      });
    } else {
      onSaveSettings(formData);
    }
    onClose();
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(formData.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  // Staff operations
  const handleCreateStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffName.trim() || !newStaffPin.trim()) {
      setStaffError('Name and 4-digit PIN/password are required.');
      return;
    }

    const newStaff: StaffAccount = {
      id: `staff-${Date.now()}`,
      name: newStaffName.trim(),
      role: newStaffRole,
      pin: newStaffPin.trim(),
      phone: newStaffPhone.trim() || undefined,
      active: true,
      createdAt: new Date().toISOString(),
    };

    const updatedAccounts = [...formData.staffAccounts, newStaff];
    setFormData({
      ...formData,
      staffAccounts: updatedAccounts,
    });

    setShowAddStaffModal(false);
    setNewStaffName('');
    setNewStaffPin('');
    setNewStaffPhone('');
    setStaffError('');
  };

  const handleDeleteStaff = (staffId: string) => {
    if (formData.staffAccounts.length <= 1) {
      alert('At least one staff/owner account must remain.');
      return;
    }
    const updated = formData.staffAccounts.filter((s) => s.id !== staffId);
    setFormData({
      ...formData,
      staffAccounts: updated,
      activeStaffId: formData.activeStaffId === staffId ? updated[0].id : formData.activeStaffId,
    });
  };

  const handleChangeOwnerPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setOwnerPasswordChangeError('');
    setOwnerPasswordChangeSuccess('');

    // If active user is not owner, verify current owner password
    if (!userIsOwner && ownerStaffAccount?.pin && currentOwnerPasswordInput.trim() !== ownerStaffAccount.pin) {
      setOwnerPasswordChangeError('Current Owner password is incorrect.');
      return;
    }

    if (!newOwnerPasswordInput.trim()) {
      setOwnerPasswordChangeError('Please enter a new password.');
      return;
    }
    if (newOwnerPasswordInput.trim().length < 4) {
      setOwnerPasswordChangeError('Password must be at least 4 characters long.');
      return;
    }
    if (newOwnerPasswordInput.trim() !== confirmOwnerPasswordInput.trim()) {
      setOwnerPasswordChangeError('New passwords do not match. Please re-enter.');
      return;
    }

    const updatedStaffAccounts = formData.staffAccounts.map((staff) => {
      if (staff.role === 'owner') {
        return {
          ...staff,
          pin: newOwnerPasswordInput.trim(),
        };
      }
      return staff;
    });

    const updatedSettings: StoreSettings = {
      ...formData,
      staffAccounts: updatedStaffAccounts,
    };

    setFormData(updatedSettings);
    onSaveSettings(updatedSettings);
    setOwnerPasswordChangeSuccess('Owner password successfully updated! (मालिक का पासवर्ड बदल दिया गया है)');
    setCurrentOwnerPasswordInput('');
    setNewOwnerPasswordInput('');
    setConfirmOwnerPasswordInput('');
    setTimeout(() => {
      setOwnerPasswordChangeSuccess('');
      setShowOwnerPasswordModal(false);
    }, 2200);
  };

  // Product Add / Update
  const handleSaveNewProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setProdErrorMsg('');
    if (!newProdName.trim()) {
      setProdErrorMsg('Please enter product name.');
      return;
    }

    const parsedRate = parseFloat(newProdRate);
    if (isNaN(parsedRate) || parsedRate <= 0) {
      setProdErrorMsg('Please enter a valid selling rate greater than 0.');
      return;
    }

    const parsedStock = newProdStock.trim() !== '' ? parseFloat(newProdStock) : undefined;

    const newProd: Product = {
      id: `prod-${Date.now()}`,
      name: newProdName.trim(),
      hindiName: newProdHindi.trim() || undefined,
      category: newProdCategory,
      unit: newProdUnit,
      rate: parsedRate,
      stock: parsedStock,
      minStockAlert: 5,
    };

    onAddProduct(newProd);
    setProdSuccessMsg(`Added "${newProd.name}" (${newProdUnit}) to inventory successfully!`);
    setShowAddProductModal(false);
    setNewProdName('');
    setNewProdHindi('');
    setNewProdRate('');
    setNewProdStock('');
    setTimeout(() => setProdSuccessMsg(''), 4000);
  };

  // Printer Connect Handlers
  const handleConnectBluetooth = async () => {
    setPrinterConnecting(true);
    setPrinterStatusMsg('Searching for Bluetooth Thermal Printers...');
    const res = await connectBluetoothPrinter();
    setPrinterConnecting(false);
    if (res.success) {
      setPrinterConnected(true);
      setPrinterStatusMsg(`Connected: ${res.deviceName}`);
      setFormData({
        ...formData,
        printerConfig: {
          ...formData.printerConfig,
          printerType: 'bluetooth',
          deviceName: res.deviceName,
          connected: true,
        },
      });
    } else {
      setPrinterStatusMsg(res.error || 'Failed to connect Bluetooth printer.');
    }
  };

  const handleConnectSerial = async () => {
    setPrinterConnecting(true);
    setPrinterStatusMsg('Requesting USB / Serial Port...');
    const res = await connectSerialPrinter();
    setPrinterConnecting(false);
    if (res.success) {
      setPrinterConnected(true);
      setPrinterStatusMsg(`Connected: ${res.deviceName}`);
      setFormData({
        ...formData,
        printerConfig: {
          ...formData.printerConfig,
          printerType: 'serial',
          deviceName: res.deviceName,
          connected: true,
        },
      });
    } else {
      setPrinterStatusMsg(res.error || 'Failed to connect USB / Serial printer.');
    }
  };

  const handleDisconnectPrinter = async () => {
    await disconnectHardwarePrinter();
    setPrinterConnected(false);
    setPrinterStatusMsg('Printer disconnected. Falling back to Browser Thermal Print.');
    setFormData({
      ...formData,
      printerConfig: {
        ...formData.printerConfig,
        connected: false,
      },
    });
  };

  const handleTestPrint = async () => {
    setPrinterStatusMsg('Sending test slip to printer...');
    const res = await printTestReceipt(formData);
    if (res.success) {
      setPrinterStatusMsg('Test slip printed successfully!');
    } else {
      setPrinterStatusMsg(res.error || 'Could not print test slip.');
    }
  };

  // Filtered products in Inventory tab
  const filteredProducts = useMemo(() => {
    const q = invSearch.toLowerCase().trim();
    return products.filter((p) => {
      const matchesSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        (p.hindiName && p.hindiName.includes(q)) ||
        p.category.toLowerCase().includes(q);
      const matchesCat = invCategory === 'all' || p.category === invCategory;
      return matchesSearch && matchesCat;
    });
  }, [products, invSearch, invCategory]);

  const totalInvPages = Math.max(1, Math.ceil(filteredProducts.length / invPageSize));
  const safeInvPage = Math.min(invPage, totalInvPages);
  const paginatedInvProducts = useMemo(() => {
    const start = (safeInvPage - 1) * invPageSize;
    return filteredProducts.slice(start, start + invPageSize);
  }, [filteredProducts, safeInvPage, invPageSize]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/95">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center">
              <Settings className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Store & System Settings</h3>
              <p className="text-xs text-slate-400">Manage UPI Scanner, Inventory, Staff & Thermal Printer</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveAll}
              className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Save Changes</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-2.5 bg-slate-950/60 border-b border-slate-800 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('upi')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'upi'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>1. UPI ID Scanner</span>
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'inventory'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>2. Inventory ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('staff')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'staff'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {isOwnerPermissionGranted ? (
              <Users className="w-4 h-4" />
            ) : (
              <Lock className="w-4 h-4 text-amber-400" />
            )}
            <span>3. Staff Accounts {!isOwnerPermissionGranted && '(Owner Only)'}</span>
          </button>

          <button
            onClick={() => setActiveTab('printer')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'printer'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Printer className="w-4 h-4" />
            <span>4. Thermal Printer</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'profile'
                ? 'bg-slate-700 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Store className="w-4 h-4" />
            <span>5. Shop Profile</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'backup'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>6. Data Backup (JSON)</span>
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'reports'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>7. Owner Reports (Daily, Weekly, Monthly, Yearly)</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
          {/* TAB 1: UPI ID FOR SCANNER */}
          {activeTab === 'upi' && (
            <div className="space-y-4">
              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white text-sm">UPI ID & Dynamic QR Scanner Settings</h4>
                    <p className="text-slate-400 text-xs">
                      Set your store's UPI VPA. Customers will scan this to pay exact bill amounts directly into your bank.
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-semibold text-[10px]">
                    LIVE ACTIVE
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-start">
                  <div className="space-y-3">
                    <div>
                      <label className="text-slate-300 font-semibold block mb-1">
                        Merchant UPI ID (e.g. 9876543210@paytm or nayabmasale@okhdfcbank):
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          required
                          value={formData.upiId}
                          onChange={(e) => setFormData({ ...formData, upiId: e.target.value.trim() })}
                          placeholder="yourname@upi"
                          className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={handleCopyUpi}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-emerald-400"
                          title="Copy UPI ID"
                        >
                          {copiedUpi ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 font-semibold block mb-1">
                        Merchant / Payee Name (Displayed in Customer's UPI App):
                      </label>
                      <input
                        type="text"
                        value={formData.upiName || formData.shopName}
                        onChange={(e) => setFormData({ ...formData, upiName: e.target.value })}
                        placeholder="e.g. Nayab Masale & Kirana Store"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                      />
                    </div>

                    <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
                      <div className="font-semibold text-white">Supported UPI Payment Apps:</div>
                      <div>PhonePe, Google Pay (GPay), Paytm, BHIM, Amazon Pay, Cred & All Bank UPI apps.</div>
                    </div>
                  </div>

                  {/* Live Scanner QR Preview */}
                  <div className="flex flex-col items-center justify-center p-4 bg-slate-950 rounded-2xl border border-slate-800 text-center">
                    <span className="text-slate-400 font-medium mb-2">Live Scanner QR Code Preview:</span>
                    <div className="bg-white p-2.5 rounded-2xl shadow-xl">
                      {previewQrUrl ? (
                        <img src={previewQrUrl} alt="UPI QR Preview" className="w-36 h-36 rounded-lg" />
                      ) : (
                        <div className="w-36 h-36 flex items-center justify-center text-slate-400 text-xs">
                          Generating QR...
                        </div>
                      )}
                    </div>
                    <span className="font-mono text-emerald-400 text-xs mt-2 font-bold">{formData.upiId}</span>
                    <span className="text-[10px] text-slate-500">NAYAB calculator screen will display this QR with bill amounts</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: INVENTORY MANAGEMENT */}
          {activeTab === 'inventory' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-800">
                <div>
                  <h4 className="font-bold text-white text-sm">Kirana & Spice Inventory Management</h4>
                  <p className="text-slate-400 text-xs">Edit product rates, update stock, or add new items</p>
                </div>

                <button
                  onClick={() => {
                    setShowAddProductModal(true);
                    setProdErrorMsg('');
                  }}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product (नया आइटम)</span>
                </button>
              </div>

              {/* Feedback messages */}
              {prodSuccessMsg && (
                <div className="p-3 bg-emerald-900/50 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs font-semibold flex items-center justify-between animate-in fade-in">
                  <span>✓ {prodSuccessMsg}</span>
                  <button onClick={() => setProdSuccessMsg('')} className="text-emerald-400 hover:text-white">✕</button>
                </div>
              )}

              {/* Add Product Inline Dialog (TOP OF INVENTORY) */}
              {showAddProductModal && (
                <div className="p-4 bg-slate-800/95 border-2 border-purple-500/60 rounded-2xl space-y-3 shadow-xl animate-in fade-in">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-700">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-purple-600/30 flex items-center justify-center text-purple-300 font-bold text-xs">
                        +
                      </div>
                      <span className="font-bold text-white text-xs sm:text-sm">Add New Kirana / Spice Product (नया सामान जोड़ें)</span>
                    </div>
                    <button
                      onClick={() => {
                        setShowAddProductModal(false);
                        setProdErrorMsg('');
                      }}
                      className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {prodErrorMsg && (
                    <div className="p-2 bg-red-950/60 border border-red-500/40 rounded-lg text-red-300 text-xs">
                      ⚠ {prodErrorMsg}
                    </div>
                  )}

                  <form onSubmit={handleSaveNewProduct} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1 font-medium">Product Name (English): <span className="text-red-400">*</span></label>
                      <input
                        type="text"
                        required
                        value={newProdName}
                        onChange={(e) => setNewProdName(e.target.value)}
                        placeholder="e.g. Kasuri Methi"
                        className="w-full bg-slate-900 border border-slate-750 focus:border-purple-500 rounded-lg px-2.5 py-2 text-white placeholder-slate-500"
                        autoFocus
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-medium">Hindi Name (हिंदी नाम):</label>
                      <input
                        type="text"
                        value={newProdHindi}
                        onChange={(e) => setNewProdHindi(e.target.value)}
                        placeholder="e.g. कस्तूरी मेथी"
                        className="w-full bg-slate-900 border border-slate-750 focus:border-purple-500 rounded-lg px-2.5 py-2 text-white placeholder-slate-500"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-medium">Category (श्रेणी):</label>
                      <select
                        value={newProdCategory}
                        onChange={(e) => setNewProdCategory(e.target.value as any)}
                        className="w-full bg-slate-900 border border-slate-750 focus:border-purple-500 rounded-lg px-2.5 py-2 text-white"
                      >
                        <option value="spices">Spices & Masale (मसाले)</option>
                        <option value="dal_pulses">Dals & Pulses (दालें)</option>
                        <option value="grains_flour">Flour & Rice (आटा, चावल)</option>
                        <option value="oil_ghee">Oil & Ghee (तेल, घी)</option>
                        <option value="dry_fruits">Dry Fruits (मेवे)</option>
                        <option value="packaged_grocery">Packaged Grocery (पैकेट किराना)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-medium">Weight Unit (वजन इकाई):</label>
                      <select
                        value={newProdUnit}
                        onChange={(e) => setNewProdUnit(e.target.value as any)}
                        className="w-full bg-slate-900 border border-slate-750 focus:border-purple-500 rounded-lg px-2.5 py-2 text-white font-medium"
                      >
                        <option value="kg">kg (Kilogram / किलो)</option>
                        <option value="g">g (Gram / ग्राम)</option>
                        <option value="quintal">quintal (क्विंटल / 100kg)</option>
                        <option value="litre">litre (लीटर)</option>
                        <option value="packet">packet (पैकेट)</option>
                        <option value="piece">piece (नग / पीस)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-medium">Selling Rate (₹ प्रति {newProdUnit}): <span className="text-red-400">*</span></label>
                      <input
                        type="number"
                        required
                        step="any"
                        min="0.1"
                        placeholder="e.g. 380"
                        value={newProdRate}
                        onChange={(e) => setNewProdRate(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-750 focus:border-purple-500 rounded-lg px-2.5 py-2 text-emerald-400 font-mono font-bold"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-medium">Initial Weight / Stock (ऐच्छिक):</label>
                      <input
                        type="number"
                        step="any"
                        placeholder={`e.g. 25 (${newProdUnit})`}
                        value={newProdStock}
                        onChange={(e) => setNewProdStock(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-750 focus:border-purple-500 rounded-lg px-2.5 py-2 text-white font-mono"
                      />
                    </div>

                    <div className="sm:col-span-3 flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                      <button
                        type="button"
                        onClick={() => {
                          setShowAddProductModal(false);
                          setProdErrorMsg('');
                        }}
                        className="px-3.5 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl shadow-lg transition-all"
                      >
                        Save Product to Inventory (सेव करें)
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Search & Filter */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={invSearch}
                    onChange={(e) => setInvSearch(e.target.value)}
                    placeholder="Search product by English or Hindi name..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-400"
                  />
                </div>

                <select
                  value={invCategory}
                  onChange={(e) => setInvCategory(e.target.value)}
                  className="bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
                >
                  <option value="all">All Categories</option>
                  <option value="spices">Spices & Masale</option>
                  <option value="dal_pulses">Dals & Pulses</option>
                  <option value="grains_flour">Flour & Rice</option>
                  <option value="oil_ghee">Oil & Ghee</option>
                  <option value="dry_fruits">Dry Fruits</option>
                  <option value="packaged_grocery">Packaged Grocery</option>
                </select>
              </div>

              {/* Products Table */}
              <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/60 max-h-80 overflow-y-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-800/90 text-slate-300 font-semibold sticky top-0 z-10">
                    <tr>
                      <th className="p-2.5">Item Name</th>
                      <th className="p-2.5">Category</th>
                      <th className="p-2.5">Rate (₹)</th>
                      <th className="p-2.5">Stock</th>
                      <th className="p-2.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {paginatedInvProducts.map((p: Product) => (
                      <tr key={p.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-2.5">
                          <div className="font-semibold text-white">{p.name}</div>
                          {p.hindiName && (
                            <div className="text-[10px] text-amber-300/80">{p.hindiName}</div>
                          )}
                        </td>
                        <td className="p-2.5 text-slate-400 capitalize">{p.category.replace('_', ' ')}</td>
                        <td className="p-2.5">
                          {editingProduct?.id === p.id ? (
                            <input
                              type="number"
                              value={editingProduct.rate}
                              onChange={(e) =>
                                setEditingProduct((prev) => prev ? { ...prev, rate: parseFloat(e.target.value) || 0 } : null)
                              }
                              className="w-16 bg-slate-950 border border-purple-500 rounded px-1.5 py-0.5 text-emerald-400 font-mono text-xs font-bold"
                            />
                          ) : (
                            <span className="font-mono font-bold text-emerald-400">
                              ₹{p.rate}/{p.unit}
                            </span>
                          )}
                        </td>
                        <td className="p-2.5">
                          {editingProduct?.id === p.id ? (
                            <input
                              type="number"
                              value={editingProduct.stock || 0}
                              onChange={(e) =>
                                setEditingProduct((prev) => prev ? { ...prev, stock: parseFloat(e.target.value) || 0 } : null)
                              }
                              className="w-16 bg-slate-950 border border-purple-500 rounded px-1.5 py-0.5 text-white font-mono text-xs"
                            />
                          ) : (
                            <span className="text-slate-300">
                              {p.stock !== undefined ? `${p.stock} ${p.unit}` : 'In Stock'}
                            </span>
                          )}
                        </td>
                        <td className="p-2.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {editingProduct?.id === p.id ? (
                              <button
                                onClick={() => {
                                  if (editingProduct) {
                                    onUpdateProduct(editingProduct);
                                    setEditingProduct(null);
                                  }
                                }}
                                className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold"
                              >
                                Save
                              </button>
                            ) : (
                              <button
                                onClick={() => setEditingProduct(p)}
                                className="p-1 text-slate-400 hover:text-purple-300"
                                title="Edit Rate & Stock"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                            )}

                            <button
                              onClick={() => {
                                if (confirm(`Delete "${p.name}" from inventory?`)) {
                                  onDeleteProduct(p.id);
                                }
                              }}
                              className="p-1 text-slate-400 hover:text-red-400"
                              title="Delete Item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Inventory High-Capacity Pagination Controls */}
              {filteredProducts.length > 0 && (
                <div className="flex flex-wrap items-center justify-between gap-2 p-2 bg-slate-950/40 border border-slate-800 rounded-xl text-xs">
                  <span className="text-slate-400 text-[11px]">
                    Showing <strong className="text-white">{(safeInvPage - 1) * invPageSize + 1}</strong>–<strong className="text-white">{Math.min(safeInvPage * invPageSize, filteredProducts.length)}</strong> of <strong className="text-purple-300">{filteredProducts.length.toLocaleString()}</strong> items
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setInvPage((p) => Math.max(1, p - 1))}
                      disabled={safeInvPage === 1}
                      className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-30 text-xs"
                    >
                      Prev
                    </button>
                    <span className="px-2 py-0.5 text-xs font-mono font-bold text-white bg-slate-800 rounded">
                      {safeInvPage} / {totalInvPages}
                    </span>
                    <button
                      type="button"
                      onClick={() => setInvPage((p) => Math.min(totalInvPages, p + 1))}
                      disabled={safeInvPage === totalInvPages}
                      className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-30 text-xs"
                    >
                      Next
                    </button>
                    <select
                      value={invPageSize}
                      onChange={(e) => {
                        setInvPageSize(Number(e.target.value));
                        setInvPage(1);
                      }}
                      className="ml-2 bg-slate-800 border border-slate-700 text-slate-300 rounded px-1.5 py-0.5 text-[11px] outline-none"
                    >
                      <option value={25}>25 / page</option>
                      <option value={50}>50 / page</option>
                      <option value={100}>100 / page</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: STAFF ACCOUNTS WITH PASSWORD - OWNER RESTRICTED */}
          {activeTab === 'staff' && (
            <div className="space-y-4">
              {!isOwnerPermissionGranted ? (
                /* Non-owner staff locked out banner */
                <div className="p-6 bg-slate-900/90 border-2 border-amber-500/50 rounded-2xl text-center space-y-4 max-w-md mx-auto my-6 shadow-2xl">
                  <div className="w-14 h-14 rounded-3xl bg-amber-500/20 border border-amber-500/30 mx-auto flex items-center justify-center text-amber-400">
                    <ShieldAlert className="w-7 h-7" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-base font-extrabold text-white">Owner Access Restricted</h4>
                    <p className="text-xs text-amber-200/80 leading-relaxed">
                      Staff & cashier accounts cannot manage store settings, staff profiles, or passwords. This section is strictly restricted to the Store Owner (<span className="text-amber-300 font-bold">{ownerStaffAccount.name}</span>).
                    </p>
                  </div>

                  <form onSubmit={handleVerifyOwnerPin} className="space-y-3 pt-1">
                    <div className="text-left">
                      <label className="text-xs font-semibold text-slate-300 block mb-1">
                        Enter Owner PIN to unlock staff settings:
                      </label>
                      <input
                        type="password"
                        maxLength={30}
                        value={unlockPinInput}
                        onChange={(e) => {
                          setUnlockPinInput(e.target.value);
                          setUnlockPinError('');
                        }}
                        placeholder="Enter Owner Password / PIN"
                        className="w-full bg-slate-950 border border-amber-500/60 rounded-xl px-3 py-2 text-center text-white font-mono tracking-widest text-lg font-bold outline-none focus:border-amber-400"
                        autoFocus
                      />
                      {unlockPinError && (
                        <p className="text-red-400 text-xs mt-1 font-semibold">{unlockPinError}</p>
                      )}
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Verify Owner PIN & Unlock</span>
                    </button>
                  </form>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <div>
                      <h4 className="font-bold text-white text-sm">Staff Accounts & Password Protection</h4>
                      <p className="text-slate-400 text-xs">
                        Manage cashier accounts, owner security and passwords.
                      </p>
                    </div>

                    <button
                      onClick={() => setShowAddStaffModal(true)}
                      className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Staff Account</span>
                    </button>
                  </div>

                  {/* Dedicated Owner Password Security Card */}
                  <div className="p-3.5 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 rounded-2xl border border-amber-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 flex-shrink-0">
                        <Lock className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="font-bold text-white text-sm">Owner Account Security</h5>
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            {ownerStaffAccount.name}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">
                          Controls financial reports, store settings, and staff passwords.
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setShowOwnerPasswordModal(true);
                        setOwnerPasswordChangeError('');
                        setOwnerPasswordChangeSuccess('');
                      }}
                      className="px-3.5 py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer select-none active:scale-95 whitespace-nowrap"
                    >
                      <Key className="w-3.5 h-3.5" />
                      <span>Change Owner Password (पासवर्ड बदलें)</span>
                    </button>
                  </div>

                  {/* Change Owner Password Modal / Form */}
                  {showOwnerPasswordModal && (
                    <div className="p-4 bg-slate-900 border-2 border-amber-500/60 rounded-2xl space-y-3.5 animate-in fade-in shadow-2xl">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                            <Lock className="w-4 h-4" />
                          </div>
                          <div>
                            <span className="font-bold text-white text-sm">Change Owner Password / PIN</span>
                            <p className="text-[11px] text-amber-300/80">मालिक का नया पासवर्ड सेट करें</p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowOwnerPasswordModal(false)}
                          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      {ownerPasswordChangeError && (
                        <div className="p-2.5 bg-red-950/70 border border-red-500/50 rounded-xl text-red-200 text-xs font-semibold">
                          ⚠ {ownerPasswordChangeError}
                        </div>
                      )}

                      {ownerPasswordChangeSuccess && (
                        <div className="p-2.5 bg-emerald-950/70 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs font-semibold flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                          <span>{ownerPasswordChangeSuccess}</span>
                        </div>
                      )}

                      <form onSubmit={handleChangeOwnerPassword} className="space-y-3">
                        {!userIsOwner && (
                          <div>
                            <label className="text-xs font-bold text-slate-300 block mb-1">
                              Current Owner Password:
                            </label>
                            <input
                              type="password"
                              required
                              value={currentOwnerPasswordInput}
                              onChange={(e) => setCurrentOwnerPasswordInput(e.target.value)}
                              placeholder="Enter current owner password"
                              className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl px-3 py-2 text-white font-mono text-sm outline-none"
                            />
                          </div>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="text-xs font-bold text-slate-300 block mb-1">
                              New Owner Password:
                            </label>
                            <input
                              type={showNewPasswordText ? 'text' : 'password'}
                              required
                              minLength={4}
                              value={newOwnerPasswordInput}
                              onChange={(e) => setNewOwnerPasswordInput(e.target.value)}
                              placeholder="Enter new password (min 4 chars)"
                              className="w-full bg-slate-950 border border-amber-500/40 focus:border-amber-400 rounded-xl px-3 py-2 text-white font-mono text-sm outline-none"
                            />
                          </div>

                          <div>
                            <label className="text-xs font-bold text-slate-300 block mb-1">
                              Confirm New Password:
                            </label>
                            <input
                              type={showNewPasswordText ? 'text' : 'password'}
                              required
                              minLength={4}
                              value={confirmOwnerPasswordInput}
                              onChange={(e) => setConfirmOwnerPasswordInput(e.target.value)}
                              placeholder="Re-enter new password"
                              className="w-full bg-slate-950 border border-amber-500/40 focus:border-amber-400 rounded-xl px-3 py-2 text-white font-mono text-sm outline-none"
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-1">
                          <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-400 hover:text-slate-300 select-none">
                            <input
                              type="checkbox"
                              checked={showNewPasswordText}
                              onChange={(e) => setShowNewPasswordText(e.target.checked)}
                              className="w-3.5 h-3.5 accent-amber-500 rounded"
                            />
                            <span>Show password text</span>
                          </label>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setShowOwnerPasswordModal(false)}
                              className="px-3 py-1.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 text-xs font-medium cursor-pointer"
                            >
                              Cancel
                            </button>
                            <button
                              type="submit"
                              className="px-4 py-1.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1 cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Save Password</span>
                            </button>
                          </div>
                        </div>
                      </form>
                    </div>
                  )}

              {/* Staff Accounts List */}
              <div className="space-y-2.5">
                {formData.staffAccounts.map((staff) => (
                  <div
                    key={staff.id}
                    className="p-3 bg-slate-800/60 rounded-2xl border border-slate-700/80 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-slate-700 flex items-center justify-center font-bold text-amber-300">
                        {staff.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{staff.name}</span>
                          <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            {staff.role}
                          </span>
                        </div>
                        <div className="text-slate-400 text-[11px] mt-0.5 flex items-center gap-3">
                          <span className="font-mono text-slate-300">Password: ••••••••</span>
                          {staff.phone && <span>Ph: {staff.phone}</span>}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {staff.role === 'owner' ? (
                        <button
                          type="button"
                          onClick={() => {
                            setShowOwnerPasswordModal(true);
                            setOwnerPasswordChangeError('');
                            setOwnerPasswordChangeSuccess('');
                          }}
                          className="px-2.5 py-1 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
                          title="Change Owner Password"
                        >
                          <Key className="w-3 h-3 text-amber-400" />
                          <span>Change Password</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleDeleteStaff(staff.id)}
                          className="p-1.5 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                          title="Delete staff account"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Staff Account Modal Form */}
              {showAddStaffModal && (
                <div className="p-4 bg-slate-800/90 border border-amber-500/40 rounded-2xl space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-700">
                    <span className="font-bold text-white text-xs">Create New Staff Account</span>
                    <button
                      onClick={() => setShowAddStaffModal(false)}
                      className="text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {staffError && <div className="text-red-400 text-[11px]">{staffError}</div>}

                  <form onSubmit={handleCreateStaff} className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-slate-300 block mb-1">Staff Member Name:</label>
                      <input
                        type="text"
                        required
                        value={newStaffName}
                        onChange={(e) => setNewStaffName(e.target.value)}
                        placeholder="e.g. Rahul Sharma"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1">Role:</label>
                      <select
                        value={newStaffRole}
                        onChange={(e) => setNewStaffRole(e.target.value as any)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                      >
                        <option value="cashier">Cashier (Billing Only)</option>
                        <option value="manager">Store Manager</option>
                        <option value="owner">Owner / Admin</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1">Login PIN / Password (4-digits):</label>
                      <input
                        type="password"
                        required
                        maxLength={8}
                        value={newStaffPin}
                        onChange={(e) => setNewStaffPin(e.target.value)}
                        placeholder="Enter PIN / password"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1">Phone Number (Optional):</label>
                      <input
                        type="tel"
                        value={newStaffPhone}
                        onChange={(e) => setNewStaffPhone(e.target.value)}
                        placeholder="10-digit mobile"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                      />
                    </div>

                    <div className="sm:col-span-2 flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setShowAddStaffModal(false)}
                        className="px-3 py-1.5 rounded-lg text-slate-400 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg"
                      >
                        Save Staff Account
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </>
          )}
        </div>
      )}

          {/* TAB 4: THERMAL PRINTER INTEGRATION */}
          {activeTab === 'printer' && (
            <div className="space-y-4">
              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white text-sm">Thermal POS Receipt Printer Connection</h4>
                    <p className="text-slate-400 text-xs">
                      Connect Bluetooth / USB Serial ESC/POS 58mm or 80mm thermal receipt printers.
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        printerConnected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
                      }`}
                    />
                    <span className="text-[11px] font-bold text-slate-300">
                      {printerConnected ? 'HARDWARE CONNECTED' : 'READY (BROWSER PRINT)'}
                    </span>
                  </div>
                </div>

                {printerStatusMsg && (
                  <div className="p-2.5 bg-blue-950/60 border border-blue-800/80 rounded-xl text-blue-200 text-xs">
                    {printerStatusMsg}
                  </div>
                )}

                {/* Connection Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    disabled={printerConnecting}
                    onClick={handleConnectBluetooth}
                    className="p-3 rounded-xl bg-slate-900 hover:bg-slate-750 border border-blue-500/40 text-left transition-all flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <Bluetooth className="w-5 h-5 text-blue-400" />
                      <div>
                        <div className="font-bold text-white text-xs">Connect Bluetooth Printer</div>
                        <div className="text-[10px] text-slate-400">NAYAB, TVS, NGX, MPT-II, RPP02</div>
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    disabled={printerConnecting}
                    onClick={handleConnectSerial}
                    className="p-3 rounded-xl bg-slate-900 hover:bg-slate-750 border border-cyan-500/40 text-left transition-all flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <Usb className="w-5 h-5 text-cyan-400" />
                      <div>
                        <div className="font-bold text-white text-xs">Connect USB / Serial Printer</div>
                        <div className="text-[10px] text-slate-400">POS-58 / POS-80 via USB Cable</div>
                      </div>
                    </div>
                  </button>
                </div>

                {/* Printer Settings Config */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Receipt Paper Roll Width:</label>
                    <select
                      value={formData.printerConfig.paperWidth}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          printerConfig: {
                            ...formData.printerConfig,
                            paperWidth: e.target.value as '58mm' | '80mm',
                          },
                        })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                    >
                      <option value="58mm">58mm (Standard Compact Kirana Roll - 32 chars)</option>
                      <option value="80mm">80mm (Wide Thermal Roll - 48 chars)</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-900 rounded-xl border border-slate-700/80">
                    <div>
                      <div className="font-semibold text-white">Auto-Print on Bill Settlement:</div>
                      <div className="text-[10px] text-slate-400">Prints bill automatically after payment</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData.printerConfig.autoPrintOnSale}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          printerConfig: {
                            ...formData.printerConfig,
                            autoPrintOnSale: e.target.checked,
                          },
                        })
                      }
                      className="w-4 h-4 accent-blue-500 cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-900 rounded-xl border border-slate-700/80">
                    <div>
                      <div className="font-semibold text-white">Print Dynamic UPI QR Code on Bill Slip:</div>
                      <div className="text-[10px] text-slate-400">Prints scan & pay QR code directly on thermal receipt</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData.printerConfig.printQrCodeOnSlip !== false}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          printerConfig: {
                            ...formData.printerConfig,
                            printQrCodeOnSlip: e.target.checked,
                          },
                        })
                      }
                      className="w-4 h-4 accent-emerald-500 cursor-pointer"
                    />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleTestPrint}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Test Slip</span>
                  </button>

                  {printerConnected && (
                    <button
                      type="button"
                      onClick={handleDisconnectPrinter}
                      className="px-3 py-2 bg-slate-750 hover:bg-red-600/40 text-red-300 rounded-xl text-xs font-semibold transition-colors"
                    >
                      Disconnect Hardware
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: SHOP PROFILE */}
          {activeTab === 'profile' && (
            <div className="space-y-3.5">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Shop / Business Name:</label>
                <input
                  type="text"
                  required
                  value={formData.shopName}
                  onChange={(e) => setFormData({ ...formData, shopName: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-medium"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Shop Address:</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-300 block mb-1">Shop Phone:</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-300 block mb-1">Default GST Rate (%):</label>
                  <select
                    value={formData.defaultTaxRate}
                    onChange={(e) =>
                      setFormData({ ...formData, defaultTaxRate: Number(e.target.value) })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none"
                  >
                    <option value={0}>0% (Tax-Free Kirana)</option>
                    <option value={5}>5% (Spices & Basic Groceries)</option>
                    <option value={12}>12% (Packaged Items)</option>
                    <option value={18}>18% (Standard GST)</option>
                    <option value={28}>28%</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">GSTIN Number (Optional):</label>
                <input
                  type="text"
                  value={formData.gstin || ''}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value })}
                  placeholder="e.g. 07AAAAA0000A1Z5"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono uppercase"
                />
              </div>
            </div>
          )}

          {/* TAB 6: DATA BACKUP & RESTORE */}
          {activeTab === 'backup' && (
            <div className="space-y-4">
              {/* Alert Feedback Messages */}
              {backupSuccessMsg && (
                <div className="p-3 bg-emerald-950/70 border border-emerald-500/60 rounded-2xl text-emerald-200 text-xs flex items-center gap-2.5 shadow-lg animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span className="font-medium">{backupSuccessMsg}</span>
                </div>
              )}

              {backupErrorMsg && (
                <div className="p-3 bg-red-950/70 border border-red-500/60 rounded-2xl text-red-200 text-xs flex items-center gap-2.5 shadow-lg animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <span className="font-medium">{backupErrorMsg}</span>
                </div>
              )}

              {restoreSuccessMsg && (
                <div className="p-3 bg-teal-950/70 border border-teal-500/60 rounded-2xl text-teal-200 text-xs flex items-center gap-2.5 shadow-lg animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-teal-400 flex-shrink-0" />
                  <span className="font-medium">{restoreSuccessMsg}</span>
                </div>
              )}

              {/* Pending Restore Confirmation Modal/Card */}
              {pendingRestoreData && (
                <div className="p-4 bg-amber-950/40 border border-amber-500/60 rounded-2xl space-y-3 shadow-xl animate-in zoom-in-95">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>Confirm Data Restore from Backup</span>
                  </div>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    You uploaded a backup for{' '}
                    <strong className="text-white font-semibold">"{pendingRestoreData.storeName}"</strong>{' '}
                    created on{' '}
                    <span className="text-amber-300 font-medium">
                      {new Date(pendingRestoreData.backupTimestamp).toLocaleString()}
                    </span>
                    .
                  </p>

                  <div className="grid grid-cols-3 gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 text-center text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Products</span>
                      <strong className="text-purple-300 font-mono text-sm">
                        {pendingRestoreData.summary.totalProducts}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Transactions</span>
                      <strong className="text-emerald-300 font-mono text-sm">
                        {pendingRestoreData.summary.totalTransactions}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Customers</span>
                      <strong className="text-amber-300 font-mono text-sm">
                        {pendingRestoreData.summary.totalCustomers}
                      </strong>
                    </div>
                  </div>

                  <p className="text-[11px] text-amber-300/80">
                    ⚠️ Restoring will overwrite current live inventory, transaction ledger, and udhaar records.
                  </p>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setPendingRestoreData(null)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-semibold transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmRestore}
                      className="px-4 py-1.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-md transition-all"
                    >
                      <Check className="w-4 h-4" />
                      <span>Confirm & Restore All Data</span>
                    </button>
                  </div>
                </div>
              )}

              {/* CARD 1: AUTOMATIC FULL DATA BACKUP CONFIGURATION */}
              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <ShieldCheck className="w-5 h-5 text-cyan-400" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-sm">Automatic Full Data Backup</h4>
                      <p className="text-slate-400 text-xs">
                        Automatically safeguard your entire store inventory, transactions, and customer udhaar to avoid accidental data loss.
                      </p>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-md font-semibold text-[10px] uppercase tracking-wide border flex-shrink-0 ${
                      formData.autoBackupEnabled !== false
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : 'bg-slate-700 text-slate-400 border-slate-600'
                    }`}
                  >
                    {formData.autoBackupEnabled !== false ? 'Auto-Backup Active' : 'Disabled'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-700/60">
                  {/* Enable Switch */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                    <div>
                      <span className="font-semibold text-white block text-xs">Automatic Backup Service</span>
                      <span className="text-[11px] text-slate-400">Creates snapshots on shift changes</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.autoBackupEnabled !== false}
                        onChange={(e) => {
                          const updated = { ...formData, autoBackupEnabled: e.target.checked };
                          setFormData(updated);
                          onSaveSettings(updated);
                        }}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-600"></div>
                    </label>
                  </div>

                  {/* Frequency Selector */}
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
                    <label className="font-semibold text-white block text-xs">Backup Frequency</label>
                    <select
                      value={formData.autoBackupFrequency || 'daily'}
                      onChange={(e) => {
                        const updated = {
                          ...formData,
                          autoBackupFrequency: e.target.value as 'daily' | 'each_shift' | 'weekly',
                        };
                        setFormData(updated);
                        onSaveSettings(updated);
                      }}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white text-xs focus:outline-none focus:border-cyan-500"
                    >
                      <option value="daily">Daily on App Open / Shift End</option>
                      <option value="each_shift">Each Shift (Every 6 Hours)</option>
                      <option value="weekly">Weekly Full Snapshot</option>
                    </select>
                  </div>
                </div>

                {/* Status & Instant Snapshot Button */}
                <div className="flex items-center justify-between flex-wrap gap-2 pt-1 text-xs">
                  <div className="text-slate-400">
                    <span>Last Full Backup: </span>
                    <strong className="text-cyan-300 font-mono">
                      {formData.lastBackupTimestamp
                        ? new Date(formData.lastBackupTimestamp).toLocaleString()
                        : 'Not exported yet'}
                    </strong>
                  </div>

                  <button
                    type="button"
                    onClick={handleTakeImmediateSnapshot}
                    className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-cyan-300 hover:text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <HardDrive className="w-3.5 h-3.5" />
                    <span>Save Internal Snapshot Now</span>
                  </button>
                </div>
              </div>

              {/* CARD 2: ONE-CLICK FULL DATA EXPORT TO JSON */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-850 p-4 rounded-2xl border border-cyan-500/40 shadow-xl space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileJson className="w-5 h-5 text-cyan-400" />
                    <div>
                      <h4 className="font-bold text-white text-sm">Download Full Backup (.JSON File)</h4>
                      <p className="text-slate-400 text-xs">
                        Exports complete store catalog, sales history, customer udhaar records, and store configurations into a single JSON file.
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded-full border border-cyan-500/30 font-semibold">
                    COMPLETE OFFLINE FILE
                  </span>
                </div>

                {/* Data Overview Chips */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">Inventory Products</span>
                    <span className="text-base font-bold text-purple-300 font-mono">{products.length} Items</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">Transactions Ledger</span>
                    <span className="text-base font-bold text-emerald-300 font-mono">
                      {transactions.length} Records
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">Customer Udhaar</span>
                    <span className="text-base font-bold text-amber-300 font-mono">{customers.length} Accounts</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                    <span className="text-slate-400 block text-[10px] uppercase font-semibold">Staff & Cashier Accounts</span>
                    <span className="text-base font-bold text-cyan-300 font-mono">
                      {formData.staffAccounts?.length || 1} Staff
                    </span>
                  </div>
                </div>

                {/* Download Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleDownloadFullBackup}
                    disabled={isExporting}
                    className="w-full py-3 bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-cyan-950 transition-all active:scale-[0.99]"
                  >
                    {isExporting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Generating JSON Backup...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        <span>Download Full Data Backup (JSON File) / पूरा बैकअप डाउनलोड करें</span>
                      </>
                    )}
                  </button>
                  <p className="text-[10px] text-slate-400 text-center mt-1.5">
                    Downloads an offline file you can save on your computer, phone, or Google Drive for complete safety.
                  </p>
                </div>
              </div>

              {/* CARD 3: RESTORE / IMPORT BACKUP FROM JSON */}
              <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-3">
                <div className="flex items-center gap-2">
                  <Upload className="w-4 h-4 text-purple-400" />
                  <h4 className="font-bold text-white text-sm">Restore Data from JSON Backup</h4>
                </div>
                <p className="text-slate-400 text-xs">
                  Restore your store by selecting a previously downloaded JSON backup file. All products, transactions, and customers will be verified before restoring.
                </p>

                <div className="flex items-center gap-3">
                  <label className="cursor-pointer px-4 py-2 bg-slate-700 hover:bg-slate-650 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors border border-slate-600 shadow-sm">
                    <Upload className="w-4 h-4 text-purple-400" />
                    <span>Select Backup JSON File</span>
                    <input
                      type="file"
                      accept=".json,application/json"
                      onChange={handleFileUploadForRestore}
                      className="hidden"
                    />
                  </label>
                  <span className="text-[11px] text-slate-400">Supported format: .json backup files</span>
                </div>
              </div>

              {/* CARD 4: RECENT LOCAL SNAPSHOTS */}
              {localSnapshotsMeta.length > 0 && (
                <div className="bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800 space-y-2">
                  <h5 className="font-semibold text-xs text-slate-300 uppercase tracking-wider">
                    Recent Auto-Backup Snapshots in Browser Storage
                  </h5>
                  <div className="space-y-1.5">
                    {localSnapshotsMeta.map((snap, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-2 rounded-xl bg-slate-800/70 border border-slate-700/60 text-xs"
                      >
                        <div>
                          <span className="font-mono text-cyan-300 font-semibold">
                            {new Date(snap.timestamp).toLocaleString()}
                          </span>
                          <span className="text-[11px] text-slate-400 ml-2">
                            ({snap.countProducts} items, {snap.countTx} txs, {snap.sizeKb} KB)
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleDownloadFullBackup}
                          className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold"
                        >
                          Export →
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 7: OWNER REPORTS (DAILY, WEEKLY, MONTHLY, YEARLY) */}
          {activeTab === 'reports' && (
            <OwnerReportsTab
              transactions={transactions}
              customers={customers}
              products={products}
              storeSettings={formData}
              cashFlow={cashFlow}
              onOpenBillsManager={onOpenBillsManager}
            />
          )}
        </div>
      </div>
    </div>
  );
};

