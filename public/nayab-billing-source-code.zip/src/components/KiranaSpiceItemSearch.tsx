import React, { useState, useMemo } from 'react';
import {
  Search,
  Scale,
  Plus,
  Edit2,
  Check,
  X,
  Camera,
  ShoppingBag,
  Sparkles,
  Barcode,
  Package,
  SlidersHorizontal,
  ChevronDown,
  Globe,
} from 'lucide-react';
import { Product, ProductCategory, UnitType, BillItem } from '../types';
import { CATEGORY_LABELS } from '../data/defaultInventory';

interface KiranaSpiceItemSearchProps {
  products: Product[];
  onAddItemToBill: (item: Omit<BillItem, 'id'>) => void;
  onSelectProductForWeight: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onOpenPosCatalog?: () => void;
  onOpenBarcodeScanner?: () => void;
}

export const KiranaSpiceItemSearch: React.FC<KiranaSpiceItemSearchProps> = ({
  products,
  onAddItemToBill,
  onSelectProductForWeight,
  onUpdateProduct,
  onOpenPosCatalog,
  onOpenBarcodeScanner,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [editRate, setEditRate] = useState<number>(0);
  const [editStock, setEditStock] = useState<number>(0);
  const [editSuccessId, setEditSuccessId] = useState<string | null>(null);
  const [quickEditMode, setQuickEditMode] = useState<boolean>(false);

  // Filter products based on search query and category
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        (p.hindiName && p.hindiName.toLowerCase().includes(q)) ||
        (p.barcode && p.barcode.toLowerCase().includes(q)) ||
        p.category.toLowerCase().includes(q);

      const matchesCategory =
        selectedCategory === 'all' || p.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });
  }, [products, searchTerm, selectedCategory]);

  const handleStartEdit = (p: Product) => {
    setEditingProductId(p.id);
    setEditRate(p.rate);
    setEditStock(p.stock !== undefined ? p.stock : 100);
  };

  const handleSaveEdit = (p: Product) => {
    if (editRate <= 0) return;
    const updated: Product = {
      ...p,
      rate: Number(editRate),
      stock: Number(editStock),
    };
    onUpdateProduct(updated);
    setEditingProductId(null);
    setEditSuccessId(p.id);
    setTimeout(() => setEditSuccessId(null), 2500);
  };

  const handleCancelEdit = () => {
    setEditingProductId(null);
  };

  const handleQuickAddSingle = (p: Product) => {
    onAddItemToBill({
      productId: p.id,
      name: p.name,
      hindiName: p.hindiName,
      quantity: 1,
      unit: p.unit,
      rate: p.rate,
      total: p.rate,
    });
  };

  return (
    <div className="bg-slate-900/90 rounded-3xl p-3.5 sm:p-4 border border-purple-500/30 shadow-xl space-y-3">
      {/* Header & Section Title */}
      <div className="flex items-center justify-between gap-2 flex-wrap pb-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-purple-500/20">
            <ShoppingBag className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-extrabold text-xs sm:text-sm text-white tracking-tight flex items-center gap-1.5">
              <span>Select Kirana and Spice Inventory Item Search</span>
            </h3>
            <p className="text-[10px] text-slate-400">
              किराना व मसाला सामान खोजें • Editable Rates & Stock Qty
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Quick Edit Mode Toggle */}
          <button
            type="button"
            onClick={() => setQuickEditMode(!quickEditMode)}
            className={`px-2 py-1 rounded-xl text-[11px] font-semibold border flex items-center gap-1 transition-all ${
              quickEditMode
                ? 'bg-purple-600/30 text-purple-200 border-purple-500/50 shadow-sm'
                : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border-slate-700'
            }`}
            title="Toggle Quick Edit for Rates & Stock"
          >
            <Edit2 className="w-3 h-3 text-purple-400" />
            <span className="hidden sm:inline">
              {quickEditMode ? 'Close Edit Mode' : 'Edit Rates & Qty'}
            </span>
          </button>

          {onOpenBarcodeScanner && (
            <button
              type="button"
              onClick={onOpenBarcodeScanner}
              className="p-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs transition-colors"
              title="Scan Barcode with Camera"
            >
              <Camera className="w-3.5 h-3.5 text-emerald-400" />
            </button>
          )}

          {onOpenPosCatalog && (
            <button
              type="button"
              onClick={onOpenPosCatalog}
              className="px-2 py-1 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-[11px] font-semibold transition-colors"
            >
              All ({products.length})
            </button>
          )}
        </div>
      </div>

      {/* Search Input Box */}
      <div className="relative">
        <Search className="w-4 h-4 text-purple-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search kirana, spices, dals, oils (e.g. Jeera, Haldi, Atta, Kaju)..."
          className="w-full bg-slate-950 border border-slate-700/90 focus:border-purple-500 rounded-2xl pl-9 pr-8 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500/50 transition-all shadow-inner"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] no-scrollbar">
        <button
          type="button"
          onClick={() => setSelectedCategory('all')}
          className={`px-2.5 py-1 rounded-xl font-semibold whitespace-nowrap transition-all border ${
            selectedCategory === 'all'
              ? 'bg-purple-600 text-white border-purple-500 shadow-sm'
              : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700/80'
          }`}
        >
          All Items ({products.length})
        </button>
        {Object.entries(CATEGORY_LABELS).map(([catKey, catConf]) => {
          const count = products.filter((p) => p.category === catKey).length;
          if (count === 0 && selectedCategory !== catKey) return null;
          return (
            <button
              key={catKey}
              type="button"
              onClick={() => setSelectedCategory(catKey)}
              className={`px-2.5 py-1 rounded-xl font-medium whitespace-nowrap transition-all border ${
                selectedCategory === catKey
                  ? 'bg-purple-600 text-white border-purple-500 shadow-sm'
                  : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700/80'
              }`}
            >
              {catConf.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Items Scrollable Grid / List */}
      <div className="max-h-60 sm:max-h-64 overflow-y-auto space-y-2 pr-1 select-none scroll-smooth">
        {filteredProducts.length === 0 ? (
          <div className="py-6 text-center text-slate-400 text-xs space-y-2">
            <Package className="w-7 h-7 mx-auto text-slate-600" />
            <p>No inventory items found matching "{searchTerm}"</p>
            {onOpenPosCatalog && (
              <button
                type="button"
                onClick={onOpenPosCatalog}
                className="px-3 py-1 bg-purple-600/30 hover:bg-purple-600 text-purple-200 hover:text-white rounded-xl text-xs font-semibold border border-purple-500/40 transition-colors"
              >
                + Add or Search in POS Catalog
              </button>
            )}
          </div>
        ) : (
          filteredProducts.map((p) => {
            const isEditing = editingProductId === p.id || quickEditMode;
            const isSuccess = editSuccessId === p.id;

            return (
              <div
                key={p.id}
                className={`p-2.5 rounded-2xl border transition-all ${
                  isEditing
                    ? 'bg-slate-800 border-purple-500/70 shadow-lg'
                    : isSuccess
                    ? 'bg-emerald-950/40 border-emerald-500/50'
                    : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700/80 hover:border-purple-500/40'
                }`}
              >
                {/* Item Details Row */}
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-xs sm:text-sm text-white truncate">
                        {p.name}
                      </span>
                      {p.hindiName && (
                        <span className="text-[11px] text-amber-300/90 font-medium">
                          ({p.hindiName})
                        </span>
                      )}
                      {p.popular && (
                        <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30">
                          ★ Fast
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400">
                      <span className="capitalize">{p.category.replace('_', ' ')}</span>
                      {p.barcode && (
                        <span className="font-mono text-slate-400 flex items-center gap-0.5">
                          <Barcode className="w-2.5 h-2.5 text-emerald-400" />
                          {p.barcode}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Pricing / Stock Status Display */}
                  <div className="text-right flex-shrink-0">
                    <div className="font-mono font-bold text-sm text-emerald-400">
                      ₹{p.rate}
                      <span className="text-[10px] text-slate-400 font-sans font-normal">
                        /{p.unit}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Stock:{' '}
                      <span className="text-slate-200 font-medium">
                        {p.stock !== undefined ? `${p.stock} ${p.unit}` : '100+'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Inline Editing Form (Editable Rates and Quantity) */}
                {isEditing ? (
                  <div className="mt-2 pt-2 border-t border-slate-700/80 space-y-2">
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <label className="text-[10px] text-slate-300 font-semibold block mb-0.5">
                          Rate (₹ per {p.unit}):
                        </label>
                        <div className="relative">
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-emerald-400 font-bold">
                            ₹
                          </span>
                          <input
                            type="number"
                            step="any"
                            min="0.1"
                            value={editingProductId === p.id ? editRate : p.rate}
                            onChange={(e) => {
                              if (editingProductId !== p.id) {
                                setEditingProductId(p.id);
                                setEditStock(p.stock || 100);
                              }
                              setEditRate(parseFloat(e.target.value) || 0);
                            }}
                            className="w-full bg-slate-950 border border-purple-500 rounded-xl pl-6 pr-2 py-1 text-emerald-400 font-mono font-bold text-xs"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-300 font-semibold block mb-0.5">
                          Stock Qty ({p.unit}):
                        </label>
                        <input
                          type="number"
                          step="any"
                          min="0"
                          value={
                            editingProductId === p.id
                              ? editStock
                              : p.stock !== undefined
                              ? p.stock
                              : 100
                          }
                          onChange={(e) => {
                            if (editingProductId !== p.id) {
                              setEditingProductId(p.id);
                              setEditRate(p.rate);
                            }
                            setEditStock(parseFloat(e.target.value) || 0);
                          }}
                          className="w-full bg-slate-950 border border-purple-500 rounded-xl px-2.5 py-1 text-white font-mono text-xs"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-1.5 pt-1">
                      {editingProductId === p.id && !quickEditMode && (
                        <button
                          type="button"
                          onClick={handleCancelEdit}
                          className="px-2 py-1 rounded-lg text-slate-400 hover:text-white text-[11px]"
                        >
                          Cancel
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleSaveEdit(p)}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold flex items-center gap-1 shadow-sm"
                      >
                        <Check className="w-3 h-3" />
                        <span>Save Rate & Qty</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Action Buttons Row */
                  <div className="mt-2 pt-1.5 border-t border-slate-700/60 flex items-center justify-between gap-1.5 text-xs">
                    {/* Quick Edit Rate & Quantity Button */}
                    <button
                      type="button"
                      onClick={() => handleStartEdit(p)}
                      className="px-2 py-1 text-slate-400 hover:text-purple-300 hover:bg-purple-950/40 rounded-lg text-[11px] flex items-center gap-1 transition-colors"
                      title="Edit Selling Rate or Stock Quantity"
                    >
                      <Edit2 className="w-3 h-3 text-purple-400" />
                      <span>Edit Rate/Qty</span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      {/* Custom Weight Modal Trigger */}
                      <button
                        type="button"
                        onClick={() => onSelectProductForWeight(p)}
                        className="px-2.5 py-1 bg-slate-700/80 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-[11px] font-semibold border border-slate-600/80 flex items-center gap-1 transition-all"
                        title="Add with custom weight (grams / kg)"
                      >
                        <Scale className="w-3 h-3 text-amber-400" />
                        <span>Weight (वजन)</span>
                      </button>

                      {/* 1-Click Fast Add */}
                      <button
                        type="button"
                        onClick={() => handleQuickAddSingle(p)}
                        className="px-2.5 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-[11px] font-bold flex items-center gap-1 shadow-sm transition-all"
                        title={`Add 1 ${p.unit} to current bill`}
                      >
                        <Plus className="w-3 h-3" />
                        <span>+1 {p.unit}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
