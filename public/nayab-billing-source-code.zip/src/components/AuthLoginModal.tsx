import React, { useState } from 'react';
import { Shield, Key, Lock, User, CheckCircle2, AlertCircle, Sparkles, Store } from 'lucide-react';
import { StaffAccount, StoreSettings } from '../types';
import { playKeySound } from '../utils/audio';

interface AuthLoginModalProps {
  isOpen: boolean;
  onClose?: () => void;
  settings: StoreSettings;
  onLoginSuccess: (staff: StaffAccount) => void;
  canDismiss?: boolean;
}

export const AuthLoginModal: React.FC<AuthLoginModalProps> = ({
  isOpen,
  onClose,
  settings,
  onLoginSuccess,
  canDismiss = false,
}) => {
  const [selectedRole, setSelectedRole] = useState<'any' | 'owner' | 'cashier'>('any');
  const [userIdInput, setUserIdInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [rememberSession, setRememberSession] = useState(true);

  if (!isOpen) return null;

  const staffList = settings.staffAccounts || [];
  const ownerAccount = staffList.find((s) => s.role === 'owner') || staffList[0];

  const handleSelectQuickAccount = (staff: StaffAccount) => {
    playKeySound('num');
    const username = staff.username || staff.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    setUserIdInput(username);
    setPasswordInput('');
    setErrorMsg('');
    if (staff.role === 'owner') {
      setSelectedRole('owner');
    } else {
      setSelectedRole('cashier');
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cleanUser = userIdInput.trim().toLowerCase();
    const cleanPin = passwordInput.trim();

    if (!cleanUser) {
      setErrorMsg('Please enter your User ID or Username.');
      return;
    }
    if (!cleanPin) {
      setErrorMsg('Please enter your Password or PIN.');
      return;
    }

    // Find staff by username, id, or name (case-insensitive)
    const matched = staffList.find((s) => {
      const u = (s.username || '').toLowerCase();
      const n = s.name.toLowerCase().replace(/[^a-z0-9]/g, '');
      const rawId = s.id.toLowerCase();
      return (
        u === cleanUser ||
        n === cleanUser ||
        rawId === cleanUser ||
        (cleanUser === 'owner' && s.role === 'owner') ||
        (cleanUser === 'admin' && s.role === 'owner')
      );
    });

    if (!matched) {
      setErrorMsg('User ID not found. Check your credentials or select an account below.');
      return;
    }

    // Verify Password / PIN
    if (matched.pin !== cleanPin) {
      setErrorMsg('Incorrect Password. Please check and try again.');
      return;
    }

    // Login successful
    playKeySound('action');
    if (rememberSession) {
      try {
        localStorage.setItem('nayab_active_session_staff', matched.id);
        localStorage.setItem('nayab_session_authenticated', 'true');
      } catch {
        // ignore
      }
    }
    onLoginSuccess(matched);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-gradient-to-b from-slate-900 via-slate-925 to-slate-950 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-7 shadow-2xl shadow-emerald-950/60 relative overflow-hidden">
        {/* Glow Header Accent */}
        <div className="absolute -top-12 -left-12 w-40 h-40 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-40 h-40 bg-purple-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Brand Banner */}
        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs font-bold tracking-wider">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span>NAYAB SECURE POS</span>
          </div>

          <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            <span>Store Login & Authentication</span>
          </h3>
          <p className="text-xs text-slate-400">
            {settings.shopName || 'NAYAB Smart Kirana & Spices'} • Staff & Owner Access
          </p>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-950/80 border border-rose-500/60 rounded-xl text-rose-200 text-xs flex items-center gap-2 animate-in shake">
            <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Quick Accounts Selector Chips */}
        <div className="mb-4">
          <div className="text-[11px] text-slate-400 font-semibold mb-1.5 flex items-center justify-between">
            <span>Select Account (त्वरित चयन):</span>
            <span className="text-[10px] text-slate-500">Tap to autofill ID</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {staffList.slice(0, 4).map((s) => {
              const isOwner = s.role === 'owner';
              const username = s.username || s.name.toLowerCase().replace(/[^a-z0-9]/g, '');
              const isSelected = userIdInput.toLowerCase() === username.toLowerCase();
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => handleSelectQuickAccount(s)}
                  className={`p-2.5 rounded-xl border text-left transition-all flex items-center gap-2 text-xs cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-950/80 border-emerald-400 text-white shadow-md shadow-emerald-950/40 ring-1 ring-emerald-400'
                      : isOwner
                      ? 'bg-slate-800/80 border-amber-500/40 text-amber-200 hover:bg-slate-750'
                      : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-750'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                      isOwner ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-700 text-slate-200'
                    }`}
                  >
                    {isOwner ? '👑' : '👤'}
                  </div>
                  <div className="overflow-hidden">
                    <div className="font-bold truncate text-white">{s.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono truncate">
                      ID: {username}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleLoginSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-emerald-400" />
              <span>User ID / Username:</span>
            </label>
            <input
              type="text"
              required
              autoFocus
              value={userIdInput}
              onChange={(e) => setUserIdInput(e.target.value)}
              placeholder="e.g. nayab or rahul"
              className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl px-3.5 py-2.5 text-white font-mono text-sm placeholder-slate-500 outline-none transition-all"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Password / PIN:</span>
              </span>
            </label>
            <input
              type="password"
              required
              maxLength={12}
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-900 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl px-3.5 py-2.5 text-white font-mono text-sm placeholder-slate-500 outline-none transition-all tracking-widest"
            />
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-slate-400 hover:text-slate-300 select-none">
              <input
                type="checkbox"
                checked={rememberSession}
                onChange={(e) => setRememberSession(e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded"
              />
              <span>Remember login session</span>
            </label>
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm tracking-wide rounded-xl shadow-lg shadow-emerald-950/80 border border-emerald-400/40 flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
          >
            <Key className="w-4 h-4 text-emerald-200" />
            <span>LOGIN TO NAYAB POS COUNTER</span>
          </button>

          {canDismiss && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="w-full py-2 text-xs text-slate-400 hover:text-white transition-colors"
            >
              Continue without switching account
            </button>
          )}
        </form>
      </div>
    </div>
  );
};
