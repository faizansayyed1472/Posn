import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  BookOpen,
  BarChart3,
  Settings,
  Calculator,
  UserCheck,
  Key,
  X,
  Lock,
  Camera,
  ShieldAlert,
  ShieldCheck,
  Eye,
  EyeOff,
  Sun,
  Moon,
  Clock,
  Receipt,
  LogOut,
  Menu,
  ChevronDown,
  CheckCircle2,
} from 'lucide-react';
import { StoreSettings } from '../types';

interface TohandsHeaderProps {
  storeSettings: StoreSettings;
  todaySalesTotal: number;
  productsCount: number;
  pendingUdhaarTotal: number;
  themeMode?: 'dark' | 'light';
  onToggleTheme?: () => void;
  onOpenPosCatalog: () => void;
  onOpenBarcodeScanner?: () => void;
  onOpenUdhaarLedger: () => void;
  onOpenReports: () => void;
  onOpenBillsManager?: () => void;
  onOpenSettings: (tab?: 'upi' | 'inventory' | 'staff' | 'printer' | 'profile' | 'reports') => void;
  onSwitchStaff: (staffId: string) => void;
  onLogout?: () => void;
}

export const TohandsHeader: React.FC<TohandsHeaderProps> = ({
  storeSettings,
  todaySalesTotal,
  productsCount,
  pendingUdhaarTotal,
  themeMode = 'dark',
  onToggleTheme,
  onOpenPosCatalog,
  onOpenBarcodeScanner,
  onOpenUdhaarLedger,
  onOpenReports,
  onOpenBillsManager,
  onOpenSettings,
  onSwitchStaff,
  onLogout,
}) => {
  const [showStaffSwitchModal, setShowStaffSwitchModal] = useState(false);
  const [selectedStaffId, setSelectedStaffId] = useState<string>('');
  const [inputPin, setInputPin] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');

  // Owner Access restriction states for Reports, Settings & Bills
  const [showOwnerAuthModal, setShowOwnerAuthModal] = useState(false);
  const [pendingOwnerDestination, setPendingOwnerDestination] = useState<'reports' | 'settings' | 'bills'>('reports');
  const [ownerPinInput, setOwnerPinInput] = useState('');
  const [ownerPinError, setOwnerPinError] = useState('');
  const [showOwnerPin, setShowOwnerPin] = useState(false);

  // User Logout Confirmation & Mobile Menu states
  const [showLogoutConfirmModal, setShowLogoutConfirmModal] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Real-time live date and time clock
  const [currentDateTime, setCurrentDateTime] = useState({
    time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentDateTime({
        time: now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        date: now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const activeStaff = storeSettings.staffAccounts.find((s) => s.id === storeSettings.activeStaffId) ||
    storeSettings.staffAccounts[0];
  const isOwner = activeStaff?.role === 'owner';
  const ownerStaff = storeSettings.staffAccounts.find((s) => s.role === 'owner') ||
    storeSettings.staffAccounts[0] || {
      id: 'owner',
      name: 'Owner',
      role: 'owner' as const,
      pin: 'nayab@q6',
      active: true,
    };

  const handleOpenProtectedAction = (destination: 'reports' | 'settings' | 'bills') => {
    if (isOwner) {
      if (destination === 'reports') onOpenReports();
      else if (destination === 'settings') onOpenSettings();
      else if (destination === 'bills') onOpenBillsManager?.();
    } else {
      setPendingOwnerDestination(destination);
      setOwnerPinInput('');
      setOwnerPinError('');
      setShowOwnerAuthModal(true);
    }
  };

  const handleReportsClick = () => {
    handleOpenProtectedAction('reports');
  };

  const handleVerifyOwnerPinAndOpen = (e: React.FormEvent) => {
    e.preventDefault();
    if (ownerStaff.pin && ownerStaff.pin !== ownerPinInput.trim()) {
      setOwnerPinError('Incorrect Owner PIN. Access is strictly restricted to store owner.');
      return;
    }

    setShowOwnerAuthModal(false);
    setOwnerPinInput('');
    setOwnerPinError('');

    if (pendingOwnerDestination === 'reports') onOpenReports();
    else if (pendingOwnerDestination === 'settings') onOpenSettings();
    else if (pendingOwnerDestination === 'bills') onOpenBillsManager?.();
  };

  const handleSwitchToOwnerSession = () => {
    if (ownerStaff.pin && ownerStaff.pin !== ownerPinInput.trim()) {
      setOwnerPinError('Incorrect Owner PIN. Please enter correct PIN to switch.');
      return;
    }

    onSwitchStaff(ownerStaff.id);
    setShowOwnerAuthModal(false);
    setOwnerPinInput('');
    setOwnerPinError('');

    if (pendingOwnerDestination === 'reports') onOpenReports();
    else if (pendingOwnerDestination === 'settings') onOpenSettings();
    else if (pendingOwnerDestination === 'bills') onOpenBillsManager?.();
  };

  const handleConfirmSwitch = (e: React.FormEvent) => {
    e.preventDefault();
    const targetStaff = storeSettings.staffAccounts.find((s) => s.id === selectedStaffId);
    if (!targetStaff) return;

    if (targetStaff.pin && targetStaff.pin !== inputPin.trim()) {
      setPinError('Incorrect PIN / Password. Please re-enter.');
      return;
    }

    onSwitchStaff(targetStaff.id);
    setShowStaffSwitchModal(false);
    setInputPin('');
    setPinError('');
  };

  return (
    <header
      className={`h-16 px-2 sm:px-4 md:px-5 flex items-center justify-between z-30 flex-shrink-0 backdrop-blur-md select-none transition-colors duration-150 relative ${
        themeMode === 'light'
          ? 'bg-white/95 border-b border-slate-200 text-slate-900 shadow-xs'
          : 'bg-slate-900/95 border-b border-slate-800 text-white'
      }`}
    >
      {/* 1. Top Left: Dark / Light Mode Toggle Button & Brand Identity */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        {/* Top Left Corner: Dedicated Dark / Light Mode Toggle Button */}
        {onToggleTheme && (
          <button
            id="theme-toggle-btn-top-left"
            onClick={onToggleTheme}
            className={`h-9 px-2.5 sm:px-3 rounded-xl border text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer select-none flex-shrink-0 active:scale-95 ${
              themeMode === 'dark'
                ? 'bg-slate-800/90 hover:bg-slate-750 text-amber-300 border-amber-500/40 hover:border-amber-400'
                : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300'
            }`}
            title={`Switch to ${themeMode === 'dark' ? 'Light' : 'Dark'} Mode (थीम बदलें)`}
          >
            {themeMode === 'dark' ? (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="text-[11px] font-bold hidden sm:inline">Light</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-indigo-600" />
                <span className="text-[11px] font-bold hidden sm:inline">Dark</span>
              </>
            )}
          </button>
        )}

        {/* Brand Icon */}
        <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center shadow-md shadow-emerald-500/20 flex-shrink-0">
          <Calculator className="w-4 h-4 text-white" />
        </div>

        {/* Store Name & Subtitle */}
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <h1
              className={`font-black text-xs xs:text-sm sm:text-base tracking-tight truncate max-w-[100px] xs:max-w-[140px] sm:max-w-[200px] md:max-w-[260px] lg:max-w-none ${
                themeMode === 'light' ? 'text-slate-900' : 'text-white'
              }`}
              title={storeSettings.shopName}
            >
              {storeSettings.shopName}
            </h1>
            <span className="hidden xl:inline-flex text-[10px] uppercase font-bold tracking-wider bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 px-2 py-0.5 rounded-full">
              POS
            </span>
          </div>
          <p
            className={`text-[10px] truncate hidden 2xl:block ${
              themeMode === 'light' ? 'text-slate-500' : 'text-slate-400'
            }`}
          >
            Smart Kirana Billing • 1,500k Capacity
          </p>
        </div>
      </div>

      {/* 2. Center & Right: Organized Action Buttons */}
      <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
        {/* Real-time Live Clock Pill (Visible on 2xl+ screens) */}
        <div
          className={`hidden 2xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs shadow-xs transition-colors ${
            themeMode === 'light'
              ? 'bg-slate-50 border-slate-200 text-slate-700'
              : 'bg-slate-800/90 border-slate-700/80 text-slate-300'
          }`}
          title="Real-time Store Date & Time"
        >
          <Clock className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-semibold">{currentDateTime.date}</span>
          <span className="text-slate-400 font-mono">•</span>
          <span
            className={`font-mono font-bold tracking-wider ${
              themeMode === 'light' ? 'text-cyan-700' : 'text-cyan-300'
            }`}
          >
            {currentDateTime.time}
          </span>
        </div>

        {/* Today's Sales Pill (Visible on xl+ screens) */}
        <div
          className={`hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs ${
            themeMode === 'light'
              ? 'bg-emerald-50 border-emerald-200 text-slate-700'
              : 'bg-slate-800/90 border-slate-700/80 text-slate-300'
          }`}
          title="Today's Total Store Turnover"
        >
          <span className={themeMode === 'light' ? 'text-slate-500' : 'text-slate-400'}>Sale:</span>
          <span className="font-mono font-bold text-emerald-500 dark:text-emerald-400">
            ₹{todaySalesTotal > 9999 ? `${(todaySalesTotal / 1000).toFixed(1)}k` : todaySalesTotal.toFixed(0)}
          </span>
        </div>

        {/* 1. POS Inventory Catalogue Button (Always visible on all screens) */}
        <button
          onClick={onOpenPosCatalog}
          className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all shadow-sm active:scale-95"
          title="Open Kirana & Spice Item Catalog (1,500k Capacity)"
        >
          <ShoppingBag className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-400 flex-shrink-0" />
          <span className="hidden xs:inline">Items</span>
          <span className="bg-purple-500/30 text-purple-200 text-[10px] font-bold px-1.5 py-0.2 rounded-full font-mono">
            {productsCount > 999 ? `${(productsCount / 1000).toFixed(1)}k` : productsCount}
          </span>
        </button>

        {/* 2. Udhaar Khata Button (Always visible on all screens) */}
        <button
          onClick={onOpenUdhaarLedger}
          className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all shadow-sm active:scale-95"
          title="Customer Udhaar Credit Ledger"
        >
          <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 flex-shrink-0" />
          <span className="hidden xs:inline">Khata</span>
          {pendingUdhaarTotal > 0 && (
            <span className="bg-amber-500/30 text-amber-200 text-[10px] font-bold px-1.5 py-0.2 rounded-full font-mono">
              ₹{pendingUdhaarTotal > 999 ? `${(pendingUdhaarTotal / 1000).toFixed(1)}k` : pendingUdhaarTotal.toFixed(0)}
            </span>
          )}
        </button>

        {/* 3. Barcode Scanner Button (Visible on lg+) */}
        {onOpenBarcodeScanner && (
          <button
            onClick={onOpenBarcodeScanner}
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition-all shadow-sm"
            title="Scan items with Camera Barcode Scanner"
          >
            <Camera className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden xl:inline">Scan</span>
          </button>
        )}

        {/* 4. Bills & Transactions Manager (Visible on lg+) */}
        {onOpenBillsManager && (
          <button
            onClick={() => handleOpenProtectedAction('bills')}
            className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
              isOwner
                ? 'bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border-blue-500/30 shadow-sm'
                : 'bg-amber-950/30 hover:bg-amber-900/40 text-amber-200 border-amber-600/40'
            }`}
            title="Search, View & Edit Sales, Online UPI, Expense & Udhaar Bills (Owner)"
          >
            <Receipt className={`w-3.5 h-3.5 ${isOwner ? 'text-blue-400' : 'text-amber-400'}`} />
            <span>Bills</span>
            {!isOwner && <Lock className="w-2.5 h-2.5 text-amber-400" />}
          </button>
        )}

        {/* 5. Dashboard / Reports Button (Visible on xl+) */}
        <button
          onClick={handleReportsClick}
          className={`hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
            isOwner
              ? 'bg-slate-800 hover:bg-slate-750 text-slate-200 border-slate-700'
              : 'bg-amber-950/30 hover:bg-amber-900/40 text-amber-200 border-amber-600/40'
          }`}
          title="Daily Sales, Expenses & Balance Reports (Owner Access)"
        >
          <BarChart3 className={`w-3.5 h-3.5 ${isOwner ? 'text-blue-400' : 'text-amber-400'}`} />
          <span>Reports</span>
          {!isOwner && <Lock className="w-2.5 h-2.5 text-amber-400" />}
        </button>

        {/* 6. Settings Button (Visible on lg+) */}
        <button
          onClick={() => handleOpenProtectedAction('settings')}
          className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
            isOwner
              ? themeMode === 'light'
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
                : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border-slate-700'
              : 'bg-amber-950/30 hover:bg-amber-900/40 text-amber-200 border-amber-600/40'
          }`}
          title="Store Settings & Thermal Printer Accounts (Owner Access)"
        >
          <Settings className={`w-3.5 h-3.5 ${isOwner ? (themeMode === 'light' ? 'text-slate-600' : 'text-slate-300') : 'text-amber-400'}`} />
          <span className="hidden xl:inline">Settings</span>
          {!isOwner && <Lock className="w-2.5 h-2.5 text-amber-400" />}
        </button>

        {/* 7. Active User / Cashier Pill (Always visible) */}
        {activeStaff && (
          <button
            onClick={() => {
              setSelectedStaffId(activeStaff.id);
              setShowStaffSwitchModal(true);
            }}
            className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl border text-xs transition-colors cursor-pointer ${
              themeMode === 'light'
                ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
                : 'bg-slate-800/90 hover:bg-slate-750 text-slate-200 border-slate-700/80'
            }`}
            title={`Active User: ${activeStaff.name} (${activeStaff.role}). Click to switch user account.`}
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400 flex-shrink-0" />
            <span className="font-bold text-xs max-w-[60px] xs:max-w-[80px] sm:max-w-[100px] truncate">
              {activeStaff.name}
            </span>
          </button>
        )}

        {/* 8. Dedicated LOGOUT Option in Header Bar (Always visible for quick one-tap logout) */}
        {onLogout && (
          <button
            id="header-logout-button"
            onClick={() => setShowLogoutConfirmModal(true)}
            className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-500 dark:text-rose-400 hover:text-rose-600 dark:hover:text-rose-300 border border-rose-500/30 hover:border-rose-500/50 text-xs font-bold transition-all shadow-sm cursor-pointer select-none flex-shrink-0 active:scale-95"
            title="Lock Counter & Log Out Current User (लॉगआउट करें)"
          >
            <LogOut className="w-3.5 h-3.5 flex-shrink-0 text-rose-500 dark:text-rose-400" />
            <span className="inline font-bold">Logout</span>
          </button>
        )}

        {/* 9. Mobile / Tablet Menu Toggle (< 1024px) for 1-Tap Access to Bills, Scanner, Reports, Settings */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className={`lg:hidden p-1.5 rounded-xl border transition-colors ${
            isMobileMenuOpen
              ? 'bg-indigo-600 text-white border-indigo-500'
              : themeMode === 'light'
              ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
          }`}
          title="Open Actions & Settings Menu"
        >
          {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </button>
      </div>

      {/* Mobile Drawer / Dropdown Menu for Full Feature Access on Phone & Tablet */}
      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-16 left-0 right-0 bg-slate-900/98 border-b border-slate-800 shadow-2xl p-3 z-50 backdrop-blur-xl animate-in slide-in-from-top-2 duration-150 space-y-2.5">
          {/* Mobile Status Bar */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/80 border border-slate-700/70 text-xs">
            <div className="flex items-center gap-1 text-slate-300">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>{currentDateTime.time}</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="text-slate-400">Today:</span>
              <span className="font-mono font-bold text-emerald-400">₹{todaySalesTotal.toFixed(0)}</span>
            </div>
          </div>

          {/* Quick Action Buttons Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            {onOpenBarcodeScanner && (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenBarcodeScanner();
                }}
                className="p-2.5 rounded-xl bg-emerald-600/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-2"
              >
                <Camera className="w-4 h-4 text-emerald-400" />
                <span>Scan Barcode</span>
              </button>
            )}

            {onOpenBillsManager && (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  handleOpenProtectedAction('bills');
                }}
                className="p-2.5 rounded-xl bg-blue-600/20 text-blue-300 border border-blue-500/30 flex items-center gap-2"
              >
                <Receipt className="w-4 h-4 text-blue-400" />
                <span>Bills (बिल)</span>
              </button>
            )}

            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                handleReportsClick();
              }}
              className="p-2.5 rounded-xl bg-slate-800 text-slate-200 border border-slate-700 flex items-center gap-2"
            >
              <BarChart3 className="w-4 h-4 text-cyan-400" />
              <span>Dashboard Reports</span>
            </button>

            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                handleOpenProtectedAction('settings');
              }}
              className="p-2.5 rounded-xl bg-slate-800 text-slate-200 border border-slate-700 flex items-center gap-2"
            >
              <Settings className="w-4 h-4 text-amber-400" />
              <span>Store Settings</span>
            </button>
          </div>

          {/* Mobile User & Logout Footer */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs text-slate-300 truncate">
              <UserCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span className="font-bold truncate">{activeStaff.name}</span>
              <span className="text-slate-500">({activeStaff.role})</span>
            </div>

            {onLogout && (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setShowLogoutConfirmModal(true);
                }}
                className="px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded-xl text-xs font-bold flex items-center gap-1"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Owner Access PIN Authentication Modal (Reports Protection) */}
      {showOwnerAuthModal && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-white">
                    {pendingOwnerDestination === 'settings'
                      ? 'Owner Access Required (Settings)'
                      : pendingOwnerDestination === 'bills'
                      ? 'Owner Access Required (Bills)'
                      : 'Owner Access Required (Dashboard)'}
                  </h4>
                  <p className="text-[11px] text-amber-300/90 font-medium">
                    {pendingOwnerDestination === 'settings'
                      ? 'खाता सेटिंग्स केवल मालिक के लिए सुरक्षित हैं'
                      : pendingOwnerDestination === 'bills'
                      ? 'बिल प्रबंधन केवल मालिक के लिए सुरक्षित है'
                      : 'रिपोर्ट्स केवल मालिक के लिए सुरक्षित हैं'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowOwnerAuthModal(false);
                  setOwnerPinError('');
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-slate-950/90 rounded-2xl border border-slate-800/80 text-xs text-slate-300 space-y-1">
              <p>
                {pendingOwnerDestination === 'settings'
                  ? 'Managing store account settings, staff profiles, PINs/passwords, and configs is restricted strictly to the store owner. Cashiers cannot modify accounts.'
                  : pendingOwnerDestination === 'bills'
                  ? 'Searching, modifying, or deleting transaction records and expense receipts requires Owner verification.'
                  : 'Store financial turnover, profit analytics, and audit ledgers are confidential and restricted strictly to the store owner.'}
              </p>
              <div className="pt-1.5 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800">
                <span>Active Cashier:</span>
                <span className="text-white font-semibold">{activeStaff.name} ({activeStaff.role})</span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>Store Owner:</span>
                <span className="text-amber-400 font-bold">{ownerStaff.name}</span>
              </div>
            </div>

            {ownerPinError && (
              <div className="p-2.5 bg-red-950/70 border border-red-500/50 rounded-xl text-red-200 text-xs font-semibold flex items-center gap-1.5 animate-in fade-in">
                <span>⚠ {ownerPinError}</span>
              </div>
            )}

            <form onSubmit={handleVerifyOwnerPinAndOpen} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Enter Owner PIN / Password (मालिक का पिन):
                </label>
                <div className="relative">
                  <input
                    type={showOwnerPin ? 'text' : 'password'}
                    required
                    autoFocus
                    placeholder="Enter Owner Password / PIN"
                    value={ownerPinInput}
                    onChange={(e) => setOwnerPinInput(e.target.value)}
                    className="w-full bg-slate-950 border border-amber-500/50 focus:border-amber-400 rounded-xl pl-3.5 pr-10 py-2.5 text-white font-mono text-sm tracking-wider focus:outline-none shadow-inner"
                  />
                  <button
                    type="button"
                    onClick={() => setShowOwnerPin(!showOwnerPin)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showOwnerPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-amber-950/80 transition-all"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Unlock & View Reports</span>
                </button>

                <button
                  type="button"
                  onClick={handleSwitchToOwnerSession}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 font-semibold rounded-xl text-[11px] border border-slate-700 transition-colors"
                >
                  Switch Current Session to {ownerStaff.name}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Switch Active Staff Modal */}
      {showStaffSwitchModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-emerald-400" />
                <h4 className="font-bold text-sm text-white">Switch Active Cashier</h4>
              </div>
              <button
                onClick={() => {
                  setShowStaffSwitchModal(false);
                  setPinError('');
                }}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {pinError && <div className="p-2 bg-red-500/10 border border-red-500/30 text-red-300 text-xs rounded-xl">{pinError}</div>}

            <form onSubmit={handleConfirmSwitch} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 block mb-1">Select Staff Member:</label>
                <select
                  value={selectedStaffId}
                  onChange={(e) => setSelectedStaffId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-medium"
                >
                  {storeSettings.staffAccounts.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.role.toUpperCase()})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">Enter 4-Digit Password / PIN:</label>
                <input
                  type="password"
                  required
                  autoFocus
                  maxLength={8}
                  value={inputPin}
                  onChange={(e) => setInputPin(e.target.value)}
                  placeholder="••••"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-center font-mono text-lg tracking-widest focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowStaffSwitchModal(false);
                    onOpenSettings('staff');
                  }}
                  className="text-xs text-amber-400 hover:underline"
                >
                  Manage Accounts →
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowStaffSwitchModal(false)}
                    className="px-3 py-1.5 rounded-xl text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl"
                  >
                    Login
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Lock Counter & Log Out Confirmation Modal */}
      {showLogoutConfirmModal && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border-2 border-rose-500/40 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                  <LogOut className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-white">Lock Counter & Log Out?</h4>
                  <p className="text-[11px] text-rose-300 font-medium">काउंटर लॉक करें और सत्र समाप्त करें</p>
                </div>
              </div>
              <button
                onClick={() => setShowLogoutConfirmModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-slate-950/90 rounded-2xl border border-slate-800/80 text-xs text-slate-300 space-y-2">
              <p>
                Are you sure you want to log out of current session? The billing counter will be locked and will require staff PIN/password to unlock.
              </p>
              <div className="pt-2 flex items-center justify-between text-xs border-t border-slate-800">
                <span className="text-slate-400">Active User:</span>
                <span className="text-white font-bold">{activeStaff.name} ({activeStaff.role})</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowLogoutConfirmModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 font-semibold text-xs transition-colors"
              >
                Cancel (रद्द करें)
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLogoutConfirmModal(false);
                  onLogout?.();
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-rose-950/60 transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span>Yes, Log Out</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
