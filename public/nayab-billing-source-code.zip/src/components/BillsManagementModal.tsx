import React, { useState, useMemo } from 'react';
import {
  X,
  Receipt,
  Search,
  Filter,
  Edit3,
  Printer,
  Trash2,
  Calendar,
  Clock,
  IndianRupee,
  CreditCard,
  Wallet,
  BookOpen,
  ArrowDownRight,
  TrendingDown,
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  User,
  Phone,
  Tag,
  FileText,
} from 'lucide-react';
import { Transaction, CustomerUdhaar, StoreSettings, PaymentMode } from '../types';
import { playKeySound } from '../utils/audio';
import { printReceipt } from '../utils/printer';

interface BillsManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  customers?: CustomerUdhaar[];
  storeSettings: StoreSettings;
  onUpdateTransaction: (updated: Transaction, original?: Transaction) => void;
  onDeleteTransaction: (transactionId: string) => void;
  onPrintTransactionReceipt?: (transaction: Transaction) => void;
}

type BillFilterTab = 'all' | 'sale' | 'online' | 'cash' | 'udhaar' | 'expense';

export const BillsManagementModal: React.FC<BillsManagementModalProps> = ({
  isOpen,
  onClose,
  transactions,
  customers = [],
  storeSettings,
  onUpdateTransaction,
  onDeleteTransaction,
  onPrintTransactionReceipt,
}) => {
  const [activeTab, setActiveTab] = useState<BillFilterTab>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  // Edit form state
  const [editAmount, setEditAmount] = useState<string>('');
  const [editPaymentMode, setEditPaymentMode] = useState<PaymentMode>('cash');
  const [editCustomerName, setEditCustomerName] = useState<string>('');
  const [editCustomerPhone, setEditCustomerPhone] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [editSuccessMsg, setEditSuccessMsg] = useState<string>('');

  // Filtered transactions
  const filteredList = useMemo(() => {
    return transactions.filter((t) => {
      // 1. Tab match
      if (activeTab === 'sale' && t.type !== 'sale') return false;
      if (activeTab === 'online' && (t.type !== 'sale' || t.paymentMode !== 'online_upi')) return false;
      if (activeTab === 'cash' && (t.type !== 'sale' || t.paymentMode !== 'cash')) return false;
      if (activeTab === 'udhaar' && (t.type !== 'sale' || t.paymentMode !== 'credit_udhaar')) return false;
      if (activeTab === 'expense' && t.type !== 'expense') return false;

      // 2. Search query match
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      const rcptMatch = (t.receiptNumber || '').toLowerCase().includes(q);
      const custMatch = (t.customerName || '').toLowerCase().includes(q);
      const staffMatch = (t.staffName || '').toLowerCase().includes(q);
      const noteMatch = (t.notes || '').toLowerCase().includes(q);
      const modeMatch = (t.paymentMode || '').toLowerCase().includes(q);
      const itemMatch = (t.items || []).some((item) =>
        item.name.toLowerCase().includes(q) || (item.hindiName && item.hindiName.includes(q))
      );

      return rcptMatch || custMatch || staffMatch || noteMatch || modeMatch || itemMatch;
    });
  }, [transactions, activeTab, searchQuery]);

  // Tab counters and totals
  const stats = useMemo(() => {
    const saleList = transactions.filter((t) => t.type === 'sale');
    const onlineList = saleList.filter((t) => t.paymentMode === 'online_upi');
    const cashList = saleList.filter((t) => t.paymentMode === 'cash');
    const udhaarList = saleList.filter((t) => t.paymentMode === 'credit_udhaar');
    const expenseList = transactions.filter((t) => t.type === 'expense');

    return {
      allCount: transactions.length,
      saleCount: saleList.length,
      saleTotal: saleList.reduce((acc, t) => acc + t.amount, 0),
      onlineCount: onlineList.length,
      onlineTotal: onlineList.reduce((acc, t) => acc + t.amount, 0),
      cashCount: cashList.length,
      cashTotal: cashList.reduce((acc, t) => acc + t.amount, 0),
      udhaarCount: udhaarList.length,
      udhaarTotal: udhaarList.reduce((acc, t) => acc + t.amount, 0),
      expenseCount: expenseList.length,
      expenseTotal: expenseList.reduce((acc, t) => acc + t.amount, 0),
    };
  }, [transactions]);

  const handleOpenEdit = (t: Transaction) => {
    playKeySound('action');
    setEditingTransaction(t);
    setEditAmount(String(t.amount));
    setEditPaymentMode(t.paymentMode);
    setEditCustomerName(t.customerName || '');
    setEditCustomerPhone(t.customerPhone || '');
    setEditNotes(t.notes || '');
    setEditSuccessMsg('');
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTransaction) return;

    const parsedAmt = parseFloat(editAmount);
    if (isNaN(parsedAmt) || parsedAmt <= 0) {
      alert('Please enter a valid amount greater than 0.');
      return;
    }

    const updated: Transaction = {
      ...editingTransaction,
      amount: parsedAmt,
      paymentMode: editPaymentMode,
      customerName: editCustomerName.trim() || undefined,
      customerPhone: editCustomerPhone.trim() || undefined,
      notes: editNotes.trim() || undefined,
    };

    onUpdateTransaction(updated, editingTransaction);
    setEditSuccessMsg(`Bill #${updated.receiptNumber} updated successfully!`);
    playKeySound('bill');
    setTimeout(() => {
      setEditSuccessMsg('');
      setEditingTransaction(null);
    }, 1200);
  };

  const handleDelete = (t: Transaction) => {
    playKeySound('clear');
    if (
      window.confirm(
        `Are you sure you want to void / delete Bill #${t.receiptNumber} for ₹${t.amount.toFixed(2)}? This cannot be undone.`
      )
    ) {
      onDeleteTransaction(t.id);
    }
  };

  const handlePrint = (t: Transaction) => {
    playKeySound('action');
    if (onPrintTransactionReceipt) {
      onPrintTransactionReceipt(t);
      return;
    }
    printReceipt(
      {
        shopName: storeSettings.shopName || 'NAYAB POS',
        address: storeSettings.address || '',
        phone: storeSettings.phone || '',
        gstin: storeSettings.gstin,
        receiptNumber: t.receiptNumber,
        date: new Date(t.timestamp).toLocaleString('en-IN'),
        cashierName: t.staffName || 'Staff',
        customerName: t.customerName,
        items: t.items || [],
        subtotal: t.baseAmount || t.amount,
        taxAmount: t.taxAmount || 0,
        taxRate: t.taxRate || 0,
        grandTotal: t.amount,
        paymentMode: t.paymentMode,
        upiId: storeSettings.upiId,
        printQrCodeOnSlip: storeSettings.printerConfig?.printQrCodeOnSlip !== false,
      },
      storeSettings
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-5xl bg-gradient-to-b from-slate-900 via-slate-925 to-slate-950 border border-slate-700 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 font-bold">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white">Owner Bills & Ledger Manager</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-emerald-500/30">
                  Owner Dashboard
                </span>
              </div>
              <p className="text-xs text-slate-400">
                View, search & edit Sale Bills, Cash, Online UPI, and Udhaar transactions
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Filters */}
        <div className="px-4 sm:px-5 pt-3 border-b border-slate-800/80 bg-slate-950/60 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-2 min-w-max pb-3">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'all'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <span>All Records ({stats.allCount})</span>
            </button>

            <button
              onClick={() => setActiveTab('sale')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'sale'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-emerald-300" />
              <span>Sale Bills ({stats.saleCount} • ₹{stats.saleTotal.toFixed(0)})</span>
            </button>

            <button
              onClick={() => setActiveTab('online')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'online'
                  ? 'bg-cyan-600 text-white shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5 text-cyan-300" />
              <span>Online UPI Bills ({stats.onlineCount} • ₹{stats.onlineTotal.toFixed(0)})</span>
            </button>

            <button
              onClick={() => setActiveTab('cash')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'cash'
                  ? 'bg-emerald-700 text-white shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <Wallet className="w-3.5 h-3.5 text-emerald-300" />
              <span>Cash Bills ({stats.cashCount} • ₹{stats.cashTotal.toFixed(0)})</span>
            </button>

            <button
              onClick={() => setActiveTab('udhaar')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'udhaar'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-300" />
              <span>Udhaar Bills ({stats.udhaarCount} • ₹{stats.udhaarTotal.toFixed(0)})</span>
            </button>

            <button
              onClick={() => setActiveTab('expense')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === 'expense'
                  ? 'bg-rose-600 text-white shadow-md'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <TrendingDown className="w-3.5 h-3.5 text-rose-300" />
              <span>Expenses ({stats.expenseCount} • ₹{stats.expenseTotal.toFixed(0)})</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="p-3 sm:px-5 sm:py-3 bg-slate-900 border-b border-slate-800 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Bill Receipt No (NB-...), Customer Name, Item Name, or Payment Mode..."
              className="w-full bg-slate-950 border border-slate-750 focus:border-emerald-500 rounded-xl pl-9 pr-8 py-2 text-xs sm:text-sm text-white placeholder-slate-500 outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>
          <div className="text-xs text-slate-400 font-mono font-semibold px-2">
            Showing {filteredList.length} of {transactions.length}
          </div>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-2.5">
          {filteredList.length === 0 ? (
            <div className="text-center py-12 text-slate-500 space-y-2">
              <Receipt className="w-10 h-10 mx-auto text-slate-600 opacity-50" />
              <div className="text-sm font-semibold">No bills or transactions match your search</div>
              <div className="text-xs">Try selecting a different tab or clearing your search term</div>
            </div>
          ) : (
            filteredList.map((t) => {
              const formattedDate = new Date(t.timestamp).toLocaleDateString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
              });
              const formattedTime = new Date(t.timestamp).toLocaleTimeString('en-IN', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
              });

              const isSale = t.type === 'sale';
              const isOnline = t.paymentMode === 'online_upi';
              const isUdhaar = t.paymentMode === 'credit_udhaar';

              return (
                <div
                  key={t.id}
                  className="p-3 sm:p-4 rounded-2xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700/80 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm"
                >
                  {/* Bill Details */}
                  <div className="space-y-1">
                    <div className="flex items-center flex-wrap gap-2">
                      <span className="font-mono font-black text-white text-sm">
                        {t.receiptNumber}
                      </span>

                      {/* Type Badge */}
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          isSale
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {t.type}
                      </span>

                      {/* Mode Badge */}
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 ${
                          isOnline
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                            : isUdhaar
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}
                      >
                        {isOnline ? 'Online UPI' : isUdhaar ? 'Udhaar / Khata' : 'Cash (नकद)'}
                      </span>

                      {t.staffName && (
                        <span className="text-[10px] text-slate-400">
                          Staff: <strong className="text-slate-300">{t.staffName}</strong>
                        </span>
                      )}
                    </div>

                    {/* Timestamp & Customer */}
                    <div className="text-xs text-slate-400 flex items-center flex-wrap gap-2">
                      <span className="flex items-center gap-1 text-slate-300">
                        <Calendar className="w-3 h-3 text-cyan-400" />
                        {formattedDate}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1 font-mono text-cyan-300">
                        <Clock className="w-3 h-3" />
                        {formattedTime}
                      </span>

                      {t.customerName && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-1 text-amber-300 font-semibold">
                            <User className="w-3 h-3" />
                            {t.customerName}
                            {t.customerPhone ? ` (${t.customerPhone})` : ''}
                          </span>
                        </>
                      )}

                      {t.notes && (
                        <>
                          <span>•</span>
                          <span className="text-slate-400 italic font-normal">"{t.notes}"</span>
                        </>
                      )}
                    </div>

                    {/* Items preview if present */}
                    {t.items && t.items.length > 0 && (
                      <div className="text-[11px] text-slate-400 pt-0.5">
                        <span className="text-slate-500">Items: </span>
                        {t.items.slice(0, 3).map((item, idx) => (
                          <span key={idx} className="mr-2 text-slate-300">
                            {item.name} ({item.quantity}{item.unit})
                          </span>
                        ))}
                        {t.items.length > 3 && (
                          <span className="text-slate-500">+{t.items.length - 3} more</span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Amount & Actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 sm:gap-4 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-700/60">
                    <div className="text-left sm:text-right">
                      <div
                        className={`text-lg sm:text-xl font-black font-mono ${
                          isSale ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {isSale ? '+' : '-'}₹{t.amount.toFixed(2)}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        Net Amount
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(t)}
                        className="px-2.5 py-1.5 bg-slate-700 hover:bg-slate-600 text-purple-300 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-all"
                        title="Edit bill details, amount, or payment mode"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>

                      <button
                        onClick={() => handlePrint(t)}
                        className="p-1.5 text-slate-400 hover:text-blue-300 hover:bg-slate-750 rounded-xl transition-colors"
                        title="Print / Re-print receipt slip"
                      >
                        <Printer className="w-4 h-4 text-blue-400" />
                      </button>

                      <button
                        onClick={() => handleDelete(t)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-750 rounded-xl transition-colors"
                        title="Delete / Void bill"
                      >
                        <Trash2 className="w-4 h-4 text-rose-400" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* EDIT BILL DIALOG MODAL */}
        {editingTransaction && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
            <div className="w-full max-w-lg bg-slate-900 border-2 border-purple-500/60 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-300 font-bold text-xs">
                    <Edit3 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-white text-sm">
                      Edit Bill #{editingTransaction.receiptNumber}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Update payment mode (Cash, Online UPI, Udhaar) and amount
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setEditingTransaction(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {editSuccessMsg && (
                <div className="p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>{editSuccessMsg}</span>
                </div>
              )}

              <form onSubmit={handleSaveEdit} className="space-y-4">
                {/* Payment Mode Selector */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    Payment Mode (भुगतान प्रकार बदलें):
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setEditPaymentMode('cash')}
                      className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                        editPaymentMode === 'cash'
                          ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg'
                          : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-750'
                      }`}
                    >
                      <Wallet className="w-4 h-4" />
                      <span>Cash (नकद)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setEditPaymentMode('online_upi')}
                      className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                        editPaymentMode === 'online_upi'
                          ? 'bg-cyan-600 text-white border-cyan-400 shadow-lg'
                          : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-750'
                      }`}
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Online UPI (ऑनलाइन)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setEditPaymentMode('credit_udhaar')}
                      className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                        editPaymentMode === 'credit_udhaar'
                          ? 'bg-amber-600 text-white border-amber-400 shadow-lg'
                          : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-750'
                      }`}
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>Udhaar (खाता / उधार)</span>
                    </button>
                  </div>
                  {editPaymentMode === 'credit_udhaar' && (
                    <div className="text-[11px] text-amber-300/90 mt-1.5 bg-amber-950/40 p-2 rounded-lg border border-amber-500/30">
                      ℹ Changing to Udhaar will automatically add this bill amount to the customer's pending due ledger.
                    </div>
                  )}
                </div>

                {/* Amount */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Bill Amount (₹): <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-emerald-400 font-bold text-sm">
                      ₹
                    </span>
                    <input
                      type="number"
                      required
                      step="any"
                      min="1"
                      value={editAmount}
                      onChange={(e) => setEditAmount(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl pl-8 pr-3 py-2 text-white font-mono font-bold text-base"
                    />
                  </div>
                </div>

                {/* Customer Details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      Customer Name (ग्राहक नाम):
                    </label>
                    <input
                      type="text"
                      value={editCustomerName}
                      onChange={(e) => setEditCustomerName(e.target.value)}
                      placeholder="e.g. Ramesh Bhai"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white text-xs sm:text-sm"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      Phone Number (फ़ोन नंबर):
                    </label>
                    <input
                      type="tel"
                      value={editCustomerPhone}
                      onChange={(e) => setEditCustomerPhone(e.target.value)}
                      placeholder="10-digit mobile"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white text-xs sm:text-sm"
                    />
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Remarks / Notes (टिप्पणी):
                  </label>
                  <input
                    type="text"
                    value={editNotes}
                    onChange={(e) => setEditNotes(e.target.value)}
                    placeholder="e.g. Modified payment mode from cash to online GPay"
                    className="w-full bg-slate-950 border border-slate-700 focus:border-purple-500 rounded-xl px-3 py-2 text-white text-xs"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setEditingTransaction(null)}
                    className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all"
                  >
                    Save Changes (बदलाव सहेजें)
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
