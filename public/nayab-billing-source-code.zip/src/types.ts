export type ProductCategory =
  | 'spices'
  | 'dal_pulses'
  | 'grains_flour'
  | 'oil_ghee'
  | 'dry_fruits'
  | 'packaged_grocery'
  | 'daily_needs'
  | 'general';

export type UnitType = 'kg' | 'g' | 'quintal' | 'packet' | 'litre' | 'piece' | 'pcs' | string;

export interface Product {
  id: string;
  name: string;
  hindiName?: string;
  category: ProductCategory;
  unit: UnitType;
  rate: number; // Price per default unit
  stock?: number;
  popular?: boolean;
  minStockAlert?: number;
  barcode?: string;
  notes?: string;
}

export interface BillItem {
  id: string;
  productId?: string;
  name: string;
  hindiName?: string;
  quantity: number;
  unit: UnitType;
  rate: number;
  total: number;
}

export type PaymentMode = 'cash' | 'online_upi' | 'credit_udhaar';

export interface StaffAccount {
  id: string;
  username?: string; // User ID / login handle
  name: string;
  role: 'owner' | 'manager' | 'cashier';
  pin: string; // Password or 4-digit PIN
  phone?: string;
  active: boolean;
  createdAt?: string;
}

export interface PrinterConfig {
  printerType: 'browser' | 'bluetooth' | 'serial';
  paperWidth: '58mm' | '80mm';
  deviceName?: string;
  autoPrintOnSale: boolean;
  printHeaderNotes?: string;
  printFooterNotes?: string;
  connected?: boolean;
  printQrCodeOnSlip?: boolean; // Toggle whether to print UPI QR code on receipt
}

export interface Transaction {
  id: string;
  receiptNumber: string;
  type: 'sale' | 'expense';
  amount: number;
  baseAmount?: number;
  taxAmount?: number;
  taxRate?: number;
  paymentMode: PaymentMode;
  customerName?: string;
  customerPhone?: string;
  customerId?: string;
  staffName?: string;
  staffId?: string;
  remarks?: string;
  notes?: string;
  timestamp: string;
  items?: BillItem[];
}

export interface CustomerUdhaar {
  id: string;
  name: string;
  phone: string;
  totalDue: number; // Amount they owe store
  lastActive: string;
  notes?: string;
}

export interface StoreSettings {
  shopName: string;
  tagline: string;
  phone: string;
  upiId: string;
  upiName?: string;
  gstin?: string;
  address: string;
  defaultTaxRate: number;
  printerConfig: PrinterConfig;
  staffAccounts: StaffAccount[];
  activeStaffId: string;
  autoBackupEnabled?: boolean;
  autoBackupFrequency?: 'daily' | 'each_shift' | 'weekly';
  lastBackupTimestamp?: string;
}

export interface FullBackupData {
  version: string;
  appName: string;
  backupTimestamp: string;
  storeName: string;
  summary: {
    totalProducts: number;
    totalTransactions: number;
    totalCustomers: number;
    totalUdhaarDue: number;
  };
  data: {
    products: Product[];
    transactions: Transaction[];
    customers: CustomerUdhaar[];
    storeSettings?: Partial<StoreSettings>;
    cashFlow?: {
      openingAmount: number;
      addedAmount: number;
    };
  };
}

export interface WebItemSearchResult {
  name: string;
  hindiName?: string;
  category: ProductCategory;
  suggestedUnit: UnitType;
  typicalMarketRate: number;
  description?: string;
}
