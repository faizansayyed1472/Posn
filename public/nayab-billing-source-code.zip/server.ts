import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "5mb" }));

// Lazy initialize Gemini client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is missing.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Chat endpoint with Search Grounding
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, userLocation, selectedCity, model } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Messages array is required." });
    }

    const ai = getGeminiClient();

    // Select model according to user choice or prompt requirement
    // gemini-3.6-flash with search grounding is excellent for fast real-time grounding
    const chosenModel = model || "gemini-3.6-flash";

    let locationContext = "";
    if (userLocation && typeof userLocation.lat === "number" && typeof userLocation.lng === "number") {
      locationContext += `\nUser's current GPS location: latitude ${userLocation.lat}, longitude ${userLocation.lng}.`;
    }
    if (selectedCity) {
      locationContext += `\nCurrent active map focus city/region: ${selectedCity}.`;
    }

    const systemInstruction = `You are GeoNavigator, an expert interactive location and travel guide powered by real-time Google Search data.
Your mission is to answer location-specific questions with fresh, accurate, real-world data (hours, addresses, recommendations, vibe, prices, transit tips).
${locationContext}

Guidelines:
1. Provide a comprehensive, well-structured, engaging answer with helpful recommendations. Use Markdown formatting (bolding, bullet points, headers) for readability.
2. For each notable place, restaurant, cafe, shop, landmark, or point of interest you recommend, make sure you mention its neighborhood, address, and what makes it special.
3. If the user asks for a tour or itinerary, arrange places in logical walking or transit order.
4. MANDATORY STRUCTURED DATA: At the very end of your response, ALWAYS include a JSON block containing all recommended places with their accurate geographic coordinates (lat, lng), category, address, rating, price level, and a brief highlight.
Format it strictly as:
\`\`\`json:places
[
  {
    "name": "Place Name",
    "category": "restaurant" | "cafe" | "attraction" | "hotel" | "park" | "shopping" | "landmark" | "transit" | "other",
    "address": "Street address, City, Country",
    "lat": 35.6580,
    "lng": 139.7016,
    "rating": 4.7,
    "priceLevel": "$$",
    "highlight": "Key highlight or signature dish/view",
    "hours": "e.g. 9:00 AM - 10:00 PM"
  }
]
\`\`\`
Ensure latitude and longitude coordinates are accurate real-world coordinates so they pin properly on the interactive map. If exact coordinates are not known, provide best-estimate coordinates for that specific address/neighborhood.`;

    // Convert client messages to Gemini content format
    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: m.content }],
    }));

    const response = await ai.models.generateContent({
      model: chosenModel,
      contents,
      config: {
        systemInstruction,
        tools: [{ googleSearch: {} }],
        temperature: 0.7,
      },
    });

    const responseText = response.text || "";

    // Extract structured places JSON if present
    let cleanText = responseText;
    let places: Array<{
      name: string;
      category: string;
      address: string;
      lat: number;
      lng: number;
      rating?: number;
      priceLevel?: string;
      highlight?: string;
      hours?: string;
    }> = [];

    const jsonMatch = responseText.match(/```json:places\s*([\s\S]*?)\s*```/);
    if (jsonMatch && jsonMatch[1]) {
      try {
        places = JSON.parse(jsonMatch[1]);
        // Remove the json block from the displayed chat markdown for clean presentation
        cleanText = responseText.replace(/```json:places\s*[\s\S]*?\s*```/, "").trim();
      } catch (parseErr) {
        console.warn("Failed to parse places JSON block:", parseErr);
      }
    } else {
      // Fallback: check standard ```json [...] ```
      const altJsonMatch = responseText.match(/```json\s*(\[\s*\{[\s\S]*?\}\s*\])\s*```/);
      if (altJsonMatch && altJsonMatch[1]) {
        try {
          const parsed = JSON.parse(altJsonMatch[1]);
          if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].lat && parsed[0].lng) {
            places = parsed;
            cleanText = responseText.replace(/```json\s*\[\s*\{[\s\S]*?\}\s*\]\s*```/, "").trim();
          }
        } catch {
          // ignore
        }
      }
    }

    // Extract grounding search sources & queries if available
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    const searchQueries: string[] = groundingMetadata?.webSearchQueries || [];
    const groundingSources = (groundingMetadata?.groundingChunks || [])
      .map((chunk: any) => chunk.web)
      .filter((web: any) => web && web.uri)
      .map((web: any) => ({
        title: web.title || "Web Source",
        url: web.uri,
      }));

    res.json({
      text: cleanText,
      places,
      searchQueries,
      sources: groundingSources,
      modelUsed: chosenModel,
    });
  } catch (error: any) {
    console.error("Chat API error:", error);
    res.status(500).json({
      error: error?.message || "Failed to generate location response",
    });
  }
});

interface KiranaItemCatalog {
  name: string;
  hindiName: string;
  category: string;
  unit: string;
  rate: number;
  description: string;
  keywords: string[];
}

const CURATED_KIRANA_CATALOG: KiranaItemCatalog[] = [
  // Spices & Masale
  { name: "Star Anise (Chakra Phool)", hindiName: "चक्र फूल", category: "spices", unit: "kg", rate: 750, description: "Aromatic star anise for biryani, garam masala, and rich curries", keywords: ["star", "anise", "chakra", "phool", "badiyan", "star anise"] },
  { name: "Jeera (Cumin Seeds)", hindiName: "साबुत जीरा", category: "spices", unit: "kg", rate: 380, description: "Whole cumin seeds for daily tempering and tadka", keywords: ["jeera", "cumin", "zeera"] },
  { name: "Haldi Powder (Turmeric)", hindiName: "हल्दी पाउडर", category: "spices", unit: "kg", rate: 260, description: "Pure ground turmeric powder with high natural curcumin", keywords: ["haldi", "turmeric"] },
  { name: "Dhaniya Powder (Coriander)", hindiName: "धनिया पाउडर", category: "spices", unit: "kg", rate: 220, description: "Freshly milled aromatic coriander powder", keywords: ["dhaniya", "coriander"] },
  { name: "Lal Mirch Powder (Red Chilli)", hindiName: "लाल मिर्च पाउडर", category: "spices", unit: "kg", rate: 340, description: "Fine red chilli powder for rich heat and color", keywords: ["mirch", "chilli", "lal mirch"] },
  { name: "Kashmiri Lal Mirch", hindiName: "कश्मीरी लाल मिर्च", category: "spices", unit: "kg", rate: 480, description: "Mild heat with deep natural red curry coloring", keywords: ["kashmiri", "deggi"] },
  { name: "Chhoti Elaichi (Green Cardamom)", hindiName: "छोटी इलायची", category: "spices", unit: "kg", rate: 3200, description: "Aromatic bold green cardamom pods (₹320 per 100g)", keywords: ["elaichi", "cardamom", "choti elaichi", "hari elaichi"] },
  { name: "Badi Elaichi (Black Cardamom)", hindiName: "बड़ी इलायची", category: "spices", unit: "kg", rate: 1750, description: "Smoky black cardamom pods for gravies and biryani", keywords: ["badi elaichi", "black cardamom", "moti elaichi"] },
  { name: "Sabut Kali Mirch (Black Pepper)", hindiName: "काली मिर्च", category: "spices", unit: "kg", rate: 850, description: "Bold black peppercorns for rich punjent spice", keywords: ["kali mirch", "black pepper", "pepper"] },
  { name: "Laung (Cloves)", hindiName: "साबुत लौंग", category: "spices", unit: "kg", rate: 1150, description: "Aromatic whole dried flower buds", keywords: ["laung", "clove", "cloves", "lavang"] },
  { name: "Dalchini (Cinnamon Bark)", hindiName: "दालचीनी", category: "spices", unit: "kg", rate: 460, description: "Aromatic sweet cinnamon bark sticks", keywords: ["dalchini", "cinnamon"] },
  { name: "Rai / Sarson (Mustard Seeds)", hindiName: "राई / सरसों दाना", category: "spices", unit: "kg", rate: 110, description: "Black / yellow mustard seeds for tadka and pickling", keywords: ["rai", "sarson", "mustard"] },
  { name: "Saunf (Fennel Seeds)", hindiName: "सौंफ", category: "spices", unit: "kg", rate: 240, description: "Sweet fennel seeds for cooking and mukhwas", keywords: ["saunf", "fennel", "variyali"] },
  { name: "Ajwain (Carom Seeds)", hindiName: "अजवाइन", category: "spices", unit: "kg", rate: 290, description: "Digestive carom seeds for puris and parathas", keywords: ["ajwain", "carom"] },
  { name: "Kasuri Methi", hindiName: "कस्तूरी मेथी", category: "spices", unit: "packet", rate: 45, description: "Dried fenugreek leaves (50g box) for restaurant-style aroma", keywords: ["kasuri", "methi", "kasoori"] },
  { name: "Asafoetida (Hing Vandevi)", hindiName: "हींग (50g)", category: "spices", unit: "packet", rate: 115, description: "Compounded hing for aromatic dal tadka", keywords: ["hing", "asafoetida"] },
  { name: "Kesar (Pure Kashmir Saffron 1g)", hindiName: "शुद्ध केसर", category: "spices", unit: "g", rate: 350, description: "Grade A Mogra saffron threads for sweets and milk", keywords: ["kesar", "saffron", "zafran"] },
  { name: "Jaiphal (Nutmeg)", hindiName: "जायफल", category: "spices", unit: "piece", rate: 25, description: "Whole nutmeg nut for sweets and biryani spices", keywords: ["jaiphal", "nutmeg"] },
  { name: "Javitri (Mace)", hindiName: "जावित्री", category: "spices", unit: "kg", rate: 2200, description: "Fragrant mace spice flower blades", keywords: ["javitri", "mace"] },
  { name: "Tejpatta (Bay Leaves)", hindiName: "तेजपत्ता", category: "spices", unit: "kg", rate: 240, description: "Dried Indian bay leaves for pulao and curries", keywords: ["tejpatta", "bay leaf", "tej patta"] },
  { name: "Amchur Powder", hindiName: "आमचूर पाउडर", category: "spices", unit: "kg", rate: 320, description: "Tangy dry mango powder for snacks and chat", keywords: ["amchur", "mango powder", "aamchur"] },
  { name: "Garam Masala Shahi", hindiName: "शाही गरम मसाला", category: "spices", unit: "kg", rate: 680, description: "Signature 15-spice aromatic blend", keywords: ["garam masala", "garam"] },
  { name: "Biryani Masala", hindiName: "बिरयानी मसाला", category: "spices", unit: "packet", rate: 75, description: "Aromatic Mughlai biryani blend (100g pack)", keywords: ["biryani masala", "biryani"] },

  // Dals & Pulses
  { name: "Toor Dal (Arhar Dal)", hindiName: "अरहर / तूर दाल", category: "dal_pulses", unit: "kg", rate: 165, description: "Unpolished premium yellow pigeon pea dal", keywords: ["toor", "arhar", "tuvar"] },
  { name: "Moong Dal Dhuli (Yellow)", hindiName: "मूंग दाल धुली", category: "dal_pulses", unit: "kg", rate: 130, description: "Yellow split washed moong lentils", keywords: ["moong", "mung"] },
  { name: "Chana Dal", hindiName: "चना दाल", category: "dal_pulses", unit: "kg", rate: 92, description: "Polished split Bengal gram dal", keywords: ["chana dal", "bengal gram"] },
  { name: "Urad Dal Dhuli (White)", hindiName: "उड़द दाल धुली", category: "dal_pulses", unit: "kg", rate: 145, description: "White split skinless urad for idli, dosa, and vada", keywords: ["urad", "udad"] },
  { name: "Masoor Dal (Red Lentils)", hindiName: "मसूर दाल मलका", category: "dal_pulses", unit: "kg", rate: 98, description: "Split red masoor malka lentils", keywords: ["masoor", "malka"] },
  { name: "Kabuli Chana (Chole)", hindiName: "काबुली चना / छोले", category: "dal_pulses", unit: "kg", rate: 135, description: "Large white chickpeas for Amritsari chole", keywords: ["kabuli", "chana", "chole", "chickpeas"] },
  { name: "Kala Chana (Desi)", hindiName: "काला चना", category: "dal_pulses", unit: "kg", rate: 85, description: "Nutritious brown desi chickpeas", keywords: ["kala chana", "black chana"] },
  { name: "Rajma Chitra (Kidney Beans)", hindiName: "चित्रा राजमा", category: "dal_pulses", unit: "kg", rate: 155, description: "Premium spotted Himalayan kidney beans", keywords: ["rajma", "kidney beans"] },
  { name: "Soya Chunks / Nutrela", hindiName: "सोया चंक्स", category: "dal_pulses", unit: "kg", rate: 120, description: "High-protein texturized vegetable protein chunks", keywords: ["soya", "soyabean", "nutrela", "chunks"] },

  // Grains & Flour
  { name: "Chakki Fresh Sharbati Atta", hindiName: "शरबती गेहूं आटा", category: "grains_flour", unit: "kg", rate: 44, description: "100% pure MP Sharbati wheat stone-ground flour", keywords: ["atta", "aata", "wheat flour", "sharbati"] },
  { name: "Basmati Rice Premium 1121", hindiName: "बासमती चावल 1121", category: "grains_flour", unit: "kg", rate: 135, description: "Extra-long grain aged aromatic basmati rice", keywords: ["basmati", "rice", "chawal", "1121"] },
  { name: "Regular Kolam / Sona Masoori Rice", hindiName: "सोना मसूरी चावल", category: "grains_flour", unit: "kg", rate: 62, description: "Daily cooking medium grain lightweight rice", keywords: ["sona", "masoori", "kolam", "rice"] },
  { name: "Maida (Refined Wheat Flour)", hindiName: "मैदा", category: "grains_flour", unit: "kg", rate: 38, description: "Fine bakery-grade all-purpose white flour", keywords: ["maida", "all purpose flour"] },
  { name: "Sooji / Rava (Semolina)", hindiName: "सूजी / रवा", category: "grains_flour", unit: "kg", rate: 42, description: "Granulated wheat semolina for halwa, upma, and idli", keywords: ["sooji", "suji", "rava"] },
  { name: "Besan (Gram Flour)", hindiName: "चना बेसन", category: "grains_flour", unit: "kg", rate: 98, description: "Pure ground chana dal flour for pakoras and sweets", keywords: ["besan", "gram flour"] },
  { name: "Poha (Thick Flattened Rice)", hindiName: "पोहा मोटा", category: "grains_flour", unit: "kg", rate: 55, description: "Clean thick beaten rice flakes for morning breakfast", keywords: ["poha", "pohe", "flattened rice", "chuda"] },
  { name: "Sabudana (Tapioca Sago)", hindiName: "साबुदाना बड़ा", category: "grains_flour", unit: "kg", rate: 90, description: "Pearled sago for fasting khichdi and kheer", keywords: ["sabudana", "sago"] },

  // Oil & Ghee
  { name: "Kachi Ghani Sarson Ka Tel", hindiName: "कच्ची घानी सरसों तेल", category: "oil_ghee", unit: "litre", rate: 158, description: "Cold-pressed pungent mustard cooking oil", keywords: ["sarson", "mustard oil", "kachi ghani", "tel"] },
  { name: "Refined Sunflower Oil (1L Pouch)", hindiName: "रिफाइंड तेल 1L", category: "oil_ghee", unit: "packet", rate: 138, description: "Light refined heart-friendly cooking oil", keywords: ["sunflower oil", "refined oil", "cooking oil", "fortune"] },
  { name: "Pure Desi Cow Ghee", hindiName: "शुद्ध देशी गाय घी", category: "oil_ghee", unit: "litre", rate: 640, description: "Traditional aromatic bilona cow milk ghee", keywords: ["ghee", "desi ghee", "cow ghee"] },

  // Dry Fruits
  { name: "Kaju W320 (Cashews)", hindiName: "काजू साबुत W320", category: "dry_fruits", unit: "kg", rate: 840, description: "Whole bold white crunchy cashew nuts", keywords: ["kaju", "cashew", "cashews"] },
  { name: "Badam Giri (California Almonds)", hindiName: "कैलिफोर्निया बादाम", category: "dry_fruits", unit: "kg", rate: 780, description: "Sweet premium California almond kernels", keywords: ["badam", "almond", "almonds"] },
  { name: "Kishmish (Green Raisins)", hindiName: "हरी किशमिश", category: "dry_fruits", unit: "kg", rate: 340, description: "Long sweet green seedless Afghan raisins", keywords: ["kishmish", "kismis", "raisins"] },
  { name: "Akhrot Giri (Walnut Kernels)", hindiName: "अखरोट गिरी", category: "dry_fruits", unit: "kg", rate: 980, description: "Light half-kernels Kashmiri walnut meat", keywords: ["akhrot", "walnut", "walnuts"] },
  { name: "Pista Salted (Pistachios)", hindiName: "नमकीन पिस्ता", category: "dry_fruits", unit: "kg", rate: 1150, description: "Roasted salted Iranian pistachios", keywords: ["pista", "pistachio", "pistachios"] },
  { name: "Phool Makhana (Fox Nuts)", hindiName: "फूल मखाना", category: "dry_fruits", unit: "kg", rate: 920, description: "Puffed lotus seeds for roasting and sweets", keywords: ["makhana", "fox nuts", "lotus seeds"] },

  // Packaged & Daily Essentials
  { name: "Tata Salt (1kg Pouch)", hindiName: "टाटा नमक 1kg", category: "daily_needs", unit: "packet", rate: 28, description: "Iodised vacuum evaporated salt pouch", keywords: ["salt", "namak", "tata salt"] },
  { name: "Refined White Sugar (Cheeni)", hindiName: "सफेद चीनी", category: "daily_needs", unit: "kg", rate: 45, description: "Crystalline sulfur-free white sugar", keywords: ["sugar", "cheeni", "shakar"] },
  { name: "Red Label / Taj Mahal Tea (250g)", hindiName: "चाय पत्ती 250g", category: "daily_needs", unit: "packet", rate: 140, description: "Strong CTC granular tea blend", keywords: ["tea", "chai", "patti", "red label", "taj mahal"] },
];

function findInCuratedCatalog(query: string): KiranaItemCatalog | null {
  const q = query.toLowerCase().trim();
  for (const item of CURATED_KIRANA_CATALOG) {
    if (item.name.toLowerCase().includes(q) || item.hindiName.includes(q)) {
      return item;
    }
    for (const kw of item.keywords) {
      if (q === kw || q.includes(kw) || kw.includes(q)) {
        return item;
      }
    }
  }
  return null;
}

// Free Open API Kirana & Spice Item Search (DuckDuckGo Free API + Open Food Facts + Wikipedia Open API + Curated Mandi Data)
app.post("/api/item-search", async (req, res) => {
  const { query } = req.body;
  if (!query || typeof query !== "string" || !query.trim()) {
    return res.status(400).json({ error: "Search query is required." });
  }

  const cleanQuery = query.trim();
  const lowerQuery = cleanQuery.toLowerCase();

  // Check if query directly matches our curated Indian Kirana catalog
  const catalogMatch = findInCuratedCatalog(cleanQuery);

  let searchSummary = "Retrieved via Free DuckDuckGo & Open Food API";
  let searchQueries: string[] = [cleanQuery];
  let sources: Array<{ title: string; url: string }> = [];
  let parsedItem: {
    name: string;
    hindiName?: string;
    category?: string;
    suggestedUnit?: string;
    typicalMarketRate?: number;
    description?: string;
    searchSummary?: string;
  } | null = null;

  // 1. Query Free DuckDuckGo Instant Answer API (100% Free, No Gemini API needed)
  try {
    const ddgUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(
      cleanQuery + " spice grocery price india"
    )}&format=json&no_html=1&skip_disambig=1`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);

    const ddgResponse = await fetch(ddgUrl, {
      headers: {
        "User-Agent": "NayabSmartBilling/1.0 (DuckDuckGo Free API)",
        Accept: "application/json",
      },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (ddgResponse.ok) {
      const ddgData = await ddgResponse.json();
      if (ddgData && (ddgData.Heading || ddgData.AbstractText)) {
        const title = ddgData.Heading || cleanQuery;
        const abstract = ddgData.AbstractText || "";
        if (abstract || title) {
          sources.push({
            title: `DuckDuckGo: ${title}`,
            url: ddgData.AbstractURL || `https://duckduckgo.com/?q=${encodeURIComponent(cleanQuery)}`,
          });
          parsedItem = {
            name: title.slice(0, 45),
            category: "spices",
            suggestedUnit: "kg",
            typicalMarketRate: 180,
            description: abstract.slice(0, 160) || "Information retrieved via Free DuckDuckGo Search",
            searchSummary: "Verified via Free DuckDuckGo Instant Search",
          };
        }
      }
    }
  } catch {
    // DuckDuckGo fallback
  }

  // 2. Query Free Open Food Facts API (100% Free Public Food Database)
  try {
    const offUrl = `https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(
      cleanQuery
    )}&search_simple=1&action=process&json=1&page_size=3`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const offResponse = await fetch(offUrl, {
      headers: {
        "User-Agent": "NayabSmartBilling/1.0 (free-api-item-search)",
        Accept: "application/json",
      },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (offResponse.ok) {
      const offData = await offResponse.json();
      if (offData && Array.isArray(offData.products) && offData.products.length > 0) {
        const product = offData.products[0];
        const productName =
          product.product_name_en ||
          product.product_name ||
          product.generic_name_en ||
          product.generic_name;

        if (productName && productName.trim().length > 0) {
          const packaging = (product.quantity || product.packaging || "").toLowerCase();
          let detectedUnit = "kg";
          if (packaging.includes("l") || packaging.includes("ml") || packaging.includes("litre")) {
            detectedUnit = "litre";
          } else if (packaging.includes("packet") || packaging.includes("pouch") || packaging.includes("box")) {
            detectedUnit = "packet";
          } else if (packaging.includes("pc") || packaging.includes("piece")) {
            detectedUnit = "piece";
          } else if (packaging.includes("g") && !packaging.includes("kg")) {
            detectedUnit = "g";
          }

          let detectedCat = "general";
          const catString = (product.categories || "").toLowerCase();
          if (catString.includes("spice") || catString.includes("condiment") || catString.includes("herb")) {
            detectedCat = "spices";
          } else if (catString.includes("oil") || catString.includes("fat") || catString.includes("ghee")) {
            detectedCat = "oil_ghee";
          } else if (catString.includes("pulse") || catString.includes("dal") || catString.includes("legume") || catString.includes("bean")) {
            detectedCat = "dal_pulses";
          } else if (catString.includes("grain") || catString.includes("flour") || catString.includes("cereal") || catString.includes("rice")) {
            detectedCat = "grains_flour";
          } else if (catString.includes("nut") || catString.includes("dry fruit")) {
            detectedCat = "dry_fruits";
          }

          sources.push({
            title: `Open Food Facts: ${productName}`,
            url: `https://world.openfoodfacts.org/product/${product.code || ""}`,
          });

          parsedItem = {
            name: productName.slice(0, 45),
            hindiName: product.product_name_hi || "",
            category: detectedCat,
            suggestedUnit: detectedUnit,
            typicalMarketRate: 120,
            description: product.generic_name || "Verified from Open Food Facts Public Database",
            searchSummary: "Verified from Free Open Food Facts Public Database",
          };
        }
      }
    }
  } catch {
    // Open Food Facts API network timeout/offline fallback
  }

  // 2. Query Free Wikipedia REST API for description, Hindi nomenclature or definition
  if (!parsedItem || !parsedItem.hindiName) {
    try {
      const wikiUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
        cleanQuery + " spice Indian cuisine"
      )}&utf8=&format=json&origin=*`;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);

      const wikiRes = await fetch(wikiUrl, {
        headers: {
          "User-Agent": "NayabSmartBilling/1.0 (free-api-search)",
          Accept: "application/json",
        },
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (wikiRes.ok) {
        const wikiData = await wikiRes.json();
        const firstHit = wikiData?.query?.search?.[0];
        if (firstHit) {
          sources.push({
            title: `Wikipedia: ${firstHit.title}`,
            url: `https://en.wikipedia.org/wiki/${encodeURIComponent(firstHit.title)}`,
          });
          if (!parsedItem) {
            parsedItem = {
              name: firstHit.title,
              category: "spices",
              suggestedUnit: "kg",
              typicalMarketRate: 250,
              description: firstHit.snippet?.replace(/<\/?[^>]+(>|$)/g, "") || "Open Wikipedia retail food reference",
              searchSummary: "Retrieved via Free Wikipedia Open API",
            };
          }
        }
      }
    } catch {
      // Wikipedia network timeout/offline fallback
    }
  }

  // Determine final item values using parsed response, catalog match, or smart heuristic
  let finalName = cleanQuery;
  let finalHindi = "";
  let finalCategory = "general";
  let finalUnit = "kg";
  let finalRate = 120;
  let finalDesc = "Indian Kirana retail market product";

  if (parsedItem && parsedItem.name) {
    finalName = parsedItem.name;
    finalHindi = parsedItem.hindiName || (catalogMatch ? catalogMatch.hindiName : "");
    finalCategory = parsedItem.category || (catalogMatch ? catalogMatch.category : "general");
    finalUnit = parsedItem.suggestedUnit || (catalogMatch ? catalogMatch.unit : "kg");
    finalRate = Number(parsedItem.typicalMarketRate) || (catalogMatch ? catalogMatch.rate : 120);
    finalDesc = parsedItem.description || "Current Indian retail market price";
    searchSummary = parsedItem.searchSummary || "Retrieved from live Kirana market estimates";
  } else if (catalogMatch) {
    finalName = catalogMatch.name;
    finalHindi = catalogMatch.hindiName;
    finalCategory = catalogMatch.category;
    finalUnit = catalogMatch.unit;
    finalRate = catalogMatch.rate;
    finalDesc = catalogMatch.description;
    searchSummary = `Verified from NAYAB Kirana Catalog (${catalogMatch.unit.toUpperCase()} @ ₹${catalogMatch.rate})`;
  } else {
    // Intelligent heuristic classification
    const capitalized = cleanQuery.charAt(0).toUpperCase() + cleanQuery.slice(1);
    finalName = capitalized;
    if (lowerQuery.includes("dal") || lowerQuery.includes("chana") || lowerQuery.includes("rajma") || lowerQuery.includes("moong") || lowerQuery.includes("chole")) {
      finalCategory = "dal_pulses";
      finalRate = 130;
      finalDesc = "Pulses & Lentils retail estimate";
    } else if (lowerQuery.includes("oil") || lowerQuery.includes("tel") || lowerQuery.includes("ghee")) {
      finalCategory = "oil_ghee";
      finalUnit = "litre";
      finalRate = 160;
      finalDesc = "Edible oil & ghee retail packaging";
    } else if (lowerQuery.includes("rice") || lowerQuery.includes("atta") || lowerQuery.includes("flour") || lowerQuery.includes("chawal") || lowerQuery.includes("wheat")) {
      finalCategory = "grains_flour";
      finalRate = 65;
      finalDesc = "Flour & grains retail packing";
    } else if (lowerQuery.includes("kaju") || lowerQuery.includes("badam") || lowerQuery.includes("almond") || lowerQuery.includes("cashew") || lowerQuery.includes("pista") || lowerQuery.includes("walnut")) {
      finalCategory = "dry_fruits";
      finalRate = 850;
      finalDesc = "Dry fruit & nuts quality estimate";
    } else if (lowerQuery.includes("masala") || lowerQuery.includes("mirch") || lowerQuery.includes("pepper") || lowerQuery.includes("cardamom") || lowerQuery.includes("clove")) {
      finalCategory = "spices";
      finalRate = 450;
      finalDesc = "Indian whole / powdered spices";
    }
  }

  const resultItem = {
    name: finalName,
    hindiName: finalHindi,
    category: finalCategory,
    suggestedUnit: finalUnit,
    typicalMarketRate: finalRate,
    description: finalDesc,
  };

  // Return both item object and top-level properties for 100% component compatibility
  return res.json({
    item: resultItem,
    name: resultItem.name,
    hindiName: resultItem.hindiName,
    category: resultItem.category,
    unit: resultItem.suggestedUnit,
    suggestedUnit: resultItem.suggestedUnit,
    estimatedRate: resultItem.typicalMarketRate,
    typicalMarketRate: resultItem.typicalMarketRate,
    rate: resultItem.typicalMarketRate,
    description: resultItem.description,
    searchSummary,
    searchQueries,
    sources,
  });
});

// Reverse Geocoding / Location Lookup endpoint via Nominatim (with user-agent compliant)
app.get("/api/reverse-geocode", async (req, res) => {
  try {
    const { lat, lng } = req.query;
    if (!lat || !lng) {
      return res.status(400).json({ error: "lat and lng query params are required" });
    }

    const nominatimUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${encodeURIComponent(
      String(lat)
    )}&lon=${encodeURIComponent(String(lng))}&zoom=18&addressdetails=1`;

    const fetchRes = await fetch(nominatimUrl, {
      headers: {
        "User-Agent": "GeoNavigator-MapChatbot/1.0",
        Accept: "application/json",
      },
    });

    if (!fetchRes.ok) {
      return res.json({
        displayName: `${Number(lat).toFixed(4)}, ${Number(lng).toFixed(4)}`,
        address: {},
      });
    }

    const data = await fetchRes.json();
    res.json({
      displayName: data.display_name || `${Number(lat).toFixed(4)}, ${Number(lng).toFixed(4)}`,
      address: data.address || {},
    });
  } catch (err: any) {
    res.json({
      displayName: `${Number(req.query.lat).toFixed(4)}, ${Number(req.query.lng).toFixed(4)}`,
      address: {},
    });
  }
});

// Setup Vite middleware or static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
